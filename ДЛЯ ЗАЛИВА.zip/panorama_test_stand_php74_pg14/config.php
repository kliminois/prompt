<?php
// ПРОВЕРКА ОКРУЖЕНИЯ. Поменяйте только DB_PASS, если порт 5432.
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 5432);
define('DB_NAME', 'postgres');
define('DB_USER', 'postgres');
define('DB_PASS', 'CHANGE_ME');

date_default_timezone_set('Europe/Moscow');
