<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (empty($_SESSION['demo_csrf'])) {
    $_SESSION['demo_csrf'] = bin2hex(random_bytes(24));
}
$csrf = htmlspecialchars($_SESSION['demo_csrf'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= $csrf ?>">
    <title>Панорама · Тестовый стенд</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/app.js" defer></script>
</head>
<body>
    <header class="app-header demo-header">
        <div class="brand">
            <div class="brand-mark">P</div>
            <div>
                <p class="brand-subtitle">КОНКУРСНЫЙ ТЕСТОВЫЙ СТЕНД</p>
                <h1>Панорама <span class="brand-accent">заявок</span></h1>
            </div>
        </div>
        <div class="header-actions">
            <span class="connection-indicator" id="connection-pill" aria-live="polite"><span class="pulse-dot"></span> Проверка сервера...</span>
            <button class="btn-ghost" id="theme-toggle" type="button" aria-label="Переключить тему">☀ Светлая тема</button>
        </div>
    </header>

    <main class="demo-layout">
        <aside class="filters demo-sidebar" aria-label="Фильтры">
            <div class="sidebar-top">
                <span class="eyebrow">НАВИГАЦИЯ</span>
                <div class="sidebar-current"><span class="sidebar-current-icon">◫</span> Обзор заявок</div>
            </div>
            <div class="sidebar-section">
                <div class="section-overline">ФИЛЬТРАЦИЯ</div>
                <label class="field"><span>Поиск по названию</span><input id="search" type="search" placeholder="Например, PostgreSQL" autocomplete="off"></label>
                <label class="field"><span>Статус</span>
                    <select id="status-filter"><option value="">Все статусы</option><option value="new">Новая</option><option value="in_progress">В работе</option><option value="done">Выполнена</option></select>
                </label>
                <label class="field"><span>Раздел</span><select id="category-filter"><option value="">Все разделы</option></select></label>
                <button class="btn-secondary side-reset" id="reset-filters" type="button">↺ Сбросить фильтры</button>
            </div>
            <div class="sidebar-section sidebar-help">
                <div class="section-overline">СТЕНД</div>
                <p>PHP 7.4 · PostgreSQL 14 · AJAX</p>
                <p>Работает без CDN и Node.js.</p>
                <button class="link-button" type="button" id="open-about">ⓘ Общие сведения и проверка</button>
            </div>
        </aside>

        <section class="demo-main" aria-label="Рабочая область">
            <div class="hero">
                <div>
                    <div class="eyebrow">РАБОЧАЯ ПАНЕЛЬ / ОБЗОР</div>
                    <h2>Контроль тестовых заявок</h2>
                    <p>Проверяем работу базы данных, API, адаптивного интерфейса и операций CRUD перед конкурсом.</p>
                </div>
                <div class="hero-actions">
                    <button id="open-about-hero" class="btn-secondary demo-secondary" type="button">Общие сведения</button>
                    <button id="create-button" class="btn-primary demo-primary" type="button">+ Новая заявка</button>
                </div>
            </div>

            <div class="summary-grid" aria-label="Общие показатели">
                <article class="metric"><div class="metric-heading"><span>Всего заявок</span><span class="metric-symbol blue">▦</span></div><strong id="stat-total">—</strong><small>В базе данных</small></article>
                <article class="metric"><div class="metric-heading"><span>Новые</span><span class="metric-symbol orange">◉</span></div><strong id="stat-new">—</strong><small>Ожидают выполнения</small></article>
                <article class="metric"><div class="metric-heading"><span>В работе</span><span class="metric-symbol violet">◷</span></div><strong id="stat-progress">—</strong><small>Активные заявки</small></article>
                <article class="metric"><div class="metric-heading"><span>Выполнены</span><span class="metric-symbol green">✓</span></div><strong id="stat-done">—</strong><small>Закрытые заявки</small></article>
            </div>

            <div class="dashboard-grid">
                <section class="card dashboard-card">
                    <div class="panel-header"><div><div class="eyebrow">АНАЛИТИКА</div><h3>Распределение по статусам</h3></div><span class="mini-caption">Все заявки</span></div>
                    <div id="chart-status" class="chart-status" aria-label="Распределение заявок по статусам"><p class="muted">Данные загружаются...</p></div>
                    <div class="chart-legend"><span><i class="legend-dot legend-blue"></i>Новые</span><span><i class="legend-dot legend-purple"></i>В работе</span><span><i class="legend-dot legend-green"></i>Выполнены</span></div>
                </section>
                <section class="card dashboard-card health-card">
                    <div class="panel-header"><div><div class="eyebrow">ИНФРАСТРУКТУРА</div><h3>Состояние окружения</h3></div><button id="refresh-health" class="small-btn" type="button">↻ Обновить</button></div>
                    <div class="health-list" id="health-list" aria-live="polite">
                        <p class="muted">Проверяем Apache / PHP / PostgreSQL...</p>
                    </div>
                </section>
            </div>

            <section class="card records-card" aria-label="Таблица заявок">
                <div class="panel-header records-heading">
                    <div><div class="eyebrow">ДАННЫЕ И ОПЕРАЦИИ</div><h3>Реестр заявок <span class="count-bubble" id="visible-count">0</span></h3></div>
                    <div class="table-tools"><button id="export-csv" class="btn-secondary demo-secondary" type="button">↓ CSV</button><button id="refresh-data" class="btn-secondary demo-secondary" type="button">↻ Обновить</button></div>
                </div>
                <p class="table-description">Нажми «Подробнее» только у нужной заявки — остальные строки останутся компактными.</p>
                <div class="table-container">
                    <table class="demo-table">
                        <thead><tr><th>№</th><th>Заявка / раздел</th><th>Приоритет</th><th>Статус</th><th>Дата</th><th>Действия</th></tr></thead>
                        <tbody id="requests-body"><tr><td colspan="6" class="empty-table">Загрузка данных...</td></tr></tbody>
                    </table>
                </div>
                <div id="table-empty" class="empty-state" hidden>По указанным фильтрам записей нет. Попробуйте изменить фильтры или добавить заявку.</div>
            </section>
            <footer class="demo-footer"><span>Панорама · Локальный тестовый стенд</span><span>Адаптив: ПК · планшет · смартфон</span></footer>
        </section>
    </main>

    <div class="modal-overlay demo-overlay" id="editor-overlay" hidden>
        <section class="modal demo-dialog" role="dialog" aria-modal="true" aria-labelledby="editor-title">
            <header class="modal-header"><div><span class="eyebrow">РЕДАКТИРОВАНИЕ</span><h2 id="editor-title">Новая заявка</h2></div><button class="modal-close" id="close-editor" type="button" aria-label="Закрыть">×</button></header>
            <form id="editor-form" class="modal-body">
                <input type="hidden" id="edit-id">
                <label class="field"><span>Название *</span><input type="text" id="edit-title" maxlength="120" required placeholder="Что нужно сделать?"></label>
                <label class="field"><span>Раздел *</span><input type="text" id="edit-category" maxlength="50" list="categories-list" required placeholder="Например, Тестирование"><datalist id="categories-list"></datalist></label>
                <div class="form-grid"><label class="field"><span>Приоритет</span><select id="edit-priority"><option value="low">Низкий</option><option value="medium" selected>Средний</option><option value="high">Высокий</option></select></label><label class="field"><span>Статус</span><select id="edit-status"><option value="new">Новая</option><option value="in_progress">В работе</option><option value="done">Выполнена</option></select></label></div>
                <div class="dialog-actions"><button class="btn-secondary demo-secondary" type="button" id="cancel-editor">Отмена</button><button class="btn-primary demo-primary" type="submit" id="submit-editor">Сохранить</button></div>
            </form>
        </section>
    </div>

    <div class="modal-overlay demo-overlay" id="about-overlay" hidden>
        <section class="modal demo-dialog about-dialog" role="dialog" aria-modal="true" aria-labelledby="about-title">
            <header class="modal-header"><div><span class="eyebrow">О ПРОЕКТЕ</span><h2 id="about-title">Общие сведения</h2></div><button class="modal-close" id="close-about" type="button" aria-label="Закрыть">×</button></header>
            <div class="modal-body">
                <p class="dialog-lead">Небольшое приложение для проверки конкурсной конфигурации. Использует ровно одну таблицу <code>public.demo_requests</code> в PostgreSQL.</p>
                <div class="about-grid"><div><strong>Сервер</strong><span>Apache / PHP 7.4</span></div><div><strong>База данных</strong><span>PostgreSQL 14</span></div><div><strong>Операции</strong><span>Создание, изменение, удаление</span></div><div><strong>Режим</strong><span>Полностью локально</span></div></div>
                <p class="dialog-note">Проверка: добавь запись → измени статус → открой «Подробнее» → выгрузи CSV → открой сайт по IP со второго компьютера → проверь ширину экрана планшета.</p>
                <button class="btn-primary demo-primary" id="close-about-bottom" type="button">Понятно</button>
            </div>
        </section>
    </div>

    <div class="modal-overlay demo-overlay" id="details-overlay" hidden>
        <section class="modal demo-dialog details-dialog" role="dialog" aria-modal="true" aria-labelledby="details-title">
            <header class="modal-header"><div><span class="eyebrow">КАРТОЧКА ЗАЯВКИ</span><h2 id="details-title">Подробная информация</h2></div><button class="modal-close" id="close-details" type="button" aria-label="Закрыть">×</button></header>
            <div class="modal-body"><dl class="detail-list" id="details-list"></dl><div class="dialog-actions"><button class="btn-secondary demo-secondary" type="button" id="close-details-bottom">Закрыть</button></div></div>
        </section>
    </div>
    <div id="toast" class="demo-toast" role="status" aria-live="polite" hidden></div>
</body>
</html>
