/* Панорама заявок — полностью локальный JS без Node.js и CDN. */
(() => {
    'use strict';
    const $ = id => document.getElementById(id);
    const csrf = document.querySelector('meta[name="csrf-token"]').content;
    const statuses = { new: 'Новая', in_progress: 'В работе', done: 'Выполнена' };
    const priorities = { low: 'Низкий', medium: 'Средний', high: 'Высокий' };
    let rows = [];
    let loadVersion = 0;
    let toastTimer;
    let debounceTimer;

    const escapeHtml = value => String(value === undefined || value === null ? '' : value)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

    function toast(message, isError = false) {
        const el = $('toast');
        clearTimeout(toastTimer);
        el.textContent = message;
        el.className = 'demo-toast' + (isError ? ' error' : '');
        el.hidden = false;
        toastTimer = setTimeout(() => { el.hidden = true; }, isError ? 6000 : 3500);
    }

    async function api(url, options) {
        const response = await fetch(url, Object.assign({ cache: 'no-store', credentials: 'same-origin' }, options || {}));
        let data;
        try { data = await response.json(); }
        catch (_) { throw new Error('Сервер вернул не JSON. Проверьте PHP и настройки Apache.'); }
        if (!response.ok || !data.ok) throw new Error(data.error || ('Ошибка HTTP ' + response.status));
        return data;
    }

    function statePill(isOk, message) {
        const el = $('connection-pill');
        el.className = 'connection-indicator ' + (isOk ? 'ok' : 'bad');
        el.innerHTML = '<span class="pulse-dot"></span>' + escapeHtml(message);
    }

    const healthRow = (name, value, ok) => '<div class="health-row"><span>' + escapeHtml(name) +
        '</span><strong class="' + (ok === false ? 'health-bad' : ok === true ? 'health-ok' : '') + '">' + escapeHtml(value) + '</strong></div>';

    async function loadHealth() {
        const container = $('health-list');
        try {
            const response = await fetch('api/health.php', { cache: 'no-store' });
            const data = await response.json();
            const hasTable = data.table_exists === true;
            const connected = data.ok === true;
            statePill(connected, connected ? 'Сервер и БД работают' : 'Требуется настройка');
            container.innerHTML = [
                healthRow('PHP', data.php_version || '—', data.php_74),
                healthRow('PHP pgsql', data.pgsql ? 'Включён' : 'Не найден', !!data.pgsql),
                healthRow('PHP mbstring', data.mbstring ? 'Включён' : 'Не найден', !!data.mbstring),
                healthRow('PHP bcmath', data.bcmath ? 'Включён' : 'Не найден', !!data.bcmath),
                healthRow('PostgreSQL', data.postgresql_version || 'Нет подключения', connected),
                healthRow('Таблица demo_requests', hasTable ? 'Есть · ' + data.rows + ' записей' : 'Не найдена', hasTable)
            ].join('') + (data.error ? '<p class="health-bad">' + escapeHtml(data.error) + '</p>' : '');
        } catch (_) {
            statePill(false, 'Ошибка PHP API');
            container.textContent = 'Не удалось выполнить проверку API. Откройте api/health.php напрямую.';
        }
    }

    function updateMetrics(s) {
        $('stat-total').textContent = s.total;
        $('stat-new').textContent = s.new_count;
        $('stat-progress').textContent = s.active_count;
        $('stat-done').textContent = s.done_count;
        const chart = $('chart-status');
        const total = Math.max(1, s.total);
        chart.innerHTML = [
            ['Новые', s.new_count, 'fill-blue'],
            ['В работе', s.active_count, 'fill-purple'],
            ['Выполнены', s.done_count, 'fill-green']
        ].map(([label, count, cls]) => '<div class="chart-line"><span>' + label +
            '</span><div class="chart-track"><span class="chart-fill ' + cls + '" style="width:' +
            (count / total * 100).toFixed(2) + '%"></span></div><strong>' + count + '</strong></div>').join('');
    }

    function updateCategoryOptions(categories) {
        const select = $('category-filter');
        const current = select.value;
        select.replaceChildren(new Option('Все разделы', ''));
        $('categories-list').replaceChildren();
        categories.forEach(value => {
            select.add(new Option(value, value));
            $('categories-list').appendChild(new Option(value, value));
        });
        select.value = categories.includes(current) ? current : '';
    }

    function renderRows() {
        const tbody = $('requests-body');
        $('visible-count').textContent = String(rows.length);
        $('table-empty').hidden = rows.length !== 0;
        if (!rows.length) { tbody.innerHTML = ''; return; }
        tbody.innerHTML = rows.map(r => {
            const statusClass = { new: 'tag-new', in_progress: 'tag-progress', done: 'tag-done' }[r.status] || '';
            const priorityClass = { low: 'tag-low', medium: 'tag-medium', high: 'tag-high' }[r.priority] || '';
            return '<tr>' +
                '<td data-label="№" class="cell-id">#' + escapeHtml(r.id) + '</td>' +
                '<td data-label="Заявка" class="title-cell"><span class="title-text">' + escapeHtml(r.title) +
                '</span><span class="subtitle-text">' + escapeHtml(r.category) + '</span></td>' +
                '<td data-label="Приоритет"><span class="tag ' + priorityClass + '">' + escapeHtml(priorities[r.priority] || r.priority) + '</span></td>' +
                '<td data-label="Статус"><span class="tag ' + statusClass + '">' + escapeHtml(statuses[r.status] || r.status) + '</span></td>' +
                '<td data-label="Создана">' + escapeHtml(r.created_at) + '</td>' +
                '<td data-label="Действия"><div class="cell-actions">' +
                '<button class="action-btn" data-action="details" data-id="' + escapeHtml(r.id) + '">Подробнее</button>' +
                '<button class="action-btn" data-action="edit" data-id="' + escapeHtml(r.id) + '">Изменить</button>' +
                '<button class="action-btn danger" data-action="delete" data-id="' + escapeHtml(r.id) + '">Удалить</button>' +
                '</div></td></tr>';
        }).join('');
    }

    async function loadData() {
        const version = ++loadVersion;
        const params = new URLSearchParams({ status: $('status-filter').value, category: $('category-filter').value, q: $('search').value });
        try {
            const result = await api('api/data.php?' + params.toString());
            if (version !== loadVersion) return;
            rows = result.rows;
            updateMetrics(result.stats);
            updateCategoryOptions(result.categories);
            renderRows();
        } catch (error) {
            if (version !== loadVersion) return;
            rows = [];
            $('requests-body').innerHTML = '<tr><td colspan="6" class="empty-table">Не удалось получить данные. ' + escapeHtml(error.message) + '</td></tr>';
            $('visible-count').textContent = '0';
            statePill(false, 'БД недоступна');
            toast(error.message, true);
        }
    }

    function show(overlayId) {
        $(overlayId).hidden = false;
        document.body.style.overflow = 'hidden';
    }
    function hide(overlayId) {
        $(overlayId).hidden = true;
        if (!Array.from(document.querySelectorAll('.demo-overlay')).some(el => !el.hidden)) {
            document.body.style.overflow = '';
        }
    }
    function newRecord() {
        $('editor-title').textContent = 'Новая заявка';
        $('editor-form').reset();
        $('edit-id').value = '';
        show('editor-overlay');
        $('edit-title').focus();
    }
    function editRecord(r) {
        $('editor-title').textContent = 'Изменение заявки #' + r.id;
        $('edit-id').value = r.id;
        $('edit-title').value = r.title;
        $('edit-category').value = r.category;
        $('edit-status').value = r.status;
        $('edit-priority').value = r.priority;
        show('editor-overlay');
        $('edit-title').focus();
    }
    function showDetails(r) {
        $('details-title').textContent = 'Заявка #' + r.id;
        const entries = [
            ['ID', '#' + r.id], ['Название', r.title], ['Раздел', r.category],
            ['Приоритет', priorities[r.priority] || r.priority],
            ['Статус', statuses[r.status] || r.status], ['Создана', r.created_at]
        ];
        const dl = $('details-list');
        dl.replaceChildren();
        entries.forEach(([label, value]) => {
            const dt = document.createElement('dt'); dt.textContent = label;
            const dd = document.createElement('dd'); dd.textContent = value;
            dl.append(dt, dd);
        });
        show('details-overlay');
        $('close-details').focus();
    }

    async function submitRecord(event) {
        event.preventDefault();
        const button = $('submit-editor');
        button.disabled = true;
        const payload = {
            action: $('edit-id').value ? 'update' : 'create',
            title: $('edit-title').value.trim(),
            category: $('edit-category').value.trim(),
            status: $('edit-status').value,
            priority: $('edit-priority').value
        };
        if ($('edit-id').value) payload.id = Number($('edit-id').value);
        try {
            const result = await api('api/save.php', {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(payload)
            });
            hide('editor-overlay');
            toast(result.message);
            await loadData();
            loadHealth();
        } catch (error) { toast(error.message, true); }
        finally { button.disabled = false; }
    }

    async function deleteRecord(r) {
        if (!window.confirm('Удалить заявку #' + r.id + ' «' + r.title + '»?')) return;
        try {
            const result = await api('api/save.php', {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
                body: JSON.stringify({ action: 'delete', id: Number(r.id) })
            });
            toast(result.message);
            await loadData();
            loadHealth();
        } catch (error) { toast(error.message, true); }
    }

    $('requests-body').addEventListener('click', event => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;
        const r = rows.find(item => String(item.id) === button.dataset.id);
        if (!r) { toast('Запись не найдена. Обновите данные.', true); return; }
        if (button.dataset.action === 'details') showDetails(r);
        if (button.dataset.action === 'edit') editRecord(r);
        if (button.dataset.action === 'delete') deleteRecord(r);
    });
    $('editor-form').addEventListener('submit', submitRecord);
    $('create-button').addEventListener('click', newRecord);
    $('reset-filters').addEventListener('click', () => { $('search').value = ''; $('status-filter').value = ''; $('category-filter').value = ''; loadData(); });
    $('status-filter').addEventListener('change', loadData);
    $('category-filter').addEventListener('change', loadData);
    $('search').addEventListener('input', () => { clearTimeout(debounceTimer); debounceTimer = setTimeout(loadData, 260); });
    $('refresh-data').addEventListener('click', () => { loadData(); loadHealth(); });
    $('refresh-health').addEventListener('click', loadHealth);
    $('export-csv').addEventListener('click', () => { window.location.href = 'api/export.php'; });
    $('open-about').addEventListener('click', () => show('about-overlay'));
    $('open-about-hero').addEventListener('click', () => show('about-overlay'));
    ['close-about', 'close-about-bottom'].forEach(id => $(id).addEventListener('click', () => hide('about-overlay')));
    ['close-details', 'close-details-bottom'].forEach(id => $(id).addEventListener('click', () => hide('details-overlay')));
    ['close-editor', 'cancel-editor'].forEach(id => $(id).addEventListener('click', () => hide('editor-overlay')));
    document.querySelectorAll('.demo-overlay').forEach(overlay => {
        overlay.addEventListener('mousedown', event => { if (event.target === overlay) hide(overlay.id); });
    });
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') document.querySelectorAll('.demo-overlay').forEach(o => { if (!o.hidden) hide(o.id); });
    });
    const setTheme = light => {
        document.body.classList.toggle('theme-light', light);
        $('theme-toggle').textContent = light ? '☾ Тёмная тема' : '☀ Светлая тема';
        try { localStorage.setItem('demo-theme', light ? 'light' : 'dark'); } catch (_) { /* браузер может блокировать хранилище */ }
    };
    let light = false;
    try { light = localStorage.getItem('demo-theme') === 'light'; } catch (_) { /* необязательно */ }
    setTheme(light);
    $('theme-toggle').addEventListener('click', () => setTheme(!document.body.classList.contains('theme-light')));
    loadHealth();
    loadData();
})();
