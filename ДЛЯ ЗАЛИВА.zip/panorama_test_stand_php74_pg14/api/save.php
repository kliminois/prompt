<?php
require_once __DIR__ . '/bootstrap.php';
require_post_and_csrf();

try {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) {
        json_out(array('ok' => false, 'error' => 'Некорректный JSON.'), 400);
    }
    $action = isset($body['action']) ? (string) $body['action'] : '';
    if (!in_array($action, array('create', 'update', 'delete'), true)) {
        json_out(array('ok' => false, 'error' => 'Неизвестная операция.'), 422);
    }
    $conn = db_conn();
    $id = isset($body['id']) ? filter_var($body['id'], FILTER_VALIDATE_INT) : false;
    if ($action !== 'create' && ($id === false || $id < 1)) {
        json_out(array('ok' => false, 'error' => 'Некорректный ID.'), 422);
    }
    if ($action === 'delete') {
        $result = db_query($conn, 'DELETE FROM public.demo_requests WHERE id = $1 RETURNING id', array($id));
        if (pg_num_rows($result) < 1) {
            json_out(array('ok' => false, 'error' => 'Запись уже удалена или не найдена.'), 404);
        }
        json_out(array('ok' => true, 'message' => 'Запись удалена.'));
    }
    $title = isset($body['title']) ? trim((string) $body['title']) : '';
    $category = isset($body['category']) ? trim((string) $body['category']) : '';
    $status = isset($body['status']) ? (string) $body['status'] : '';
    $priority = isset($body['priority']) ? (string) $body['priority'] : '';
    if ($title === '' || mb_strlen($title, 'UTF-8') > 120 || $category === '' || mb_strlen($category, 'UTF-8') > 50) {
        json_out(array('ok' => false, 'error' => 'Укажите название (до 120 символов) и раздел (до 50).'), 422);
    }
    if (!in_array($status, array('new','in_progress','done'), true) ||
        !in_array($priority, array('low','medium','high'), true)) {
        json_out(array('ok' => false, 'error' => 'Некорректный статус или приоритет.'), 422);
    }
    if ($action === 'create') {
        $result = db_query($conn,
            'INSERT INTO public.demo_requests (title, category, status, priority) VALUES ($1,$2,$3,$4) RETURNING id',
            array($title, $category, $status, $priority));
        $row = pg_fetch_assoc($result);
        json_out(array('ok' => true, 'message' => 'Запись добавлена.', 'id' => (int) $row['id']));
    }
    $result = db_query($conn,
        'UPDATE public.demo_requests SET title=$1, category=$2, status=$3, priority=$4 WHERE id=$5 RETURNING id',
        array($title, $category, $status, $priority, $id));
    if (pg_num_rows($result) < 1) {
        json_out(array('ok' => false, 'error' => 'Запись не найдена.'), 404);
    }
    json_out(array('ok' => true, 'message' => 'Изменения сохранены.'));
} catch (Throwable $e) {
    json_out(array('ok' => false, 'error' => $e->getMessage()), 500);
}
