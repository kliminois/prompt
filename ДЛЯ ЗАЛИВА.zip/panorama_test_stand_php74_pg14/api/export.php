<?php
require_once __DIR__ . '/bootstrap.php';
try {
    $conn = db_conn();
    $result = db_query($conn,
        "SELECT id, title, category, status, priority,
                to_char(created_at, 'DD.MM.YYYY HH24:MI') AS created_at
         FROM public.demo_requests ORDER BY id ASC");
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="demo_requests.csv"');
    header('Cache-Control: no-store');
    $f = fopen('php://output', 'w');
    fwrite($f, "\xEF\xBB\xBF");
    fputcsv($f, array('ID', 'Название', 'Раздел', 'Статус', 'Приоритет', 'Создана'), ';');
    while ($row = pg_fetch_assoc($result)) {
        fputcsv($f, array_values($row), ';');
    }
    fclose($f);
} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Не удалось выгрузить CSV. Проверьте подключение к БД.';
}
