<?php
require_once __DIR__ . '/bootstrap.php';
$info = array(
    'ok' => false,
    'php_version' => PHP_VERSION,
    'php_74' => PHP_MAJOR_VERSION === 7 && PHP_MINOR_VERSION === 4,
    'pgsql' => extension_loaded('pgsql'),
    'mbstring' => extension_loaded('mbstring'),
    'bcmath' => extension_loaded('bcmath'),
    'json' => extension_loaded('json'),
    'database' => DB_NAME,
    'port' => DB_PORT
);
try {
    $conn = db_conn();
    $r = db_query($conn, "SELECT current_setting('server_version') AS version,
                              to_regclass('public.demo_requests')::text AS demo_table");
    $row = pg_fetch_assoc($r);
    $info['postgresql_version'] = $row['version'];
    $info['table_exists'] = $row['demo_table'] !== null;
    if (!$info['table_exists']) {
        $info['error'] = 'Таблица отсутствует. Выполните setup/database.sql.';
        json_out($info, 503);
    }
    $r = db_query($conn, 'SELECT COUNT(*) AS total FROM public.demo_requests');
    $info['rows'] = (int) pg_fetch_result($r, 0, 'total');
    $info['ok'] = true;
    json_out($info);
} catch (Throwable $e) {
    $info['error'] = $e->getMessage();
    json_out($info, 503);
}
