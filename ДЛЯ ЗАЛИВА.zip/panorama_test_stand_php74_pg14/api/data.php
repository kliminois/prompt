<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_out(array('ok' => false, 'error' => 'Требуется метод GET.'), 405);
}

try {
    $conn = db_conn();
    $status = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
    $category = isset($_GET['category']) ? trim((string) $_GET['category']) : '';
    $search = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
    if (strlen($search) > 100 || strlen($category) > 80) {
        json_out(array('ok' => false, 'error' => 'Слишком длинное условие поиска.'), 422);
    }
    if (!in_array($status, array('', 'new', 'in_progress', 'done'), true)) {
        json_out(array('ok' => false, 'error' => 'Некорректный статус.'), 422);
    }

    $result = db_query($conn,
        "SELECT id, title, category, status, priority, to_char(created_at, 'DD.MM.YYYY HH24:MI') AS created_at
         FROM public.demo_requests
         WHERE ($1::text = '' OR status = $1)
           AND ($2::text = '' OR category = $2)
           AND ($3::text = '' OR title ILIKE '%' || $3 || '%')
         ORDER BY created_at DESC, id DESC LIMIT 200",
        array($status, $category, $search)
    );
    $rows = pg_fetch_all($result);
    if (!$rows) { $rows = array(); }
    $stats_result = db_query($conn,
        "SELECT COUNT(*) AS total,
                COUNT(*) FILTER (WHERE status='new') AS new_count,
                COUNT(*) FILTER (WHERE status='in_progress') AS active_count,
                COUNT(*) FILTER (WHERE status='done') AS done_count
         FROM public.demo_requests"
    );
    $stats = pg_fetch_assoc($stats_result);
    foreach ($stats as $key => $value) { $stats[$key] = (int) $value; }
    $categories = pg_fetch_all_columns(db_query($conn,
        'SELECT DISTINCT category FROM public.demo_requests ORDER BY category'));
    if (!$categories) { $categories = array(); }
    json_out(array('ok' => true, 'rows' => $rows, 'stats' => $stats, 'categories' => $categories));
} catch (Throwable $e) {
    json_out(array('ok' => false, 'error' => $e->getMessage()), 500);
}
