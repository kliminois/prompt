<?php
require_once dirname(__DIR__) . '/config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function json_out($payload, $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function conn_value($value)
{
    $value = str_replace(array('\\', "'"), array('\\\\', "\\'"), (string) $value);
    return "'" . $value . "'";
}

function db_conn()
{
    if (!extension_loaded('pgsql')) {
        throw new RuntimeException('Расширение PHP pgsql не включено.');
    }
    if (DB_PASS === 'CHANGE_ME') {
        throw new RuntimeException('Укажите пароль PostgreSQL в config.php (DB_PASS).');
    }
    $params = 'host=' . conn_value(DB_HOST) .
        ' port=' . (int) DB_PORT .
        ' dbname=' . conn_value(DB_NAME) .
        ' user=' . conn_value(DB_USER) .
        ' password=' . conn_value(DB_PASS) .
        ' connect_timeout=4';
    $conn = @pg_connect($params, PGSQL_CONNECT_FORCE_NEW);
    if ($conn === false) {
        throw new RuntimeException('Не удаётся подключиться к PostgreSQL. Проверьте службу, порт и пароль.');
    }
    return $conn;
}

function db_query($conn, $sql, $params = array())
{
    $result = @pg_query_params($conn, $sql, $params);
    if ($result === false) {
        error_log('Demo DB query error: ' . pg_last_error($conn));
        throw new RuntimeException('Ошибка SQL. Проверьте, выполнен ли setup/database.sql.');
    }
    return $result;
}

function require_post_and_csrf()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        json_out(array('ok' => false, 'error' => 'Требуется метод POST.'), 405);
    }
    $provided = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    $expected = isset($_SESSION['demo_csrf']) ? $_SESSION['demo_csrf'] : '';
    if (!$expected || !is_string($provided) || !hash_equals($expected, $provided)) {
        json_out(array('ok' => false, 'error' => 'Сессия устарела. Обновите страницу.'), 403);
    }
}
