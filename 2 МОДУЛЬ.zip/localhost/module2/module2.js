'use strict';
/* Дополнительные разделы. Первый конкурсный модуль не изменяется. */
(() => {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const csrf = $('meta[name="csrf-token"]').content;
  const state = { view: 'telemetry', data: null, busy: false };
  const resources = {water: 'Водоснабжение', energy: 'Электроснабжение'};
  const statuses = {new:'Новый',assigned:'Назначен',working:'В работе',done:'Завершён',cancelled:'Отменён'};
  const sensorTypes = {pressure:'Давление',flow:'Расход',voltage:'Напряжение',current:'Ток',temperature:'Температура'};
  const nextStatus = {new:'assigned',assigned:'working',working:'done'};
  const esc = v => String(v ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
  const num = v => Number(v).toLocaleString('ru-RU',{maximumFractionDigits:3});
  const count = v => Number(v || 0);
  const resBadge = r => `<span class="badge ${r === 'water' ? 'water' : r==='energy' ? 'energy':'none'}">${esc(resources[r] || (r==='both'?'Оба ресурса':r))}</span>`;
  const stateBadge = s => `<span class="badge ${esc(s)}">${esc(statuses[s] || s)}</span>`;
  let toastTimer;
  function toast(text){const n=$('#toast'); n.textContent=text;n.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>n.hidden=true,4600);}
  function error(text){$('#alert').textContent=text;$('#alert').hidden=false;}
  function clearError(){$('#alert').hidden=true;}
  async function api(action,payload,query={}){
    const options=payload===undefined?{method:'GET'}:{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(payload)};
    let response;try{response=await fetch('module2/api.php?'+new URLSearchParams({action,...query}).toString(),options);}catch(e){throw Error('Не удалось связаться с локальным сервером. Проверьте OSPanel и PostgreSQL.');}
    let obj;try{obj=await response.json();}catch(e){throw Error('Некорректный ответ сервера (не JSON).');}
    if(!response.ok||!obj.ok)throw Error(obj.error||`Ошибка HTTP ${response.status}`);
    return obj.data;
  }
  async function refresh(){
    if(state.busy)return;
    state.busy=true;clearError();$('#btn-refresh').disabled=true;
    try{state.data=await api('snapshot');render();}
    catch(e){error(e.message);state.data=null;render();}
    finally{state.busy=false;$('#btn-refresh').disabled=false;}
  }
  function switchView(v){
    state.view=v;
    for(const x of ['telemetry','orders','analytics']){$(`#view-${x}`).hidden=x!==v;}
    $$('.navtab').forEach(b=>{b.classList.toggle('selected',b.dataset.view===v);b.setAttribute('aria-selected',String(b.dataset.view===v));});
    const labels={telemetry:['Телеметрия инфраструктуры','Показания датчиков из локальной PostgreSQL'],orders:['Диспетчеризация ремонтных работ','Наряды и назначение бригад'],analytics:['Аналитика инфраструктуры','Показатели на основании текущих локальных данных']};
    $('#page-title').textContent=labels[v][0];$('#page-subtitle').textContent=labels[v][1];render();
  }
  function readingState(s){
    if(s.reading===null||s.reading===undefined)return 'none';
    const v=Number(s.reading),min=Number(s.min_value),max=Number(s.max_value);
    if(v<min||v>max)return 'alarm';
    if(v < min+(max-min)*.1 || v > max-(max-min)*.1)return 'warn';
    return 'ok';
  }
  function metric(title,value,sub,color){return `<article class="metric"><div class="label">${esc(title)}</div><strong style="color:${color||'var(--text)'}">${esc(value)}</strong><small>${esc(sub)}</small></article>`;}
  function metrics(){
    const d=state.data;
    if(!d){$('#metrics').innerHTML='';return;}
    const sensors=d.sensors,orders=d.orders;
    const alert=sensors.filter(s=>readingState(s)==='alarm').length;
    const active=orders.filter(o=>['new','assigned','working'].includes(o.status)).length;
    const measured=sensors.filter(s=>s.reading!==null).length;
    $('#metrics').innerHTML=metric('Объекты инфраструктуры',d.objects.length,'Из первого модуля','var(--text)')+
      metric('Датчиков с измерением',`${measured}/${sensors.length}`,'Без измерений не считаются нормальными','var(--accent)')+
      metric('Показания вне порогов',alert,'Не означает автоматически аварию',alert?'var(--danger)':'var(--success)')+
      metric('Открытые наряды',active,'Новый · назначен · в работе','var(--repair)');
  }
  function renderSensors(){
    const d=state.data; if(!d)return;
    const q=$('#sensor-search').value.trim().toLowerCase(),resource=$('#sensor-resource').value;
    const rows=d.sensors.filter(s=>(resource==='all'||s.resource_type===resource)&&(!q||(s.sensor_code+' '+s.object_name+' '+s.display_name).toLowerCase().includes(q)));
    $('#sensor-empty').hidden=rows.length>0;
    $('#sensors').innerHTML=rows.map(s=>{
      const st=readingState(s),label={none:'Нет данных',ok:'Норма',warn:'Внимание',alarm:'Вне порога'}[st];
      return `<button class="s-card" data-sensor="${esc(s.sensor_code)}"><div class="top"><span class="code">${esc(s.sensor_code)}</span><span class="badge ${st}">${label}</span></div><div class="name">${esc(s.display_name)}</div><div class="sub">${esc(s.object_name||'Объект не указан')} · ${esc(sensorTypes[s.sensor_type]||s.sensor_type)}</div><div>${resBadge(s.resource_type)}</div><div class="reading">${s.reading===null?'—':num(s.reading)} <small>${esc(s.unit)}</small></div><div class="range">Допуск: ${num(s.min_value)} – ${num(s.max_value)} ${esc(s.unit)}</div><div class="sub">${esc(s.measured_at||'Измерений нет')} (Москва)</div></button>`;
    }).join('');
  }
  function renderOrders(){
    const d=state.data; if(!d)return;
    const query=$('#order-search').value.trim().toLowerCase();
    $('#brigades').innerHTML=d.brigades.map(b=>`<div class="brigade"><b>${esc(b.name)}</b>${resBadge(b.resource_scope==='both'?'both':b.resource_scope)}<span class="sub">${count(b.active_orders)} нар. · ${esc(b.members)} чел.</span></div>`).join('')||'<div class="sub">Бригад нет — добавьте первую</div>';
    const rows=d.orders.filter(o=>(String(o.id_order)+' '+o.title+' '+o.object_name+' '+o.brigade_name).toLowerCase().includes(query));
    $('#kanban').innerHTML=['new','assigned','working','done'].map(st=>{
      const cards=rows.filter(o=>st==='done'?['done','cancelled'].includes(o.status):o.status===st);
      return `<section class="kanban-col"><header>${esc(st==='done'?'Закрытые':statuses[st])}<span class="sub">${cards.length}</span></header><div class="kanban-body">${cards.map(o=>{
        const button=nextStatus[o.status];
        return `<article class="order-card"><div class="top"><span class="code">№ ${esc(o.id_order)}</span> ${stateBadge(o.status)}</div><div class="title">${esc(o.title)}</div><div class="sub">${esc(o.object_name||'Объект отсутствует')} · ${esc(o.created_fmt)}</div><div>${resBadge(o.resource_type)} <span class="badge">Приоритет ${esc(o.priority)}</span></div><div class="sub">${esc(o.brigade_name||'Бригада не назначена')}</div><div class="order-actions"><button class="btn btn-small" data-history="${esc(o.id_order)}">История</button>${button?`<button class="btn btn-small btn-primary" data-next="${esc(o.id_order)}">${esc(button==='assigned'?'Назначить':button==='working'?'Начать':'Завершить')}</button>`:''}${o.status==='new'||o.status==='assigned'?`<button class="btn btn-small btn-danger" data-cancel="${esc(o.id_order)}">Отменить</button>`:''}</div></article>`;
      }).join('')||'<div class="sub">Нарядов нет</div>'}</div></section>`;
    }).join('');
  }
  function bars(title,rows,fmt=x=>x){
    const max=Math.max(1,...rows.map(x=>Number(x.total)));
    return `<article class="chart-card"><h3>${esc(title)}</h3>${rows.length?rows.map(x=>`<div class="bar-row"><span>${esc(fmt(x))}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.min(100,100*Number(x.total)/max)}%"></div></div><b>${esc(x.total)}</b></div>`).join(''):'<p class="sub">Данных нет</p>'}</article>`;
  }
  function renderAnalytics(){
    const d=state.data;if(!d)return;
    const ord=d.orders,completed=ord.filter(o=>o.status==='done'&&o.started_at&&o.finished_at);
    const hrs=completed.map(o=>(Date.parse(o.finished_at)-Date.parse(o.started_at))/36e5).filter(v=>Number.isFinite(v)&&v>=0);
    const mt=hrs.length?num(hrs.reduce((a,b)=>a+b,0)/hrs.length)+' ч':'Нет данных';
    const statusCounts=['new','assigned','working','done','cancelled'].map(st=>({district:statuses[st],total:ord.filter(o=>o.status===st).length}));
    const rows=[['Объектов',d.objects.length],['Зарегистрированных событий',d.events.length+' (не более 500 последних)'],['Завершённых нарядов',completed.length],['Средняя длительность работ по завершённым нарядам',mt],['Установленных датчиков',d.sensors.length]];
    $('#analytics').innerHTML=bars('Объекты по районам',d.byDistrict,x=>x.district||'Без района')+
      bars('Зарегистрированные события по ресурсу',d.byResource,x=>resources[x.resource_type]||x.resource_type)+
      bars('Наряды по состоянию',statusCounts,x=>x.district)+
      bars('События по дням (последние 30 дат)',[...d.trend].reverse(),x=>x.day)+
      `<article class="chart-card"><h3>Сводка</h3><table class="mini-table"><tbody>${rows.map(r=>`<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td></tr>`).join('')}</tbody></table></article>`;
  }
  function render(){metrics();if(state.view==='telemetry')renderSensors();if(state.view==='orders')renderOrders();if(state.view==='analytics')renderAnalytics();}
  function openModal(title,content,after){$('#modal-title').textContent=title;$('#modal-content').innerHTML=content;$('#modal').hidden=false;document.body.style.overflow='hidden';$('#modal')._after=after;$('#modal').querySelector('input,select,textarea,button')?.focus();}
  function closeModal(){$('#modal').hidden=true;$('#modal-content').innerHTML='';document.body.style.overflow='';$('#modal')._after=null;}
  function opt(items,valueKey,labelKey){return items.map(i=>`<option value="${esc(i[valueKey])}">${esc(i[labelKey])}</option>`).join('');}
  function controls(text='Сохранить'){return `<div class="dialog-actions"><button type="button" class="btn btn-secondary" data-close>Отмена</button><button type="submit" class="btn btn-primary">${esc(text)}</button></div>`;}
  function formWrap(id,fields,submit){return `<form id="${id}" class="form-grid">${fields}${controls(submit)}</form>`;}
  function field(label,control,full=false){return `<label class="${full?'full':''}"><span>${esc(label)}</span>${control}</label>`;}
  function input(name,type='text',extras=''){return `<input name="${esc(name)}" type="${type}" ${extras}>`;}
  function resourceOptions(){return `<option value="water">Водоснабжение</option><option value="energy">Электроснабжение</option>`;}
  function showSensorForm(){
    const objects=state.data.objects;
    const f=field('Код датчика',input('sensor_code','text','required maxlength="64" placeholder="S-001"'))+
      field('Объект',`<select name="id_edifice" required>${opt(objects,'id_edifice','name')}</select>`,true)+
      field('Ресурс',`<select name="resource_type">${resourceOptions()}</select>`)+
      field('Тип измерения',`<select name="sensor_type">${Object.entries(sensorTypes).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select>`)+
      field('Наименование',input('display_name','text','required maxlength="120" placeholder="Давление на входе"'),true)+
      field('Единицы',input('unit','text','required maxlength="24" value="бар"'))+
      field('Мин. допустимое',input('min_value','number','required step="any" value="2"'))+
      field('Макс. допустимое',input('max_value','number','required step="any" value="6"'));
    openModal('Создать датчик',formWrap('sensor-form',f,'Создать'),null);
  }
  function showBrigadeForm(){
    const f=field('Код бригады',input('brigade_code','text','required maxlength="64" placeholder="BR-01"'))+
    field('Название',input('name','text','required maxlength="120" placeholder="Ремонтная бригада №1"'),true)+
    field('Специализация',`<select name="resource_scope">${resourceOptions()}<option value="both">Оба ресурса</option></select>`)+
    field('Число работников',input('members','number','required min="1" max="1000" value="3"'))+
    field('Контакт',input('contact','text','maxlength="120"'),true);
    openModal('Создать бригаду',formWrap('brigade-form',f,'Создать'));
  }
  function showOrderForm(){
    const objs=state.data.objects;
    if(!objs.length){toast('В кэше нет объектов. Заполните первый модуль.');return;}
    const f=field('Объект',`<select name="id_edifice" required>${opt(objs,'id_edifice','name')}</select>`,true)+
      field('Ресурс',`<select name="resource_type">${resourceOptions()}</select>`)+
      field('Связанное событие (необязательно)',`<select name="id_event"><option value="">Без события</option>${state.data.events.map(e=>`<option value="${esc(e.id_event)}" data-edifice="${esc(e.id_edifice)}" data-res="${esc(e.resource_type)}">№${esc(e.id_event)} · ${esc(e.resource_type)} · ${esc(e.occurred_at)}</option>`).join('')}</select>`)+
      field('Название работ',input('title','text','required maxlength="200" placeholder="Проверка насосной станции"'),true)+
      field('Приоритет',`<select name="priority"><option value="1">1 · Высокий</option><option value="2" selected>2 · Средний</option><option value="3">3 · Низкий</option></select>`)+
      field('Бригада',`<select name="brigade_code"><option value="">Не назначать</option>${opt(state.data.brigades,'brigade_code','name')}</select>`)+
      field('Комментарий',`<textarea name="note" maxlength="2000" placeholder="Объём работ и примечания"></textarea>`,true);
    openModal('Новый ремонтный наряд',formWrap('order-form',f,'Создать наряд'));
    // При выборе существующего события синхронизируем объект/ресурс — проверка также есть на сервере.
    const form=$('#order-form');form.elements.id_event.addEventListener('change',()=>{
      const e=form.elements.id_event.selectedOptions[0];if(e.dataset.edifice){form.elements.id_edifice.value=e.dataset.edifice;form.elements.resource_type.value=e.dataset.res;}
    });
  }
  function showReading(s){
    const st=readingState(s),col={alarm:'var(--danger)',warn:'var(--warn)',ok:'var(--success)',none:'var(--muted)'}[st];
    const desc=`<p class="dialog-copy"><strong>${esc(s.display_name)}</strong> · ${esc(s.object_name||'без объекта')}<br>Допустимо: ${num(s.min_value)}–${num(s.max_value)} ${esc(s.unit)}</p>
      <div class="reading" style="color:${col}">${s.reading===null?'Нет данных':num(s.reading)+' '+esc(s.unit)}</div>
      <div class="sub">Последняя запись: ${esc(s.measured_at||'отсутствует')} (Москва)</div>
      <div id="reading-history" class="history"><div class="sub">Загрузка истории…</div></div>`;
    const form=field('Новое показание',input('reading','number','required step="any"'),true);
    openModal('Датчик '+s.sensor_code,desc+formWrap('reading-form',form,'Сохранить измерение'));
    $('#reading-form').dataset.sensor=s.sensor_code;
    api('readings',undefined,{sensor_code:s.sensor_code}).then(rows=>{
      if($('#modal').hidden||!$('#reading-history'))return;
      $('#reading-history').innerHTML=rows.length?rows.slice(-15).reverse().map(r=>`<div class="history-entry">${esc(r.measured_at)} · <b>${num(r.reading)} ${esc(s.unit)}</b></div>`).join(''):'<div class="sub">История пуста</div>';
    }).catch(e=>{$('#reading-history').textContent=e.message;});
  }
  function showOrderHistory(o){
    const h=state.data.history.filter(x=>String(x.id_order)===String(o.id_order));
    const body=`<p class="dialog-copy">${esc(o.title)} · ${esc(o.object_name||'Без объекта')}<br>Приоритет ${esc(o.priority)} · ${esc(o.brigade_name||'Бригада не назначена')}</p><div class="history">${h.length?h.map(x=>`<div class="history-entry"><span class="sub">${esc(x.changed_at)}</span> · ${esc(statuses[x.from_status]||'Создание')} → <b>${esc(statuses[x.to_status]||x.to_status)}</b><br>${esc(x.description)}</div>`).join(''):'<div class="sub">Нет записей истории</div>'}</div>`;
    openModal('История наряда №'+o.id_order,body);
  }
  function showAssign(o){
    const brigades=state.data.brigades.filter(b=>b.is_active==='t'&&(b.resource_scope==='both'||b.resource_scope===o.resource_type));
    if(!brigades.length){toast('Нет подходящей бригады. Создайте её в разделе нарядов.');return;}
    const form=field('Бригада',`<select name="brigade_code">${opt(brigades,'brigade_code','name')}</select>`,true);
    openModal('Назначить бригаду · наряд №'+o.id_order,formWrap('assign-form',form,'Назначить'));
    $('#assign-form').dataset.order=o.id_order;
  }
  async function mutation(action,payload,closing=true){
    try{await api(action,payload);if(closing)closeModal();toast('Изменения сохранены в локальной базе');await refresh();}
    catch(e){error(e.message);toast(e.message);}
  }
  $$('.navtab').forEach(b=>b.onclick=()=>switchView(b.dataset.view));
  $('#btn-refresh').onclick=refresh;$('#analytics-refresh').onclick=refresh;
  $('#sensor-search').oninput=renderSensors;$('#sensor-resource').onchange=renderSensors;$('#order-search').oninput=renderOrders;
  $('#btn-import').onclick=()=>$('#import-file').click();
  $('#import-file').onchange=async e=>{
    const file=e.target.files[0];if(!file)return;e.target.value='';
    if(file.size>1024*1024){error('Файл больше 1 МБ. Разбейте данные на части.');return;}
    try{
      const payload=JSON.parse(await file.text());
      if(!confirm(`Импортировать данные из ${file.name} в локальную БД? Существующие датчики и бригады с теми же кодами обновятся.`))return;
      const res=await api('import',payload);
      toast(`Импорт: ${res.sensors} датчиков, ${res.readings} измерений, ${res.brigades} бригад`);
      await refresh();
    }catch(e){error('Импорт: '+e.message);}
  };
  document.addEventListener('click',async e=>{
    const modal=e.target.closest('[data-modal]');if(modal){const name=modal.dataset.modal;if(name==='sensor')showSensorForm();if(name==='brigade')showBrigadeForm();if(name==='order')showOrderForm();return;}
    const sensor=e.target.closest('[data-sensor]');if(sensor){const s=state.data?.sensors.find(x=>x.sensor_code===sensor.dataset.sensor);if(s)showReading(s);return;}
    const history=e.target.closest('[data-history]');if(history){const o=state.data?.orders.find(x=>String(x.id_order)===history.dataset.history);if(o)showOrderHistory(o);return;}
    const next=e.target.closest('[data-next]');if(next){const o=state.data?.orders.find(x=>String(x.id_order)===next.dataset.next);if(!o)return;if(o.status==='new')showAssign(o);else await mutation('order_transition',{id_order:o.id_order,status:nextStatus[o.status]},false);return;}
    const cancel=e.target.closest('[data-cancel]');if(cancel){if(confirm('Отменить наряд №'+cancel.dataset.cancel+'?'))await mutation('order_transition',{id_order:cancel.dataset.cancel,status:'cancelled'},false);return;}
    if(e.target.matches('[data-close]'))closeModal();
  });
  $('#modal-close').onclick=closeModal;$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))closeModal();});
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#modal').hidden)closeModal();});
  $('#modal').addEventListener('submit',async e=>{
    const form=e.target;if(!form.matches('form'))return;e.preventDefault();
    const v=Object.fromEntries(new FormData(form));
    const a={'sensor-form':'sensor_save','reading-form':'reading_save','brigade-form':'brigade_save','order-form':'order_create','assign-form':'order_transition'}[form.id];
    if(!a)return;
    if(form.id==='reading-form')v.sensor_code=form.dataset.sensor;
    if(form.id==='assign-form'){v.id_order=form.dataset.order;v.status='assigned';}
    // Events and unset optional fields: null, not the empty string.
    if(form.id==='order-form'&&!v.id_event)v.id_event=null;
    if(form.id==='order-form'&&!v.brigade_code)v.brigade_code=null;
    const submit=form.querySelector('[type=submit]');submit.disabled=true;
    try{await mutation(a,v);}finally{if(submit.isConnected)submit.disabled=false;}
  });
  switchView('telemetry');refresh();
})();
