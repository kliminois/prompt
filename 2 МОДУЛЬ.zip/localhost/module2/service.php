<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/db.php';

// Internal library. Only module2/api.php is a public JSON endpoint.
if (PHP_SAPI !== 'cli' && realpath((string) ($_SERVER['SCRIPT_FILENAME'] ?? '')) === realpath(__FILE__)) {
    http_response_code(404);
    exit;
}

function m2_schema_ready($db): bool
{
    return db_scalar($db, "SELECT to_regclass('public.module2_sensors')::text", [], null) !== null
        && db_scalar($db, "SELECT to_regclass('public.module2_orders')::text", [], null) !== null;
}

function m2_require_schema($db): void
{
    if (!m2_schema_ready($db)) {
        throw new DomainException('Таблицы второго модуля пока не созданы. Импортируйте sql/module2_extension.sql через pgAdmin.');
    }
}

function m2_string($value, int $limit, string $field, bool $allowEmpty = false): string
{
    if (!is_string($value)) {
        throw new InvalidArgumentException('Некорректное поле: ' . $field);
    }
    $s = trim($value);
    if ((!$allowEmpty && $s === '') || (function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s)) > $limit) {
        throw new InvalidArgumentException('Недопустимая длина поля: ' . $field);
    }
    return $s;
}

function m2_enum($value, array $values, string $field): string
{
    if (!is_string($value) || !in_array($value, $values, true)) {
        throw new InvalidArgumentException('Недопустимое значение: ' . $field);
    }
    return $value;
}

function m2_positive_int($value, string $field, bool $nullable = false): ?int
{
    if ($nullable && ($value === null || $value === '')) {
        return null;
    }
    if (!is_scalar($value) || !preg_match('/^[1-9][0-9]{0,11}$/D', (string) $value)) {
        throw new InvalidArgumentException('Некорректный идентификатор: ' . $field);
    }
    return (int) $value;
}

function m2_number($value, string $field): float
{
    if ((!is_int($value) && !is_float($value) && !is_string($value)) || !is_numeric($value)) {
        throw new InvalidArgumentException('Некорректное число: ' . $field);
    }
    $n = (float) $value;
    if (!is_finite($n) || abs($n) > 999999999) {
        throw new InvalidArgumentException('Число вне диапазона: ' . $field);
    }
    return $n;
}

function m2_measure_time($value): string
{
    if (!is_string($value) || strlen($value) > 40 || !preg_match('/^\d{4}-\d\d-\d\d[T ]\d\d:\d\d(:\d\d)?(Z|[+-]\d\d:\d\d)$/', $value)) {
        throw new InvalidArgumentException('Время измерения должно содержать часовой пояс (ISO 8601).');
    }
    try {
        $dt = new DateTimeImmutable($value);
        $issues = DateTimeImmutable::getLastErrors();
        if (is_array($issues) && ($issues['warning_count'] > 0 || $issues['error_count'] > 0)) {
            throw new InvalidArgumentException('Некорректная дата измерения.');
        }
        return $dt->format('Y-m-d H:i:sP');
    } catch (Throwable $e) {
        throw new InvalidArgumentException('Некорректная дата измерения.');
    }
}

function m2_validate_object_resource($db, ?int $id, string $resource): void
{
    if ($id === null) {
        return;
    }
    $exists = db_scalar(
        $db,
        'SELECT EXISTS(SELECT 1 FROM public.cache_edifices WHERE id_edifice=$1 AND $2::varchar = ANY(resource_type))',
        [$id, $resource],
        'f'
    );
    if ($exists !== 't') {
        throw new InvalidArgumentException('Объект не найден или не использует выбранный ресурс.');
    }
}

function m2_sensor_upsert($db, array $v): void
{
    $code = m2_string($v['sensor_code'] ?? null, 64, 'sensor_code');
    $obj = m2_positive_int($v['id_edifice'] ?? null, 'id_edifice', true);
    $resource = m2_enum($v['resource_type'] ?? null, ['water', 'energy'], 'resource_type');
    $type = m2_enum($v['sensor_type'] ?? null, ['pressure', 'flow', 'voltage', 'current', 'temperature'], 'sensor_type');
    $name = m2_string($v['display_name'] ?? null, 120, 'display_name');
    $unit = m2_string($v['unit'] ?? null, 24, 'unit');
    $min = m2_number($v['min_value'] ?? null, 'min_value');
    $max = m2_number($v['max_value'] ?? null, 'max_value');
    if ($max <= $min) {
        throw new InvalidArgumentException('Верхний порог должен быть больше нижнего.');
    }
    m2_validate_object_resource($db, $obj, $resource);
    db_exec($db, 'INSERT INTO public.module2_sensors
        (sensor_code,id_edifice,resource_type,sensor_type,display_name,unit,min_value,max_value)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        ON CONFLICT(sensor_code) DO UPDATE SET id_edifice=EXCLUDED.id_edifice,
          resource_type=EXCLUDED.resource_type,sensor_type=EXCLUDED.sensor_type,
          display_name=EXCLUDED.display_name,unit=EXCLUDED.unit,
          min_value=EXCLUDED.min_value,max_value=EXCLUDED.max_value,updated_at=now()',
        [$code,$obj,$resource,$type,$name,$unit,$min,$max]);
}

function m2_reading_upsert($db, array $v, string $source = 'manual'): void
{
    $code = m2_string($v['sensor_code'] ?? null, 64, 'sensor_code');
    $value = m2_number($v['reading'] ?? null, 'reading');
    $at = m2_measure_time($v['measured_at'] ?? null);
    if (db_scalar($db, 'SELECT 1 FROM public.module2_sensors WHERE sensor_code=$1', [$code]) === null) {
        throw new InvalidArgumentException('Датчик ' . $code . ' не найден.');
    }
    db_exec($db, 'INSERT INTO public.module2_readings(sensor_code,measured_at,reading,source)
       VALUES ($1,$2,$3,$4) ON CONFLICT(sensor_code,measured_at)
       DO UPDATE SET reading=EXCLUDED.reading,source=EXCLUDED.source,imported_at=now()',
        [$code,$at,$value,$source]);
}

function m2_brigade_upsert($db, array $v): void
{
    $code = m2_string($v['brigade_code'] ?? null, 64, 'brigade_code');
    $name = m2_string($v['name'] ?? null, 120, 'name');
    $scope = m2_enum($v['resource_scope'] ?? null, ['water','energy','both'], 'resource_scope');
    $members = m2_positive_int($v['members'] ?? 1, 'members');
    if ($members > 1000) {
        throw new InvalidArgumentException('Размер бригады вне допустимого диапазона.');
    }
    $contact = m2_string($v['contact'] ?? '', 120, 'contact', true);
    db_exec($db, 'INSERT INTO public.module2_brigades(brigade_code,name,resource_scope,members,contact)
       VALUES($1,$2,$3,$4,$5) ON CONFLICT(brigade_code) DO UPDATE SET name=EXCLUDED.name,
       resource_scope=EXCLUDED.resource_scope,members=EXCLUDED.members,contact=EXCLUDED.contact,
       updated_at=now()', [$code,$name,$scope,$members,$contact]);
}

function m2_check_brigade($db, ?string $code, string $resource): void
{
    if ($code === null) {
        return;
    }
    $row = db_one($db, 'SELECT resource_scope,is_active FROM public.module2_brigades WHERE brigade_code=$1', [$code]);
    if (!$row || $row['is_active'] !== 't' || ($row['resource_scope'] !== 'both' && $row['resource_scope'] !== $resource)) {
        throw new InvalidArgumentException('Бригада не найдена, отключена или не подходит для ресурса.');
    }
}

function m2_check_event($db, ?int $event, ?int $object, string $resource): void
{
    if ($event === null) {
        return;
    }
    $row = db_one($db, 'SELECT id_edifice,resource_type FROM public.cache_events WHERE id_event=$1', [$event]);
    if (!$row || (int) $row['id_edifice'] !== $object || $row['resource_type'] !== $resource) {
        throw new InvalidArgumentException('Событие не соответствует выбранному объекту и ресурсу.');
    }
}

function m2_order_create($db, array $v): int
{
    $object = m2_positive_int($v['id_edifice'] ?? null, 'id_edifice');
    $res = m2_enum($v['resource_type'] ?? null, ['water','energy'], 'resource_type');
    $event = m2_positive_int($v['id_event'] ?? null, 'id_event', true);
    $title = m2_string($v['title'] ?? null, 200, 'title');
    $note = m2_string($v['note'] ?? '', 2000, 'note', true);
    $priority = m2_positive_int($v['priority'] ?? 2, 'priority');
    if ($priority > 3) throw new InvalidArgumentException('Приоритет: от 1 до 3.');
    $brigade = !empty($v['brigade_code']) ? m2_string($v['brigade_code'], 64, 'brigade_code') : null;
    m2_validate_object_resource($db, $object, $res);
    m2_check_event($db, $event, $object, $res);
    m2_check_brigade($db, $brigade, $res);
    $status = $brigade ? 'assigned' : 'new';
    $row = db_one($db, 'INSERT INTO public.module2_orders
      (id_edifice,id_event,resource_type,title,priority,note,brigade_code,status)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id_order',
      [$object,$event,$res,$title,$priority,$note,$brigade,$status]);
    $id = (int) $row['id_order'];
    db_exec($db, 'INSERT INTO public.module2_order_history(id_order,to_status,description) VALUES($1,$2,$3)',
      [$id,$status,'Создание наряда']);
    return $id;
}

function m2_order_transition($db, array $v): void
{
    $id = m2_positive_int($v['id_order'] ?? null, 'id_order');
    $next = m2_enum($v['status'] ?? null, ['assigned','working','done','cancelled'], 'status');
    $row = db_one($db, 'SELECT * FROM public.module2_orders WHERE id_order=$1 FOR UPDATE', [$id]);
    if (!$row) throw new InvalidArgumentException('Наряд не найден.');
    $valid = ['new'=>['assigned','cancelled'], 'assigned'=>['working','cancelled'],
              'working'=>['done','cancelled'], 'done'=>[], 'cancelled'=>[]];
    if (!in_array($next, $valid[$row['status']], true)) {
        throw new InvalidArgumentException('Недопустимый переход статуса ' . $row['status'] . ' → ' . $next);
    }
    $brigade = $row['brigade_code'];
    if ($next === 'assigned') {
        $brigade = m2_string($v['brigade_code'] ?? '', 64, 'brigade_code');
        m2_check_brigade($db, $brigade, $row['resource_type']);
    }
    if ($next === 'working' && !$brigade) {
        throw new InvalidArgumentException('Для начала работ назначьте бригаду.');
    }
    db_exec($db, "UPDATE public.module2_orders SET status=$2,brigade_code=$3,updated_at=now(),
       started_at=CASE WHEN $2='working' THEN now() ELSE started_at END,
       finished_at=CASE WHEN $2 IN ('done','cancelled') THEN now() ELSE finished_at END
       WHERE id_order=$1", [$id,$next,$brigade]);
    db_exec($db, 'INSERT INTO public.module2_order_history(id_order,from_status,to_status,description)
       VALUES($1,$2,$3,$4)', [$id,$row['status'],$next,'Изменение статуса пользователем']);
    // Намеренно НЕ меняем cache_events: первое конкурсное задание заморожено.
}

function m2_import($db, array $payload): array
{
    foreach (['sensors','readings','brigades'] as $section) {
        if (isset($payload[$section]) && (!is_array($payload[$section]) || count($payload[$section]) > 500 || array_values($payload[$section]) !== $payload[$section])) {
            throw new InvalidArgumentException('Раздел ' . $section . ': ожидается массив не более 500 элементов.');
        }
    }
    $counts=['sensors'=>0,'readings'=>0,'brigades'=>0];
    foreach ($payload['sensors'] ?? [] as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Неверный формат датчика.');
        m2_sensor_upsert($db,$row); $counts['sensors']++;
    }
    foreach ($payload['brigades'] ?? [] as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Неверный формат бригады.');
        m2_brigade_upsert($db,$row); $counts['brigades']++;
    }
    foreach ($payload['readings'] ?? [] as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Неверный формат измерения.');
        m2_reading_upsert($db,$row,'import'); $counts['readings']++;
    }
    db_exec($db, 'INSERT INTO public.module2_import_runs(source_type,sensors_count,readings_count,brigades_count)
       VALUES($1,$2,$3,$4)', ['json',$counts['sensors'],$counts['readings'],$counts['brigades']]);
    return $counts;
}

function m2_snapshot($db): array
{
    $objects=db_all($db, 'SELECT id_edifice,name,district,array_to_json(resource_type) AS resources
       FROM public.cache_edifices ORDER BY name LIMIT 10000');
    $events=db_all($db, 'SELECT e.id_event,e.id_edifice,e.resource_type,
       to_char(e.occurred_at,\'YYYY-MM-DD HH24:MI:SS\') occurred_at,s.name AS status
       FROM public.cache_events e JOIN public.cache_event_statuses s ON s.id_status=e.id_status
       ORDER BY e.occurred_at DESC LIMIT 500');
    $sensors=db_all($db, 'SELECT s.sensor_code,s.id_edifice,s.resource_type,s.sensor_type,s.display_name,s.unit,
       s.min_value,s.max_value,s.is_active,o.name AS object_name,
       r.reading,r.measured_at
       FROM public.module2_sensors s LEFT JOIN public.cache_edifices o ON o.id_edifice=s.id_edifice
       LEFT JOIN LATERAL (SELECT reading,to_char(measured_at AT TIME ZONE \'Europe/Moscow\',\'YYYY-MM-DD HH24:MI:SS\') measured_at
       FROM public.module2_readings r WHERE r.sensor_code=s.sensor_code
       ORDER BY r.measured_at DESC LIMIT 1) AS r ON true
       ORDER BY s.sensor_code LIMIT 1000');
    $brigades=db_all($db, 'SELECT b.*,(SELECT COUNT(*) FROM public.module2_orders r WHERE r.brigade_code=b.brigade_code
       AND r.status IN(\'assigned\',\'working\'))::int active_orders FROM public.module2_brigades b ORDER BY b.name LIMIT 500');
    $orders=db_all($db, 'SELECT p.*,o.name AS object_name,b.name AS brigade_name,
        to_char(p.created_at AT TIME ZONE \'Europe/Moscow\',\'YYYY-MM-DD HH24:MI:SS\') created_fmt,
        to_char(p.started_at AT TIME ZONE \'Europe/Moscow\',\'YYYY-MM-DD HH24:MI:SS\') started_fmt,
        to_char(p.finished_at AT TIME ZONE \'Europe/Moscow\',\'YYYY-MM-DD HH24:MI:SS\') finished_fmt
        FROM public.module2_orders p LEFT JOIN public.cache_edifices o ON o.id_edifice=p.id_edifice
        LEFT JOIN public.module2_brigades b ON b.brigade_code=p.brigade_code
        ORDER BY CASE p.status WHEN \'working\' THEN 1 WHEN \'assigned\' THEN 2 WHEN \'new\' THEN 3 ELSE 4 END,
          p.priority,p.created_at DESC LIMIT 2000');
    $history=db_all($db, 'SELECT id_order,from_status,to_status,description,
       to_char(changed_at AT TIME ZONE \'Europe/Moscow\',\'YYYY-MM-DD HH24:MI:SS\') changed_at
       FROM public.module2_order_history ORDER BY changed_at DESC LIMIT 3000');
    $byDistrict=db_all($db,'SELECT COALESCE(o.district,\'Без района\') district,COUNT(*)::int total
       FROM public.cache_edifices o GROUP BY o.district ORDER BY total DESC LIMIT 100');
    $byResource=db_all($db, 'SELECT resource_type, COUNT(*)::int total FROM public.cache_events GROUP BY resource_type');
    $trend=db_all($db, 'SELECT to_char(occurred_at::date,\'YYYY-MM-DD\') day,COUNT(*)::int total
        FROM public.cache_events GROUP BY occurred_at::date ORDER BY occurred_at::date DESC LIMIT 30');
    return compact('objects','events','sensors','brigades','orders','history','byDistrict','byResource','trend');
}
