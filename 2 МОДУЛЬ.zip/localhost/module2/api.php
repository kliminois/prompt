<?php

declare(strict_types=1);
require_once __DIR__ . '/service.php';
require_once __DIR__ . '/../lib/xlsx.php';

app_session();
header('Cache-Control: no-store');
$action = (string) ($_GET['action'] ?? 'snapshot');
$method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');

try {
    $db = db_local();
    m2_require_schema($db);
    if ($method === 'GET') {
        if ($action === 'snapshot') {
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['ok'=>true,'data'=>m2_snapshot($db)],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR);
            exit;
        }
        if ($action === 'readings') {
            $code=m2_string($_GET['sensor_code']??null,64,'sensor_code');
            $rows=db_all($db,'SELECT to_char(measured_at AT TIME ZONE \'Europe/Moscow\',\'YYYY-MM-DD HH24:MI:SS\') measured_at,
              reading,source FROM public.module2_readings WHERE sensor_code=$1 ORDER BY measured_at DESC LIMIT 120',[$code]);
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['ok'=>true,'data'=>array_reverse($rows)],JSON_UNESCAPED_UNICODE);
            exit;
        }
        if ($action === 'export') {
            $data=m2_snapshot($db);
            $writer=new XlsxWriter();
            $sensorRows=[['Датчик','Объект','Ресурс','Показатель','Единицы','Мин','Макс','Показание','Время']];
            foreach ($data['sensors'] as $s) $sensorRows[]=[$s['sensor_code'],$s['object_name'],$s['resource_type'],$s['display_name'],$s['unit'],(float)$s['min_value'],(float)$s['max_value'],$s['reading']===null?'':(float)$s['reading'],$s['measured_at']];
            $orderRows=[['Наряд','Объект','Ресурс','Название','Приоритет','Статус','Бригада','Событие','Создан','Начат','Завершён']];
            foreach ($data['orders'] as $o) $orderRows[]= [(int)$o['id_order'],$o['object_name'],$o['resource_type'],$o['title'],(int)$o['priority'],$o['status'],$o['brigade_name'], $o['id_event'], $o['created_fmt'], $o['started_fmt'], $o['finished_fmt']];
            $writer->addSheet('Датчики',$sensorRows);$writer->addSheet('Наряды',$orderRows);
            $writer->output('panorama_module2_'.date('Ymd_His').'.xlsx');
            exit;
        }
        throw new InvalidArgumentException('Неизвестная операция чтения.');
    }
    if ($method !== 'POST') { http_response_code(405);throw new DomainException('Операция не поддерживается.'); }
    if (!csrf_verify($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) {
        http_response_code(403);throw new DomainException('Неверный токен CSRF. Перезагрузите страницу.');
    }
    $raw=file_get_contents('php://input');
    if ($raw===false || strlen($raw)>1024*1024) {http_response_code(413);throw new InvalidArgumentException('Слишком большой запрос (не более 1 МБ).');}
    $v=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
    if (!is_array($v)) throw new InvalidArgumentException('Ожидается объект JSON.');
    db_begin($db);
    try {
        $result=[];
        switch ($action) {
            case 'sensor_save': m2_sensor_upsert($db,$v);break;
            case 'reading_save':
                if (empty($v['measured_at'])) $v['measured_at']=gmdate('Y-m-d\TH:i:s\Z');
                m2_reading_upsert($db,$v);break;
            case 'brigade_save':m2_brigade_upsert($db,$v);break;
            case 'order_create':$result=['id_order'=>m2_order_create($db,$v)];break;
            case 'order_transition':m2_order_transition($db,$v);break;
            case 'import':$result=m2_import($db,$v);break;
            default: throw new InvalidArgumentException('Неизвестная операция изменения.');
        }
        db_commit($db);
    } catch(Throwable $e) {db_rollback($db);throw $e;}
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['ok'=>true,'data'=>$result],JSON_UNESCAPED_UNICODE);
} catch (InvalidArgumentException | DomainException | JsonException $e) {
    if (http_response_code()<400) http_response_code(422);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
} catch(Throwable $e) {
    error_log('[panorama-module2] '.$e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['ok'=>false,'error'=>'Ошибка сервера. Проверьте схему базы и журнал PHP.'],JSON_UNESCAPED_UNICODE);
}
