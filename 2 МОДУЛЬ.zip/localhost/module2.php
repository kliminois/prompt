<?php

declare(strict_types=1);
require_once __DIR__ . '/lib/bootstrap.php';
app_session();
$csrf=htmlspecialchars(csrf_token(),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?= $csrf ?>">
<title>Панорама инфраструктуры · Подготовительные модули</title>
<link rel="stylesheet" href="module2/module2.css">
<script src="module2/module2.js" defer></script>
</head>
<body>
<header class="topbar">
  <div class="brand"><a class="back" href="index.php" title="Первый модуль">←</a><div class="mark">P</div><div><div class="kicker">ЦИФРОВОЙ КОНТУР УПРАВЛЕНИЯ</div><strong>Панорама <span>инфраструктуры</span></strong></div></div>
  <nav class="mainnav" aria-label="Разделы"><button data-view="telemetry" class="navtab selected">Датчики</button><button data-view="orders" class="navtab">Ремонтные наряды</button><button data-view="analytics" class="navtab">Аналитика</button></nav>
  <span class="mode" title="Работает на локальной PostgreSQL">● Локальная база</span>
</header>
<main>
 <section class="page-head"><div><div class="kicker">ПОДГОТОВКА К МОДУЛЮ 2 · НЕ ЧАСТЬ ОЦЕНЕННОГО МОДУЛЯ 1</div><h1 id="page-title">Телеметрия инфраструктуры</h1><p id="page-subtitle">Данные из локальной PostgreSQL. Измерения вручную или через импорт файла.</p></div>
 <div class="head-actions"><button class="btn btn-secondary" id="btn-refresh">↻ Обновить</button><a class="btn btn-secondary" href="module2/api.php?action=export">↓ XLSX</a><button class="btn btn-primary" id="btn-import">Импорт JSON</button><input type="file" accept=".json,application/json" id="import-file" hidden></div></section>
 <section id="alert" class="alert" hidden role="alert"></section>
 <section class="metrics" id="metrics" aria-label="Показатели"></section>
 <section id="view-telemetry" class="view">
   <div class="section-head"><div><h2>Реестр датчиков</h2><p>Пороговые значения и последнее фактическое измерение</p></div><div class="actions"><input type="search" id="sensor-search" placeholder="Датчик или объект" aria-label="Поиск датчика"><select id="sensor-resource" aria-label="Ресурс"><option value="all">Все ресурсы</option><option value="water">Вода</option><option value="energy">Электричество</option></select><button class="btn btn-primary" data-modal="sensor">+ Датчик</button></div></div>
   <div id="sensors" class="sensor-grid" aria-live="polite"></div>
   <div id="sensor-empty" class="empty" hidden>Датчиков пока нет. Создайте датчик или загрузите JSON с данными.</div>
   <div class="hint">Состояния рассчитываются по сохранённым показаниям. Никакой генерации случайных аварий или ложной синхронизации нет. При отсутствии показаний датчик отображается без состояния «Норма».</div>
 </section>
 <section id="view-orders" class="view" hidden>
   <div class="section-head"><div><h2>Ремонтные наряды</h2><p>Учёт задач, назначение бригад и журнал изменения статусов</p></div><div class="actions"><input type="search" id="order-search" placeholder="Номер, объект или название" aria-label="Поиск наряда"><button class="btn btn-secondary" data-modal="brigade">+ Бригада</button><button class="btn btn-primary" data-modal="order">+ Наряд</button></div></div>
   <div class="brigades" id="brigades"></div>
   <div id="kanban" class="kanban"></div>
   <div class="hint">Наряды — самостоятельная подсистема. Смена статуса не изменяет аварии первого модуля, чтобы не исказить конкурсные данные.</div>
 </section>
 <section id="view-analytics" class="view" hidden>
   <div class="section-head"><div><h2>Аналитика и отчётность</h2><p>Показатели строятся из локальных таблиц без вымышленных значений</p></div><div class="actions"><button class="btn btn-secondary" id="analytics-refresh">↻ Пересчитать</button></div></div>
   <div id="analytics" class="analytics-grid"></div>
   <div class="hint">Исторические данные первого модуля содержат текущее состояние события, но не полную историю его переходов. Поэтому MTTR аварий по ним достоверно не вычисляется; отдельно выводится время работ по завершённым нарядам.</div>
 </section>
</main>
<div class="overlay" id="modal" hidden><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="dialog-head"><h2 id="modal-title">Новая запись</h2><button class="close" id="modal-close" type="button" aria-label="Закрыть">×</button></div><div id="modal-content"></div></div></div>
<div id="toast" class="toast" role="status" aria-live="polite" hidden></div>
<footer>Панорама инфраструктуры · Модуль 2: подготовительная версия · Данные хранятся на вашем сервере PostgreSQL 14</footer>
</body></html>
