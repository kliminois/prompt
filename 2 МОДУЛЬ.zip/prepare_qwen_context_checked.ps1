# Rebuilds a Qwen handoff and verifies that index.php is included.
# Windows PowerShell 5.1 / PowerShell 7. Does not modify source code.
param(
    [string]$ProjectRoot = ''
)
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    # Prefer the directory containing this script, not PowerShell's current directory.
    $ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path.TrimEnd('\', '/')
$IndexFile = Join-Path $ProjectRoot 'index.php'
if (-not (Test-Path -LiteralPath $IndexFile -PathType Leaf)) {
    throw "index.php was not found in: $ProjectRoot . Put this script next to index.php or pass -ProjectRoot explicitly."
}

$docs = [Environment]::GetFolderPath('MyDocuments')
if ([string]::IsNullOrWhiteSpace($docs)) { $docs = $env:TEMP }
$outDir = Join-Path $docs ('QwenContext_' + [System.IO.Path]::GetFileName($ProjectRoot))
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

$skipDirs = @('AI_CONTEXT','.git','node_modules','vendor','.vscode','tests','backup','backups','old','temp','tmp','logs','cache')
$skipFiles = @('config.php','database.php','.env','.env.local','dump.sql','source.zip')
$extensions = @('.php','.js','.css','.html','.htm')

function RelPath([System.IO.FileInfo]$file) {
    return $file.FullName.Substring($ProjectRoot.Length).TrimStart([char[]]@('\','/'))
}

$included = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
foreach ($f in (Get-ChildItem -LiteralPath $ProjectRoot -File -Recurse | Sort-Object FullName)) {
    $rel = RelPath $f
    $pieces = $rel -split '[\\/]'
    $excludedFolder = $false
    if ($pieces.Length -gt 1) {
        for ($i = 0; $i -lt $pieces.Length - 1; $i++) {
            if ($skipDirs -contains $pieces[$i]) { $excludedFolder = $true; break }
        }
    }
    if ($excludedFolder) { continue }
    if ($skipFiles -contains $f.Name) { continue }
    if ($f.Name -match '(?i)(secret|credential|password|token|\.min\.)') { continue }
    if ($extensions -notcontains $f.Extension.ToLowerInvariant()) { continue }
    $included.Add($f)
}

$front = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
$back = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
foreach ($f in $included) {
    $ext = $f.Extension.ToLowerInvariant()
    if (($ext -in @('.js','.css','.html','.htm')) -or ($f.Name -ieq 'index.php') -or ($f.Name -ieq 'module2.php')) {
        $front.Add($f)
    } else {
        $back.Add($f)
    }
}
if ((@($front | Where-Object { (RelPath $_) -ieq 'index.php' }).Count) -ne 1) {
    throw "Internal error: index.php was not included in the frontend file list. Root=$ProjectRoot"
}

function Bundle([string]$name, [object]$source, [string]$intro) {
    $buf = New-Object System.Text.StringBuilder
    [void]$buf.AppendLine('PROJECT SOURCE BUNDLE')
    [void]$buf.AppendLine($intro)
    [void]$buf.AppendLine('Each BEGIN FILE / END FILE block is one original source file.')
    [void]$buf.AppendLine('')
    foreach ($f in $source) {
        $rel = RelPath $f
        [void]$buf.AppendLine('')
        [void]$buf.AppendLine('==================== BEGIN FILE: ' + $rel + ' ====================')
        [void]$buf.AppendLine([System.IO.File]::ReadAllText($f.FullName))
        [void]$buf.AppendLine('==================== END FILE: ' + $rel + ' ====================')
    }
    $dest = Join-Path $outDir $name
    [System.IO.File]::WriteAllText($dest, $buf.ToString(), (New-Object System.Text.UTF8Encoding($false)))
    Write-Host ('Saved ' + $name + ': ' + $source.Count + ' files')
}

$map = New-Object System.Text.StringBuilder
[void]$map.AppendLine('PROJECT STRUCTURE / PHP 7.4 + PostgreSQL 14')
[void]$map.AppendLine('Source root: ' + $ProjectRoot)
[void]$map.AppendLine('Module 1 already evaluated. Add module 2 without rewriting existing module 1.')
[void]$map.AppendLine('config.php, .env, SQL dumps and secrets are excluded from source bundles.')
[void]$map.AppendLine('')
foreach ($f in $included) { [void]$map.AppendLine((RelPath $f) + ' [' + $f.Length + ' bytes]') }
[System.IO.File]::WriteAllText((Join-Path $outDir '01_PROJECT_MAP.txt'),$map.ToString(),(New-Object System.Text.UTF8Encoding($false)))
Bundle '02_FRONTEND_CODE.txt' $front 'Frontend source including index.php and module2.php.'
Bundle '03_BACKEND_CODE.txt' $back 'Backend PHP source (config and credentials excluded).'

$frontendText = [System.IO.File]::ReadAllText((Join-Path $outDir '02_FRONTEND_CODE.txt'))
if (-not $frontendText.Contains('BEGIN FILE: index.php ')) {
    throw "Bundle verification failed: index.php is missing from 02_FRONTEND_CODE.txt"
}
Write-Host 'CHECK PASSED: index.php exists in 02_FRONTEND_CODE.txt' -ForegroundColor Green
Write-Host ('Output folder: ' + $outDir)
Write-Host 'Review bundles for hardcoded secrets before sending to any AI service.' -ForegroundColor Yellow
