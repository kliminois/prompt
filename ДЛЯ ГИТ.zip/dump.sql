--
-- PostgreSQL database dump
--

\restrict 5EXD64u88P9r1hIA4bdS7D7lMS3MrJ6vOd4JGcadrHC2Yn3mz3kU8SPZiDo6VjT

-- Dumped from database version 14.5
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache_edifice_dependencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_edifice_dependencies (
    id_dependence integer NOT NULL,
    resource_type character varying(15) NOT NULL,
    id_edifice_source integer NOT NULL,
    id_edifice_dependent integer NOT NULL,
    CONSTRAINT cache_dependencies_check CHECK ((id_edifice_source <> id_edifice_dependent))
);


ALTER TABLE public.cache_edifice_dependencies OWNER TO postgres;

--
-- Name: cache_edifices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_edifices (
    id_edifice integer NOT NULL,
    name character varying(120) NOT NULL,
    resource_type character varying(15)[] NOT NULL,
    district character varying(50),
    street character varying(80),
    house_number character varying(10),
    CONSTRAINT cache_edifices_resource_type_check CHECK ((resource_type <@ ARRAY['water'::character varying, 'energy'::character varying]))
);


ALTER TABLE public.cache_edifices OWNER TO postgres;

--
-- Name: cache_event_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_event_statuses (
    id_status smallint NOT NULL,
    name character varying(20) NOT NULL
);


ALTER TABLE public.cache_event_statuses OWNER TO postgres;

--
-- Name: cache_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_events (
    id_event integer NOT NULL,
    id_edifice integer NOT NULL,
    resource_type character varying(15) NOT NULL,
    occurred_at timestamp without time zone NOT NULL,
    id_status smallint NOT NULL
);


ALTER TABLE public.cache_events OWNER TO postgres;

--
-- Name: cache_layout_edges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_layout_edges (
    id_dependence integer NOT NULL,
    control_points jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cache_layout_edges OWNER TO postgres;

--
-- Name: cache_layout_nodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_layout_nodes (
    id_edifice integer NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cache_layout_nodes OWNER TO postgres;

--
-- Name: cache_sync_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_sync_state (
    id smallint DEFAULT 1 NOT NULL,
    last_sync_at timestamp without time zone,
    last_status character varying(20),
    last_message text,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT cache_sync_state_id_check CHECK ((id = 1))
);


ALTER TABLE public.cache_sync_state OWNER TO postgres;

--
-- Data for Name: cache_edifice_dependencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_edifice_dependencies (id_dependence, resource_type, id_edifice_source, id_edifice_dependent) FROM stdin;
900001	energy	1002	1001
900002	energy	1002	1007
900003	energy	1002	1027
900004	energy	1002	1041
900005	water	1001	1003
900006	energy	1007	1003
900008	water	1001	1017
900009	energy	1007	1008
900010	energy	1007	1011
900011	energy	1008	1024
900012	energy	1008	1009
900013	energy	1008	1012
900014	water	1003	1005
900015	energy	1007	1005
900016	water	1003	1006
900017	water	1003	1009
900018	water	1003	1012
900019	water	1004	1019
900020	water	1004	1026
900021	water	1004	1039
900022	water	1005	1010
900024	water	1005	1028
900025	water	1006	1014
900026	water	1006	1015
900027	energy	1016	1015
900028	energy	1011	1016
900029	water	1009	1018
900030	energy	1011	1018
900031	energy	1011	1020
900032	water	1001	1021
900033	energy	1016	1021
900034	water	1006	1022
900035	energy	1016	1022
900036	water	1003	1023
900037	energy	1024	1023
900038	water	1006	1025
900039	water	1019	1029
900040	energy	1031	1029
900041	water	1019	1030
900042	energy	1011	1030
900043	water	1019	1032
900044	energy	1016	1032
900045	water	1025	1033
900046	energy	1016	1033
900047	water	1028	1034
900048	energy	1024	1034
900049	water	1028	1035
900050	energy	1024	1035
900051	energy	1024	1036
900052	water	1003	1037
900053	energy	1027	1037
900054	water	1028	1038
900055	water	1028	1042
900056	energy	1041	1042
900057	water	1003	1043
900058	energy	1027	1043
900059	water	1028	1044
900060	water	1044	1045
900061	water	1045	1046
900062	water	1013	1047
900063	energy	1048	1047
900064	water	1019	1049
900065	energy	1027	1049
900066	water	1010	1050
900067	energy	1008	1050
900068	water	1013	1051
900069	energy	1027	1051
900070	water	1025	1052
900071	energy	1031	1052
900072	water	1019	1053
900073	energy	1031	1053
900074	water	1028	1054
900075	energy	1040	1054
900077	water	1044	1056
900078	energy	1040	1057
900079	water	1019	1058
900080	energy	1031	1058
900081	energy	1040	1059
900082	water	1038	1060
900083	energy	1040	1061
900084	energy	1040	1048
900085	energy	1027	1031
900087	energy	1007	1006
900088	energy	1007	1017
900089	energy	1008	1028
900090	energy	1027	1044
900091	energy	1040	1056
900092	energy	1040	1060
900093	water	1028	1036
900094	energy	1002	1059
900095	energy	1002	1061
900096	water	1004	1055
900097	water	1013	1055
\.


--
-- Data for Name: cache_edifices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_edifices (id_edifice, name, resource_type, district, street, house_number) FROM stdin;
1001	Водоочистная станция «Северная»	{water,energy}	Центральный	Центральная	1
1002	Электростанция «Центральная»	{energy}	Заводской	Энергетиков	1
1003	Главная насосная станция «Речная»	{water,energy}	Центральный	Водопроводная	12
1004	Резервуар чистой воды № 1	{water}	Лесной	Лесная	4
1005	Насосная станция № 2	{water,energy}	Заводской	Заводская	10а
1006	Водопроводный узел «Центральный»	{water,energy}	Центральный	Набережная	8
1007	Подстанция 110/10 кВ «Северная»	{energy}	Заводской	Энергетиков	5
1008	Распределительный пункт «Заводской»	{energy}	Заводской	Промышленная	12
1009	Насосная станция «Лесная»	{water,energy}	Лесной	Садовая	16
1010	Водонапорная башня «Восточная»	{water}	Восточный	Восточная	10б
1011	Трансформаторная подстанция № 12	{energy}	Центральный	Советская	24
1012	Канализационная насосная станция «Окружная»	{water,energy}	Окружной	Объездная	7
1013	Резервуар «Восточный»	{water}	Восточный	Речная	3
1014	Узел учёта воды № 3	{water}	Центральный	Пушкина	18
1015	Тепловой пункт «Заводской»	{water,energy}	Заводской	Теплотехническая	6
1016	Подстанция 35/10 кВ «Центральная»	{energy}	Центральный	Гагарина	32
1017	Насосная станция скважинного водозабора № 1	{water,energy}	Лесной	Родниковая	2
1018	Насосная станция «Южная»	{water,energy}	Окружной	Южная	11
1019	Водопроводная камера № 7	{water}	Лесной	Лесная	27
1020	Электрощитовая городской поликлиники	{energy}	Центральный	Клиническая	9
1021	Очистные сооружения «Восточные»	{water,energy}	Восточный	Восточная	22
1022	Котельная № 3	{water,energy}	Заводской	Котельная	3
1023	Насосная станция «Заводская»	{water,energy}	Заводской	Заводская	18
1024	Подстанция «Промышленная»	{energy}	Заводской	Промышленная	30
1025	Распределительная водопроводная камера № 4	{water}	Центральный	Набережная	10в
1026	Резервуар «Лесной»	{water}	Лесной	Сосновая	14
1027	Подстанция «Восточная»	{energy}	Восточный	Энергетиков	14
1028	Водопроводный узел «Окружной»	{water,energy}	Окружной	Объездная	19
1029	Пожарное депо № 1	{water,energy}	Окружной	Пожарная	1
1030	Городская больница, корпус № 1	{water,energy}	Центральный	Больничная	5
1031	Подстанция «Лесная»	{energy}	Лесной	Северная	8
1032	Средняя школа № 7	{water,energy}	Восточный	Школьная	7
1033	Детский сад № 14	{water,energy}	Восточный	Детская	14
1034	Завод «МеталлПром»	{water,energy}	Заводской	Металлургов	2
1035	Производственный цех № 1	{water,energy}	Заводской	Цеховая	11
1036	Складской комплекс № 2	{water,energy}	Заводской	Складская	4
1037	Насосная станция «Окружная-2»	{water,energy}	Окружной	Окружная	25
1038	Водопроводная камера № 9	{water}	Окружной	Водопроводная	29
1039	Резервуар «Центральный-2»	{water}	Лесной	Лесная	41
1040	Электропункт «Восток»	{energy}	Восточный	Восточная	31
1041	Подстанция «Вокзальная»	{energy}	Центральный	Вокзальная	2
1042	Железнодорожный вокзал	{water,energy}	Центральный	Привокзальная	1
1043	Канализационная насосная станция № 5	{water,energy}	Окружной	Канализационная	5
1044	Блок доочистки воды № 2	{water,energy}	Окружной	Очистная	3
1045	Поливочный узел городского парка	{water}	Центральный	Парковая	7
1046	Парк «Сосновый»	{water}	Центральный	Парковая	10
1047	Спортивный комплекс «Олимп»	{water,energy}	Восточный	Спортивная	2
1048	Подстанция «Спортивная»	{energy}	Восточный	Спортивная	12
1049	Жилой квартал «Речной»	{water,energy}	Лесной	Речная	10г
1050	Жилой квартал «Северный»	{water,energy}	Лесной	Северная	10а
1051	Микрорайон «Восточный»	{water,energy}	Восточный	Восточная	10в
1052	Жилой дом № 18	{water,energy}	Заводской	Строителей	10б
1053	Жилой дом № 24	{water,energy}	Лесной	Садовая	10в
1054	Торговый центр «Универсам»	{water,energy}	Окружной	Объездная	10г
1055	Пожарный гидрант № 21	{water}	Окружной	Водопроводная	31
1056	Станция полива «Южная»	{water,energy}	Восточный	Полевая	17
1057	Трансформаторная будка № 6	{energy}	Заводской	Энергетиков	18
1058	Жилой дом № 31	{water,energy}	Лесной	Молодёжная	31
1059	Пункт связи «Окружной»	{energy}	Окружной	Связистов	4
1060	Насосный шкаф № 2	{water,energy}	Центральный	Водопроводная	39
1061	Опора наружного освещения № 17	{energy}	Восточный	Осветительная	1
\.


--
-- Data for Name: cache_event_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_event_statuses (id_status, name) FROM stdin;
1	Активная авария
2	Ремонтные работы
3	Норма
\.


--
-- Data for Name: cache_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_events (id_event, id_edifice, resource_type, occurred_at, id_status) FROM stdin;
700001	1001	water	2026-09-28 00:00:00	3
700002	1001	energy	2026-09-28 00:00:00	1
700003	1001	water	2026-10-03 22:13:48	1
700004	1001	energy	2026-10-06 20:22:37	2
700005	1001	water	2026-10-09 20:28:01	2
700006	1001	energy	2026-10-15 16:37:39	3
700007	1001	water	2026-10-15 18:42:14	3
700008	1002	energy	2026-09-28 00:00:00	2
700009	1002	energy	2026-09-30 13:44:15	3
700010	1002	energy	2026-10-03 03:20:35	1
700011	1002	energy	2026-10-05 16:56:55	3
700012	1002	energy	2026-10-08 06:23:15	1
700013	1002	energy	2026-10-10 19:59:35	2
700014	1002	energy	2026-10-13 09:35:55	3
700015	1003	water	2026-09-28 00:00:00	1
700016	1003	energy	2026-09-28 00:00:00	2
700017	1003	water	2026-09-29 20:33:15	3
700018	1003	energy	2026-09-30 01:58:49	3
700019	1003	water	2026-10-01 17:06:17	1
700020	1003	energy	2026-10-02 03:49:24	1
700021	1003	water	2026-10-03 13:39:19	2
700022	1003	energy	2026-10-04 05:30:00	3
700023	1003	water	2026-10-05 10:12:21	3
700024	1003	energy	2026-10-06 07:20:35	1
700025	1003	water	2026-10-07 06:45:23	1
700026	1003	energy	2026-10-08 09:11:10	2
700027	1003	water	2026-10-09 03:18:25	3
700028	1003	energy	2026-10-10 11:01:46	3
700029	1003	water	2026-10-10 23:51:27	1
700030	1003	energy	2026-10-12 12:52:21	1
700031	1003	water	2026-10-12 20:24:29	2
700032	1003	energy	2026-10-14 14:42:57	3
700033	1003	water	2026-10-14 16:57:32	3
700034	1003	energy	2026-10-24 09:00:00	1
700035	1004	water	2026-09-28 00:00:00	3
700036	1004	water	2026-10-01 14:00:36	1
700037	1004	water	2026-10-05 04:00:40	3
700038	1004	water	2026-10-08 18:00:44	1
700039	1004	water	2026-10-12 08:00:48	2
700040	1004	water	2026-10-15 22:00:52	3
700041	1005	water	2026-09-28 00:00:00	1
700042	1005	energy	2026-09-28 00:00:00	3
700043	1005	water	2026-10-05 19:32:50	2
700044	1005	energy	2026-10-26 10:00:00	1
700045	1005	water	2026-10-13 15:04:49	3
700046	1005	energy	2026-11-01 18:00:00	2
700047	1006	water	2026-09-28 00:00:00	1
700048	1006	energy	2026-09-28 00:00:00	1
700049	1006	water	2026-10-06 10:05:53	2
700050	1006	energy	2026-10-06 09:07:55	2
700051	1006	water	2026-10-14 20:10:37	3
700052	1006	energy	2026-10-14 17:56:39	3
700053	1007	energy	2026-09-28 00:00:00	2
700054	1007	energy	2026-09-28 23:56:52	3
700055	1007	energy	2026-09-29 23:54:15	1
700056	1007	energy	2026-09-30 23:51:38	3
700057	1007	energy	2026-10-01 23:49:00	1
700058	1007	energy	2026-10-02 23:46:23	2
700059	1007	energy	2026-10-03 23:43:46	3
700060	1007	energy	2026-10-04 23:41:09	1
700061	1007	energy	2026-10-05 23:38:31	3
700062	1007	energy	2026-10-06 23:35:54	1
700063	1007	energy	2026-10-07 23:33:17	2
700064	1007	energy	2026-10-08 23:30:39	3
700065	1007	energy	2026-10-09 23:28:02	1
700066	1007	energy	2026-10-10 23:25:25	3
700067	1007	energy	2026-10-11 23:22:48	1
700068	1007	energy	2026-10-12 23:20:10	2
700069	1007	energy	2026-10-13 23:17:33	3
700070	1007	energy	2026-10-14 23:14:56	1
700071	1007	energy	2026-10-15 23:02:19	3
700072	1007	energy	2026-11-07 08:00:00	1
700073	1008	energy	2026-09-28 00:00:00	3
700074	1008	energy	2026-10-01 03:13:52	1
700075	1008	energy	2026-10-04 06:27:55	3
700076	1008	energy	2026-10-07 09:41:59	1
700077	1008	energy	2026-10-10 12:56:02	2
700078	1008	energy	2026-10-13 16:10:06	3
700079	1009	water	2026-09-28 00:00:00	1
700080	1009	energy	2026-09-28 00:00:00	1
700081	1009	water	2026-10-06 11:45:04	2
700082	1009	energy	2026-10-06 10:37:05	2
700083	1009	water	2026-10-14 23:28:01	3
700084	1009	energy	2026-10-14 21:14:03	3
700085	1010	water	2026-09-28 00:00:00	3
700086	1010	water	2026-10-01 15:21:04	1
700087	1010	water	2026-10-05 06:39:43	3
700088	1010	water	2026-10-08 21:58:22	1
700089	1010	water	2026-10-12 13:17:01	2
700090	1010	water	2026-10-16 04:35:40	3
700091	1011	energy	2026-09-28 00:00:00	3
700092	1011	energy	2026-10-01 03:54:06	1
700093	1011	energy	2026-10-04 07:47:27	3
700094	1011	energy	2026-10-07 11:40:48	1
700095	1011	energy	2026-10-10 15:34:09	2
700096	1011	energy	2026-10-13 19:27:30	3
700097	1012	water	2026-09-28 00:00:00	1
700098	1012	energy	2026-09-28 00:00:00	2
700099	1012	water	2026-09-29 21:41:35	3
700100	1012	energy	2026-09-30 03:05:20	3
700101	1012	water	2026-10-01 19:20:06	1
700102	1012	energy	2026-10-02 06:09:36	1
700103	1012	water	2026-10-03 16:58:37	2
700104	1012	energy	2026-10-04 09:13:51	3
700105	1012	water	2026-10-05 14:37:08	3
700106	1012	energy	2026-10-06 12:18:07	1
700107	1012	water	2026-10-07 12:15:39	1
700108	1012	energy	2026-10-08 15:22:22	2
700109	1012	water	2026-10-09 09:54:10	3
700110	1012	energy	2026-10-10 18:26:38	3
700111	1012	water	2026-10-11 07:32:41	1
700112	1012	energy	2026-10-12 21:30:53	1
700113	1012	water	2026-10-13 05:11:12	2
700114	1012	energy	2026-10-15 00:35:09	3
700115	1012	water	2026-10-15 02:49:44	3
700116	1012	energy	2026-10-27 14:00:00	1
700117	1013	water	2026-09-28 00:00:00	3
700118	1013	water	2026-10-01 16:01:19	1
700119	1013	water	2026-10-05 07:59:15	3
700120	1013	water	2026-10-08 23:57:11	1
700121	1013	water	2026-10-12 15:55:07	2
700122	1013	water	2026-10-16 07:53:04	3
700123	1014	water	2026-09-28 00:00:00	3
700124	1014	water	2026-10-01 05:02:44	1
700125	1014	water	2026-10-04 10:01:46	3
700126	1014	water	2026-10-07 15:00:48	1
700127	1014	water	2026-10-10 19:59:50	2
700128	1014	water	2026-10-14 00:58:52	3
700129	1015	water	2026-09-28 00:00:00	1
700130	1015	energy	2026-09-28 00:00:00	3
700131	1015	water	2026-10-06 15:03:25	2
700132	1015	energy	2026-10-30 13:00:00	1
700133	1015	water	2026-10-15 06:02:49	3
700134	1015	energy	2026-11-05 17:00:00	2
700135	1016	energy	2026-09-28 00:00:00	3
700136	1016	energy	2026-10-01 16:13:10	1
700137	1016	energy	2026-10-05 08:24:00	3
700138	1016	energy	2026-10-09 00:34:50	1
700139	1016	energy	2026-10-12 16:45:40	2
700140	1016	energy	2026-10-16 08:56:30	3
700141	1017	water	2026-09-28 00:00:00	1
700142	1017	energy	2026-09-28 00:00:00	1
700143	1017	water	2026-10-06 02:09:32	2
700144	1017	energy	2026-10-06 01:01:33	2
700145	1017	water	2026-10-14 04:14:25	3
700146	1017	energy	2026-10-14 02:00:27	3
700147	1018	water	2026-09-28 00:00:00	1
700148	1018	energy	2026-09-28 00:00:00	1
700149	1018	water	2026-10-06 16:42:35	2
700150	1018	energy	2026-10-15 07:05:38	3
700151	1018	water	2026-10-15 09:20:13	3
700152	1018	energy	2026-10-30 11:00:00	1
700153	1019	water	2026-09-28 00:00:00	3
700154	1019	water	2026-10-01 17:21:48	1
700155	1019	water	2026-10-05 10:38:19	3
700156	1019	water	2026-10-09 03:54:50	1
700157	1019	water	2026-10-12 21:11:21	2
700158	1019	water	2026-10-16 14:27:52	3
700159	1020	energy	2026-09-28 00:00:00	3
700160	1020	energy	2026-10-01 05:54:50	1
700161	1020	energy	2026-10-04 11:46:03	3
700162	1020	energy	2026-10-07 17:37:16	1
700163	1020	energy	2026-10-10 23:28:29	2
700164	1020	energy	2026-10-14 05:19:42	3
700165	1021	water	2026-09-28 00:00:00	1
700166	1021	energy	2026-09-28 00:00:00	1
700167	1021	water	2026-10-06 18:21:46	2
700168	1021	energy	2026-10-06 17:13:47	2
700169	1021	water	2026-10-15 12:37:37	3
700170	1021	energy	2026-10-15 10:23:39	3
700171	1022	water	2026-09-28 00:00:00	1
700172	1022	energy	2026-09-28 00:00:00	1
700173	1022	water	2026-10-07 08:54:49	2
700174	1022	energy	2026-10-07 07:46:51	2
700175	1022	water	2026-10-16 17:43:25	3
700176	1022	energy	2026-10-16 15:29:27	3
700177	1023	water	2026-09-28 00:00:00	1
700178	1023	energy	2026-09-28 00:00:00	1
700179	1023	water	2026-10-06 05:27:53	2
700180	1023	energy	2026-10-06 04:19:54	2
700181	1023	water	2026-10-14 10:49:13	3
700182	1023	energy	2026-10-14 08:35:15	3
700183	1024	energy	2026-09-28 00:00:00	2
700184	1024	energy	2026-09-28 23:30:46	3
700185	1024	energy	2026-09-29 22:56:39	1
700186	1024	energy	2026-09-30 22:22:33	3
700187	1024	energy	2026-10-01 21:48:26	1
700188	1024	energy	2026-10-02 21:14:20	2
700189	1024	energy	2026-10-03 20:40:13	3
700190	1024	energy	2026-10-04 20:06:07	1
700191	1024	energy	2026-10-05 19:32:00	3
700192	1024	energy	2026-10-06 18:47:54	1
700193	1024	energy	2026-10-07 18:13:47	2
700194	1024	energy	2026-10-08 17:39:40	3
700195	1024	energy	2026-10-09 17:05:34	1
700196	1024	energy	2026-10-10 16:31:27	3
700197	1024	energy	2026-10-11 15:57:21	1
700198	1024	energy	2026-10-12 15:23:14	2
700199	1024	energy	2026-10-13 14:49:08	3
700200	1024	energy	2026-10-14 14:15:01	1
700201	1024	energy	2026-10-15 13:40:55	3
700202	1024	energy	2026-11-10 12:00:00	1
700203	1025	water	2026-09-28 00:00:00	3
700204	1025	water	2026-10-01 01:54:16	1
700205	1025	water	2026-10-04 03:41:22	3
700206	1025	water	2026-10-07 05:28:28	1
700207	1025	water	2026-10-10 07:15:34	2
700208	1025	water	2026-10-13 08:52:40	3
700209	1026	water	2026-09-28 00:00:00	3
700210	1026	water	2026-10-01 07:43:41	1
700211	1026	water	2026-10-04 15:19:53	3
700212	1026	water	2026-10-07 22:56:04	1
700213	1026	water	2026-10-11 06:32:16	2
700214	1026	water	2026-10-14 13:58:28	3
700215	1027	energy	2026-09-28 00:00:00	3
700216	1027	energy	2026-10-01 13:04:43	1
700217	1027	energy	2026-10-05 02:03:37	3
700218	1027	energy	2026-10-08 15:02:30	1
700219	1027	energy	2026-10-12 04:01:24	2
700220	1027	energy	2026-10-15 17:00:18	3
700221	1028	water	2026-09-28 00:00:00	1
700222	1028	energy	2026-09-28 00:00:00	3
700223	1028	water	2026-10-05 18:13:10	2
700224	1028	energy	2026-11-03 09:00:00	1
700225	1028	water	2026-10-13 12:18:13	3
700226	1028	energy	2026-11-09 19:00:00	2
700227	1029	water	2026-09-28 00:00:00	1
700228	1029	energy	2026-09-28 00:00:00	1
700229	1029	water	2026-10-06 08:46:14	2
700230	1029	energy	2026-10-06 07:38:15	2
700231	1029	water	2026-10-14 17:24:01	3
700232	1029	energy	2026-10-14 15:10:03	3
700233	1030	water	2026-09-28 00:00:00	1
700234	1030	energy	2026-09-28 00:00:00	1
700235	1030	water	2026-10-06 23:19:17	2
700236	1030	energy	2026-10-06 22:11:19	2
700237	1030	water	2026-10-15 22:19:49	3
700238	1030	energy	2026-10-15 20:15:51	3
700239	1031	energy	2026-09-28 00:00:00	1
700240	1031	energy	2026-10-01 21:26:02	2
700241	1031	energy	2026-10-05 18:44:59	3
700242	1031	energy	2026-10-09 16:03:56	1
700243	1031	energy	2026-10-13 13:22:53	3
700244	1031	energy	2026-11-13 15:00:00	1
700245	1032	water	2026-09-28 00:00:00	1
700246	1032	energy	2026-09-28 00:00:00	1
700247	1032	water	2026-10-06 10:15:24	2
700248	1032	energy	2026-10-06 09:17:26	2
700249	1032	water	2026-10-14 20:31:25	3
700250	1032	energy	2026-10-14 18:27:27	3
700251	1033	water	2026-09-28 00:00:00	1
700252	1033	energy	2026-09-28 00:00:00	1
700253	1033	water	2026-10-07 00:48:28	2
700254	1033	energy	2026-10-06 23:50:29	2
700255	1033	water	2026-10-16 01:37:13	3
700256	1033	energy	2026-10-15 23:33:15	3
700257	1034	water	2026-09-28 00:00:00	1
700258	1034	energy	2026-09-28 00:00:00	1
700259	1034	water	2026-10-05 21:21:31	2
700260	1034	energy	2026-10-05 20:23:33	2
700261	1034	water	2026-10-13 18:43:01	3
700262	1034	energy	2026-10-13 16:39:03	3
700263	1035	water	2026-09-28 00:00:00	1
700264	1035	energy	2026-09-28 00:00:00	1
700265	1035	water	2026-10-06 11:54:35	2
700266	1035	energy	2026-10-06 10:56:36	2
700267	1035	water	2026-10-14 23:48:49	3
700268	1035	energy	2026-10-14 21:44:51	3
700269	1036	water	2026-09-28 00:00:00	1
700270	1036	energy	2026-09-28 00:00:00	1
700271	1036	water	2026-10-07 02:27:38	2
700272	1036	energy	2026-10-07 01:29:40	2
700273	1036	water	2026-10-16 04:54:37	3
700274	1036	energy	2026-10-16 02:50:39	3
700275	1037	water	2026-09-28 00:00:00	1
700276	1037	energy	2026-09-28 00:00:00	3
700277	1037	water	2026-10-05 23:00:42	2
700278	1037	energy	2026-11-07 14:00:00	1
700279	1037	water	2026-10-13 22:00:25	3
700280	1037	energy	2026-11-13 17:00:00	2
700281	1038	water	2026-09-28 00:00:00	3
700282	1038	water	2026-10-01 10:14:39	1
700283	1038	water	2026-10-04 20:28:00	3
700284	1038	water	2026-10-08 06:41:21	1
700285	1038	water	2026-10-11 16:54:42	2
700286	1038	water	2026-10-15 03:08:04	3
700287	1039	water	2026-09-28 00:00:00	3
700288	1039	water	2026-10-01 16:04:04	1
700289	1039	water	2026-10-05 08:06:31	3
700290	1039	water	2026-10-09 00:08:58	1
700291	1039	water	2026-10-12 16:11:25	2
700292	1039	water	2026-10-16 08:13:52	3
700293	1040	energy	2026-09-28 00:00:00	3
700294	1040	energy	2026-10-01 04:37:06	1
700295	1040	energy	2026-10-04 09:14:15	3
700296	1040	energy	2026-10-07 13:51:24	1
700297	1040	energy	2026-10-10 18:28:33	2
700298	1040	energy	2026-10-13 23:05:42	3
700299	1041	energy	2026-09-28 00:00:00	3
700300	1041	energy	2026-10-01 10:26:30	1
700301	1041	energy	2026-10-04 20:52:45	3
700302	1041	energy	2026-10-08 07:19:00	1
700303	1041	energy	2026-10-11 17:45:15	2
700304	1041	energy	2026-10-15 04:11:30	3
700305	1042	water	2026-09-28 00:00:00	1
700306	1042	energy	2026-09-28 00:00:00	1
700307	1042	water	2026-10-07 05:45:59	2
700308	1042	energy	2026-10-07 04:38:01	2
700309	1042	water	2026-10-16 11:29:25	3
700310	1042	energy	2026-10-16 09:15:27	3
700311	1043	water	2026-09-28 00:00:00	1
700312	1043	energy	2026-09-28 00:00:00	2
700313	1043	water	2026-09-29 19:13:37	3
700314	1043	energy	2026-09-30 00:18:54	3
700315	1043	water	2026-10-01 14:24:21	1
700316	1043	energy	2026-10-02 00:36:54	1
700317	1043	water	2026-10-03 09:35:06	2
700318	1043	energy	2026-10-04 00:54:55	3
700319	1043	water	2026-10-05 04:45:50	3
700320	1043	energy	2026-10-06 01:12:55	1
700321	1043	water	2026-10-06 23:56:34	1
700322	1043	energy	2026-10-08 01:30:55	2
700323	1043	water	2026-10-08 19:07:19	3
700324	1043	energy	2026-10-10 01:48:56	3
700325	1043	water	2026-10-10 14:18:03	1
700326	1043	energy	2026-10-12 02:06:56	1
700327	1043	water	2026-10-12 09:28:47	2
700328	1043	energy	2026-10-14 02:24:57	3
700329	1043	water	2026-10-14 04:39:32	3
700330	1043	energy	2026-11-02 16:00:00	1
700331	1044	water	2026-09-28 00:00:00	1
700332	1044	energy	2026-09-28 00:00:00	1
700333	1044	water	2026-10-06 16:52:06	2
700334	1044	energy	2026-10-06 15:44:08	2
700335	1044	water	2026-10-15 09:41:01	3
700336	1044	energy	2026-10-15 07:27:03	3
700337	1045	water	2026-09-28 00:00:00	2
700338	1045	water	2026-10-04 04:58:09	3
700339	1045	water	2026-10-10 09:52:47	1
700340	1045	water	2026-10-16 14:47:26	3
700341	1045	water	2026-11-10 11:00:00	1
700342	1045	water	2026-11-15 20:00:00	2
700343	1046	water	2026-09-28 00:00:00	3
700344	1046	water	2026-10-01 06:25:57	1
700345	1046	water	2026-10-04 12:48:05	3
700346	1046	water	2026-10-07 19:10:12	1
700347	1046	water	2026-10-11 01:32:20	2
700348	1046	water	2026-10-14 07:54:28	3
700349	1047	water	2026-09-28 00:00:00	1
700350	1047	energy	2026-09-28 00:00:00	1
700351	1047	water	2026-10-06 18:31:17	2
700352	1047	energy	2026-10-06 17:23:18	2
700353	1047	water	2026-10-15 12:58:25	3
700354	1047	energy	2026-10-15 10:44:27	3
700355	1048	energy	2026-09-28 00:00:00	1
700356	1048	energy	2026-10-02 15:59:44	2
700357	1048	energy	2026-10-07 07:56:59	3
700358	1048	energy	2026-10-11 23:54:14	1
700359	1048	energy	2026-10-16 15:51:29	3
700360	1048	energy	2026-11-16 18:30:00	1
700361	1049	water	2026-09-28 00:00:00	1
700362	1049	energy	2026-09-28 00:00:00	1
700363	1049	water	2026-10-06 05:37:24	2
700364	1049	energy	2026-10-06 04:29:25	2
700365	1049	water	2026-10-14 11:10:01	3
700366	1049	energy	2026-10-14 08:56:03	3
700367	1050	water	2026-09-28 00:00:00	1
700368	1050	energy	2026-09-28 00:00:00	1
700369	1050	water	2026-10-06 20:10:27	2
700370	1050	energy	2026-10-06 19:02:29	2
700371	1050	water	2026-10-15 16:15:49	3
700372	1050	energy	2026-10-15 14:01:51	3
700373	1051	water	2026-09-28 00:00:00	1
700374	1051	energy	2026-09-28 00:00:00	1
700375	1051	water	2026-10-05 16:43:31	2
700376	1051	energy	2026-10-07 09:35:32	2
700377	1051	water	2026-10-13 09:21:37	3
700378	1051	energy	2026-10-16 19:07:39	3
700379	1052	water	2026-09-28 00:00:00	1
700380	1052	energy	2026-09-28 00:00:00	1
700381	1052	water	2026-10-06 07:16:34	2
700382	1052	energy	2026-10-06 06:08:36	2
700383	1052	water	2026-10-14 14:27:25	3
700384	1052	energy	2026-10-14 12:13:27	3
700385	1053	water	2026-09-28 00:00:00	1
700386	1053	energy	2026-09-28 00:00:00	1
700387	1053	water	2026-10-06 21:49:38	2
700388	1053	energy	2026-10-06 20:41:39	2
700389	1053	water	2026-10-15 19:33:13	3
700390	1053	energy	2026-10-15 17:19:15	3
700391	1054	water	2026-09-28 00:00:00	1
700392	1054	energy	2026-09-28 00:00:00	1
700393	1054	water	2026-10-05 18:22:41	2
700394	1054	energy	2026-10-05 17:14:43	2
700395	1054	water	2026-10-13 12:39:01	3
700396	1054	energy	2026-10-13 10:25:03	3
700397	1055	water	2026-09-28 00:00:00	3
700398	1055	water	2026-10-01 08:26:40	1
700399	1055	water	2026-10-04 16:46:40	3
700400	1055	water	2026-10-08 01:06:40	1
700401	1055	water	2026-10-11 09:26:40	2
700402	1055	water	2026-10-14 17:46:40	3
\.


--
-- Data for Name: cache_layout_edges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_layout_edges (id_dependence, control_points, updated_at) FROM stdin;
\.


--
-- Data for Name: cache_layout_nodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_layout_nodes (id_edifice, x, y, updated_at) FROM stdin;
\.


--
-- Data for Name: cache_sync_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_sync_state (id, last_sync_at, last_status, last_message, updated_at) FROM stdin;
1	2026-11-17 15:59:43.692196	ok	Автоматическое обновление событий: 402	2026-11-17 15:59:43.692196
\.


--
-- Name: cache_edifice_dependencies cache_edifice_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_edifice_dependencies
    ADD CONSTRAINT cache_edifice_dependencies_pkey PRIMARY KEY (id_dependence);


--
-- Name: cache_edifices cache_edifices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_edifices
    ADD CONSTRAINT cache_edifices_pkey PRIMARY KEY (id_edifice);


--
-- Name: cache_event_statuses cache_event_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_event_statuses
    ADD CONSTRAINT cache_event_statuses_pkey PRIMARY KEY (id_status);


--
-- Name: cache_events cache_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_events
    ADD CONSTRAINT cache_events_pkey PRIMARY KEY (id_event);


--
-- Name: cache_layout_edges cache_layout_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_layout_edges
    ADD CONSTRAINT cache_layout_edges_pkey PRIMARY KEY (id_dependence);


--
-- Name: cache_layout_nodes cache_layout_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_layout_nodes
    ADD CONSTRAINT cache_layout_nodes_pkey PRIMARY KEY (id_edifice);


--
-- Name: cache_sync_state cache_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_sync_state
    ADD CONSTRAINT cache_sync_state_pkey PRIMARY KEY (id);


--
-- Name: cache_dependencies_dependent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_dependencies_dependent_idx ON public.cache_edifice_dependencies USING btree (id_edifice_dependent);


--
-- Name: cache_dependencies_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_dependencies_source_idx ON public.cache_edifice_dependencies USING btree (id_edifice_source, resource_type);


--
-- Name: cache_events_edifice_resource_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_events_edifice_resource_idx ON public.cache_events USING btree (id_edifice, resource_type, occurred_at DESC);


--
-- Name: cache_events_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cache_events_status_idx ON public.cache_events USING btree (id_status);


--
-- Name: cache_edifice_dependencies cache_dependencies_dependent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_edifice_dependencies
    ADD CONSTRAINT cache_dependencies_dependent_fk FOREIGN KEY (id_edifice_dependent) REFERENCES public.cache_edifices(id_edifice) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cache_edifice_dependencies cache_dependencies_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_edifice_dependencies
    ADD CONSTRAINT cache_dependencies_source_fk FOREIGN KEY (id_edifice_source) REFERENCES public.cache_edifices(id_edifice) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cache_events cache_events_edifice_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_events
    ADD CONSTRAINT cache_events_edifice_fk FOREIGN KEY (id_edifice) REFERENCES public.cache_edifices(id_edifice) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cache_events cache_events_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_events
    ADD CONSTRAINT cache_events_status_fk FOREIGN KEY (id_status) REFERENCES public.cache_event_statuses(id_status) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cache_layout_edges cache_layout_edges_dep_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_layout_edges
    ADD CONSTRAINT cache_layout_edges_dep_fk FOREIGN KEY (id_dependence) REFERENCES public.cache_edifice_dependencies(id_dependence) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cache_layout_nodes cache_layout_nodes_edifice_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_layout_nodes
    ADD CONSTRAINT cache_layout_nodes_edifice_fk FOREIGN KEY (id_edifice) REFERENCES public.cache_edifices(id_edifice) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 5EXD64u88P9r1hIA4bdS7D7lMS3MrJ6vOd4JGcadrHC2Yn3mz3kU8SPZiDo6VjT

