-- Локальная схема кэша «Панорама».
-- Выполнить один раз в локальной PostgreSQL 14 (база postgres, пользователь postgres).

BEGIN;

-- Статусы событий (копия справочника).
CREATE TABLE IF NOT EXISTS public.cache_event_statuses (
    id_status smallint PRIMARY KEY,
    name      character varying(20) NOT NULL
);

-- Объекты инфраструктуры.
CREATE TABLE IF NOT EXISTS public.cache_edifices (
    id_edifice    integer PRIMARY KEY,
    name          character varying(120) NOT NULL,
    resource_type character varying(15)[] NOT NULL,
    district      character varying(50),
    street        character varying(80),
    house_number  character varying(10),
    CONSTRAINT cache_edifices_resource_type_check
        CHECK (resource_type <@ ARRAY['water', 'energy']::varchar[])
);

-- Направленные зависимости между объектами.
CREATE TABLE IF NOT EXISTS public.cache_edifice_dependencies (
    id_dependence        integer PRIMARY KEY,
    resource_type        character varying(15) NOT NULL,
    id_edifice_source    integer NOT NULL,
    id_edifice_dependent integer NOT NULL,
    CONSTRAINT cache_dependencies_source_fk
        FOREIGN KEY (id_edifice_source)
        REFERENCES public.cache_edifices (id_edifice)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT cache_dependencies_dependent_fk
        FOREIGN KEY (id_edifice_dependent)
        REFERENCES public.cache_edifices (id_edifice)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT cache_dependencies_check
        CHECK (id_edifice_source <> id_edifice_dependent)
);

-- История событий.
CREATE TABLE IF NOT EXISTS public.cache_events (
    id_event      integer PRIMARY KEY,
    id_edifice    integer NOT NULL,
    resource_type character varying(15) NOT NULL,
    occurred_at   timestamp without time zone NOT NULL,
    id_status     smallint NOT NULL,
    CONSTRAINT cache_events_edifice_fk
        FOREIGN KEY (id_edifice)
        REFERENCES public.cache_edifices (id_edifice)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT cache_events_status_fk
        FOREIGN KEY (id_status)
        REFERENCES public.cache_event_statuses (id_status)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Позиции узлов графа.
CREATE TABLE IF NOT EXISTS public.cache_layout_nodes (
    id_edifice integer PRIMARY KEY,
    x          double precision NOT NULL,
    y          double precision NOT NULL,
    updated_at timestamp without time zone NOT NULL DEFAULT NOW(),
    CONSTRAINT cache_layout_nodes_edifice_fk
        FOREIGN KEY (id_edifice)
        REFERENCES public.cache_edifices (id_edifice)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Изгибы (контрольные точки) связей графа.
CREATE TABLE IF NOT EXISTS public.cache_layout_edges (
    id_dependence  integer PRIMARY KEY,
    control_points jsonb NOT NULL DEFAULT '[]'::jsonb,
    updated_at     timestamp without time zone NOT NULL DEFAULT NOW(),
    CONSTRAINT cache_layout_edges_dep_fk
        FOREIGN KEY (id_dependence)
        REFERENCES public.cache_edifice_dependencies (id_dependence)
        ON UPDATE CASCADE ON DELETE CASCADE
);

-- Единая строка состояния синхронизации.
CREATE TABLE IF NOT EXISTS public.cache_sync_state (
    id           smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    last_sync_at timestamp without time zone,
    last_status  character varying(20),
    last_message text,
    updated_at   timestamp without time zone NOT NULL DEFAULT NOW()
);

INSERT INTO public.cache_sync_state (id) VALUES (1)
ON CONFLICT (id) DO NOTHING;

-- Индексы для типовых запросов.
CREATE INDEX IF NOT EXISTS cache_events_edifice_resource_idx
    ON public.cache_events (id_edifice, resource_type, occurred_at DESC);

CREATE INDEX IF NOT EXISTS cache_events_status_idx
    ON public.cache_events (id_status);

CREATE INDEX IF NOT EXISTS cache_dependencies_source_idx
    ON public.cache_edifice_dependencies (id_edifice_source, resource_type);

CREATE INDEX IF NOT EXISTS cache_dependencies_dependent_idx
    ON public.cache_edifice_dependencies (id_edifice_dependent);

COMMIT;
