<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/validate.php';
require_once __DIR__ . '/../lib/graph.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Метод не поддерживается', 405);
}

try {
    $at = v_datetime($_GET['at'] ?? null);
    if (isset($_GET['at']) && $_GET['at'] !== '' && $at === null) {
        json_error('Некорректная дата в параметре at', 400);
    }

    $data = graph_load_data();
    graph_assert_valid($data['edifices'], $data['dependencies']);
    $criticality = graph_criticality($data['edifices'], $data['dependencies']);
    $states = graph_states($data['edifices'], $data['dependencies'], $data['events'], $at);
    $timeline = graph_timeline($data['events']);
    $districts = graph_districts($data['edifices']);

    $nodes = [];
    foreach ($data['edifices'] as $e) {
        $id = $e['id_edifice'];
        $nodeStates = [];
        foreach ($e['resource_types'] as $res) {
            if (isset($states[$id][$res])) {
                $nodeStates[$res] = $states[$id][$res];
            }
        }
        $nodes[] = [
            'id'             => $id,
            'name'           => $e['name'],
            'resource_types' => $e['resource_types'],
            'district'       => $e['district'],
            'street'         => $e['street'],
            'house_number'   => $e['house_number'],
            'criticality'    => $criticality[$id] ?? 0,
            'states'         => $nodeStates,
        ];
    }

    $edges = [];
    foreach ($data['dependencies'] as $d) {
        $edges[] = [
            'id'            => $d['id_dependence'],
            'source'        => $d['source'],
            'dependent'     => $d['dependent'],
            'resource_type' => $d['resource_type'],
        ];
    }

    $syncInfo = db_one(db_local(), "SELECT to_char(last_sync_at, 'YYYY-MM-DD HH24:MI:SS') AS last_sync_at, last_status FROM cache_sync_state WHERE id = 1");
    json_ok([
        'sync_state' => $syncInfo,
        'nodes'    => $nodes,
        'edges'    => $edges,
        'districts' => $districts,
        'timeline' => $timeline,
        'at'       => $at,
        'timestamp_offset' => (new DateTime('now', new DateTimeZone((string) (app_config()['app']['data_timezone'] ?? 'Europe/Moscow'))))->format('P'),
    ]);
} catch (Throwable $e) {
    error_log('[panorama][graph] ' . $e->getMessage());
    json_error('Не удалось построить граф: ' . $e->getMessage(), 422);
}
