<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/validate.php';
require_once __DIR__ . '/../lib/graph.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Метод не поддерживается', 405);
}

$action = v_enum($_GET['action'] ?? null, ['objects', 'events', 'history', 'timeline', 'summary'], null);
if ($action === null) {
    json_error('Неизвестное действие', 400);
}

try {
    switch ($action) {
        case 'objects':
            json_ok(data_objects());
            break;
        case 'events':
            json_ok(data_events());
            break;
        case 'history':
            json_ok(data_history());
            break;
        case 'timeline':
            json_ok(data_timeline());
            break;
        case 'summary':
            json_ok(data_summary());
            break;
    }
} catch (InvalidArgumentException $e) {
    json_error($e->getMessage(), 400);
} catch (Throwable $e) {
    error_log('[panorama][data] ' . $e->getMessage());
    json_error('Ошибка получения данных: ' . $e->getMessage(), 500);
}

function data_objects(): array
{
    $search = v_str($_GET['search'] ?? '', 120);
    $district = v_str($_GET['district'] ?? '', 50);
    $resource = v_enum($_GET['resource'] ?? '', ['water', 'energy'], null);

    $loc = db_local();
    $sql = 'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                   district, street, house_number
              FROM cache_edifices
             WHERE 1=1';
    $params = [];

    if ($search !== '') {
        $like = '%' . $search . '%';
        $params[] = $like;
        $pos = count($params);
        $sql .= ' AND (name ILIKE $' . $pos . '::text
            OR COALESCE(street, \'\') ILIKE $' . $pos . '::text
            OR COALESCE(district, \'\') ILIKE $' . $pos . '::text
            OR id_edifice::text ILIKE $' . $pos . '::text
            OR COALESCE(house_number, \'\') ILIKE $' . $pos . '::text)';
    }
    if ($district !== '') {
        $params[] = $district;
        $pos = count($params);
        $sql .= ' AND district = $' . $pos . '::varchar';
    }
    if ($resource !== null) {
        $params[] = $resource;
        $pos = count($params);
        // Используем ANY для надежной проверки вхождения в массив
        $sql .= ' AND $' . $pos . '::varchar = ANY(resource_type)';
    }
    $sql .= ' ORDER BY id_edifice';

    $rows = db_all($loc, $sql, $params);
    $items = [];
    foreach ($rows as $row) {
        $resources = json_decode((string) ($row['resource_type_json'] ?? '[]'), true);
        if (!is_array($resources)) {
            $resources = [];
        }
        $clean = [];
        foreach ($resources as $r) {
            if (is_string($r) && in_array($r, ['water', 'energy'], true)) {
                $clean[] = $r;
            }
        }
        $items[] = [
            'id_edifice'     => (int) $row['id_edifice'],
            'name'           => (string) $row['name'],
            'resource_types' => $clean,
            'district'       => $row['district'],
            'street'         => $row['street'],
            'house_number'   => $row['house_number'],
        ];
    }

    $districts = [];
    foreach (db_all($loc, "SELECT DISTINCT district FROM cache_edifices WHERE district IS NOT NULL AND district <> '' ORDER BY district") as $dr) {
        $districts[] = (string) $dr['district'];
    }

    return ['items' => $items, 'districts' => $districts, 'total' => count($items)];
}

function data_events(): array
{
    $mode = v_enum($_GET['mode'] ?? 'active', ['active', 'archive'], 'active');
    $search = v_str($_GET['search'] ?? '', 120);
    $resource = v_enum($_GET['resource'] ?? '', ['water', 'energy'], null);
    $limit = v_id($_GET['limit'] ?? 500) ?? 500;
    if ($limit > 5000) {
        $limit = 5000;
    }

    $loc = db_local();
    $latestIds = [];
    foreach (
        db_all(
            $loc,
            'SELECT DISTINCT ON (id_edifice, resource_type) id_event
           FROM cache_events
          ORDER BY id_edifice, resource_type, occurred_at DESC, id_event DESC'
        ) as $r
    ) {
        $latestIds[] = (int) $r['id_event'];
    }

    $sql = 'SELECT e.id_event, e.id_edifice, e.resource_type,
                   to_char(e.occurred_at, \'YYYY-MM-DD HH24:MI:SS\') AS occurred_at,
                   e.id_status, s.name AS status_name, ed.name AS edifice_name
              FROM cache_events e
              JOIN cache_event_statuses s ON s.id_status = e.id_status
              JOIN cache_edifices ed ON ed.id_edifice = e.id_edifice
             WHERE 1=1';
    $params = [];

    if ($mode === 'active') {
        if (empty($latestIds)) {
            return ['items' => [], 'total' => 0, 'mode' => 'active'];
        }
        $params[] = '{' . implode(',', $latestIds) . '}';
        $sql .= ' AND e.id_event = ANY($1::integer[]) AND e.id_status IN (1, 2)';
    } else {
        if (!empty($latestIds)) {
            $params[] = '{' . implode(',', $latestIds) . '}';
            $sql .= ' AND (e.id_event != ALL($1::integer[]) OR e.id_status = 3)';
        }
    }

    if ($search !== '') {
        $params[] = '%' . $search . '%';
        $pos = count($params);
        $sql .= ' AND (ed.name ILIKE $' . $pos . '::text OR e.resource_type ILIKE $' . $pos . '::text OR e.id_event::text ILIKE $' . $pos . '::text OR ed.district ILIKE $' . $pos . '::text)';
    }
    if ($resource !== null) {
        $params[] = $resource;
        $pos = count($params);
        $sql .= ' AND e.resource_type = $' . $pos . '::varchar';
    }

    $sql .= ' ORDER BY e.occurred_at DESC, e.id_event DESC LIMIT ' . (int) $limit;

    $rows = db_all($loc, $sql, $params);
    $items = [];
    $latestSet = array_flip($latestIds);
    foreach ($rows as $row) {
        $items[] = [
            'id_event'      => (int) $row['id_event'],
            'id_edifice'    => (int) $row['id_edifice'],
            'edifice_name'  => (string) $row['edifice_name'],
            'resource_type' => (string) $row['resource_type'],
            'occurred_at'   => (string) $row['occurred_at'],
            'id_status'     => (int) $row['id_status'],
            'status_name'   => (string) $row['status_name'],
            'is_current'    => isset($latestSet[(int) $row['id_event']]),
        ];
    }

    return ['items' => $items, 'total' => count($items), 'mode' => $mode];
}

function data_history(): array
{
    $id = v_id($_GET['id'] ?? null);
    if ($id === null) {
        throw new InvalidArgumentException('Некорректный идентификатор объекта');
    }

    $loc = db_local();
    $edifice = db_one(
        $loc,
        'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                district, street, house_number
           FROM cache_edifices
          WHERE id_edifice = $1',
        [$id]
    );
    if ($edifice === null) {
        throw new InvalidArgumentException('Объект не найден');
    }

    $events = db_all(
        $loc,
        'SELECT e.id_event, e.resource_type,
                to_char(e.occurred_at, \'YYYY-MM-DD HH24:MI:SS\') AS occurred_at,
                e.id_status, s.name AS status_name
           FROM cache_events e
           JOIN cache_event_statuses s ON s.id_status = e.id_status
          WHERE e.id_edifice = $1
          ORDER BY e.occurred_at DESC, e.id_event DESC',
        [$id]
    );

    $latestIds = [];
    foreach (
        db_all(
            $loc,
            'SELECT DISTINCT ON (resource_type) id_event
           FROM cache_events
          WHERE id_edifice = $1
          ORDER BY resource_type, occurred_at DESC, id_event DESC',
            [$id]
        ) as $r
    ) {
        $latestIds[] = (int) $r['id_event'];
    }
    $latestSet = array_flip($latestIds);

    $items = [];
    foreach ($events as $ev) {
        $items[] = [
            'id_event'      => (int) $ev['id_event'],
            'resource_type' => (string) $ev['resource_type'],
            'occurred_at'   => (string) $ev['occurred_at'],
            'id_status'     => (int) $ev['id_status'],
            'status_name'   => (string) $ev['status_name'],
            'is_current'    => isset($latestSet[(int) $ev['id_event']]),
        ];
    }

    $resources = json_decode((string) ($edifice['resource_type_json'] ?? '[]'), true);
    if (!is_array($resources)) {
        $resources = [];
    }
    $clean = [];
    foreach ($resources as $r) {
        if (is_string($r) && in_array($r, ['water', 'energy'], true)) {
            $clean[] = $r;
        }
    }

    return [
        'edifice' => [
            'id_edifice'     => (int) $edifice['id_edifice'],
            'name'           => (string) $edifice['name'],
            'resource_types' => $clean,
            'district'       => $edifice['district'],
            'street'         => $edifice['street'],
            'house_number'   => $edifice['house_number'],
        ],
        'events' => $items,
        'total'  => count($items),
    ];
}

function data_timeline(): array
{
    $points = graph_timeline(graph_load_data()['events']);
    return ['points' => $points, 'total' => count($points)];
}


function data_summary(): array
{
    $data = graph_load_data();
    $states = graph_states($data['edifices'], $data['dependencies'], $data['events'], null);

    $counts = [
        'objects_total'    => count($data['edifices']),
        'objects_normal'   => 0,
        'objects_accident' => 0,
        'objects_repair'   => 0,
        'objects_affected' => 0,
        'events_total'     => count($data['events']),
        'events_active'    => 0,
        'events_archive'   => 0,
    ];

    foreach ($states as $edificeStates) {
        $worst = 'normal';
        foreach ($edificeStates as $st) {
            if ($st['state'] === 'accident') {
                $worst = 'accident';
                break;
            }
            if ($st['state'] === 'repair' && $worst !== 'accident') {
                $worst = 'repair';
            }
            if ($st['state'] === 'affected' && $worst === 'normal') {
                $worst = 'affected';
            }
        }
        if ($worst === 'accident') {
            $counts['objects_accident']++;
        } elseif ($worst === 'repair') {
            $counts['objects_repair']++;
        } elseif ($worst === 'affected') {
            $counts['objects_affected']++;
        } else {
            $counts['objects_normal']++;
        }
    }

    $latest = [];
    foreach ($data['events'] as $ev) {
        $key = $ev['id_edifice'] . ':' . $ev['resource_type'];
        $cur = $latest[$key] ?? null;
        if (
            $cur === null
            || $ev['occurred_at'] > $cur['occurred_at']
            || ($ev['occurred_at'] === $cur['occurred_at'] && $ev['id_event'] > $cur['id_event'])
        ) {
            $latest[$key] = $ev;
        }
    }
    foreach ($latest as $ev) {
        if (in_array($ev['id_status'], [1, 2], true)) {
            $counts['events_active']++;
        } else {
            $counts['events_archive']++;
        }
    }
    $counts['events_archive'] += count($data['events']) - count($latest);

    return $counts;
}
