<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Метод не поддерживается', 405);
}

json_ok(['csrf' => csrf_token()]);
