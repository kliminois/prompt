<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/db.php';

/**
 * Диагностика окружения и обоих подключений.
 * Всегда отвечает 200; итоговая готовность — в поле healthy.
 */
$result = [
    'healthy'     => false,
    'php_version' => PHP_VERSION,
    'php_74'      => version_compare(PHP_VERSION, '7.4.0', '>=') && version_compare(PHP_VERSION, '8.0.0', '<'),
    'extensions'  => [
        'pgsql'    => extension_loaded('pgsql'),
        'mbstring' => extension_loaded('mbstring'),
        'json'     => extension_loaded('json'),
        'zip'      => extension_loaded('zip'),
        'session'  => extension_loaded('session'),
    ],
    'local'       => [
        'ok'             => false,
        'error'          => null,
        'version'        => null,
        'schema_ready'   => false,
        'missing_tables' => [],
    ],
    'external'    => [
        'ok'      => false,
        'error'   => null,
        'version' => null,
        'tables'  => [],
    ],
];

/* Локальная БД */
try {
    $conn = db_local();
    $result['local']['ok']      = true;
    $result['local']['version'] = (string) db_scalar($conn, 'SHOW server_version', [], '');

    $ready = db_local_ready();
    $result['local']['schema_ready']   = (bool) $ready['ok'];
    $result['local']['missing_tables'] = $ready['missing'];
    if ($ready['error'] !== null) {
        $result['local']['error'] = $ready['error'];
    }
} catch (Throwable $e) {
    $result['local']['error'] = $e->getMessage();
}

/* Внешняя БД */
$probe = db_external_probe();
$result['external']['ok']    = (bool) $probe['ok'];
$result['external']['error'] = $probe['error'];

if ($probe['ok']) {
    try {
        $conn = db_external();
        $result['external']['version'] = (string) db_scalar($conn, 'SHOW server_version', [], '');

        // Имена таблиц берутся из фиксированного белого списка — подстановка безопасна.
        $allowedTables = ['edifices', 'edifice_dependencies', 'events', 'event_statuses'];

        foreach ($allowedTables as $tbl) {
            $existsRaw = db_scalar(
                $conn,
                'SELECT CASE WHEN EXISTS(
                    SELECT 1 FROM information_schema.tables
                     WHERE table_schema = $1 AND table_name = $2
                ) THEN 1 ELSE 0 END',
                ['public', $tbl],
                0
            );
            $exists = ((int) $existsRaw) === 1;

            $rows = null;
            if ($exists) {
                $countRaw = db_scalar($conn, 'SELECT COUNT(*) FROM public.' . $tbl, [], 0);
                $rows = (int) $countRaw;
            }

            $result['external']['tables'][$tbl] = ['exists' => $exists, 'rows' => $rows];
        }
    } catch (Throwable $e) {
        $result['external']['error'] = $e->getMessage();
    }
}

$result['healthy'] = $result['php_74']
    && $result['extensions']['pgsql']
    && $result['local']['ok']
    && $result['local']['schema_ready'];

json_ok($result);
