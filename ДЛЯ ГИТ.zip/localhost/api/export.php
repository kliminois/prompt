<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/validate.php';
require_once __DIR__ . '/../lib/xlsx.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Метод не поддерживается', 405);
}

try {
    $loc = db_local();

    // Объекты
    $objectsRows = [[
        'ID',
        'Наименование',
        'Ресурсы',
        'Район',
        'Улица',
        'Дом',
    ]];
    foreach (
        db_all(
            $loc,
            'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                district, street, house_number
           FROM cache_edifices
          ORDER BY id_edifice'
        ) as $row
    ) {
        $resources = json_decode((string) ($row['resource_type_json'] ?? '[]'), true);
        if (!is_array($resources)) {
            $resources = [];
        }
        $resLabels = [];
        foreach ($resources as $r) {
            if ($r === 'water') {
                $resLabels[] = 'Водоснабжение';
            } elseif ($r === 'energy') {
                $resLabels[] = 'Электроснабжение';
            }
        }
        $objectsRows[] = [
            (int) $row['id_edifice'],
            (string) $row['name'],
            implode(', ', $resLabels),
            (string) ($row['district'] ?? ''),
            (string) ($row['street'] ?? ''),
            (string) ($row['house_number'] ?? ''),
        ];
    }

    // Все события
    $eventsRows = [[
        'ID события',
        'ID объекта',
        'Объект',
        'Ресурс',
        'Дата и время',
        'Статус',
        'ID статуса',
    ]];
    foreach (
        db_all(
            $loc,
            "SELECT e.id_event, e.id_edifice, ed.name AS edifice_name,
                e.resource_type,
                to_char(e.occurred_at, 'YYYY-MM-DD HH24:MI:SS') AS occurred_at,
                e.id_status, s.name AS status_name
           FROM cache_events e
           JOIN cache_edifices ed ON ed.id_edifice = e.id_edifice
           JOIN cache_event_statuses s ON s.id_status = e.id_status
          ORDER BY e.occurred_at DESC, e.id_event DESC"
        ) as $row
    ) {
        $resource = (string) $row['resource_type'];
        if ($resource === 'water') {
            $resource = 'Водоснабжение';
        } elseif ($resource === 'energy') {
            $resource = 'Электроснабжение';
        }
        $eventsRows[] = [
            (int) $row['id_event'],
            (int) $row['id_edifice'],
            (string) $row['edifice_name'],
            $resource,
            (string) $row['occurred_at'],
            (string) $row['status_name'],
            (int) $row['id_status'],
        ];
    }

    $writer = new XlsxWriter();
    $writer->addSheet('Объекты', $objectsRows);
    $writer->addSheet('События', $eventsRows);
    $writer->output('panorama_export_' . date('Ymd_His') . '.xlsx');
} catch (Throwable $e) {
    error_log('[panorama][export] ' . $e->getMessage());
    json_error('Ошибка экспорта: ' . $e->getMessage(), 500);
}
