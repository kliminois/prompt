<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/validate.php';
require_once __DIR__ . '/../lib/sync.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Метод не поддерживается', 405);
}

$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!csrf_verify($token)) {
    json_error('Неверный CSRF-токен', 403);
}

$body = file_get_contents('php://input');
$data = json_decode($body, true);
if (!is_array($data)) {
    json_error('Некорректный JSON', 400);
}

$action = v_enum($data['action'] ?? null, ['sync', 'reset', 'refresh'], null);
if ($action === null) {
    json_error('Неизвестное действие', 400);
}

try {
    if ($action === 'sync') {
        $stats = sync_from_external();
        json_ok([
            'message'    => 'Синхронизация завершена',
            'stats'      => $stats,
            'sync_state' => sync_state(),
            'local'      => db_local_stats(),
        ]);
    }

    if ($action === 'refresh') {
        $stats = sync_refresh_events();
        json_ok([
            'message' => 'Состояния обновлены',
            'stats' => $stats,
            'sync_state' => sync_state(),
        ]);
    }

    // reset
    db_reset_local();
    json_ok([
        'message'    => 'Локальные данные удалены',
        'sync_state' => sync_state(),
        'local'      => db_local_stats(),
    ]);
} catch (Throwable $e) {
    error_log('[panorama][sync] ' . $e->getMessage());
    json_error('Не удалось выполнить операцию: ' . $e->getMessage(), 500);
}
