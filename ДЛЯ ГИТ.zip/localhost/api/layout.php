<?php

declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/validate.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';

if ($method === 'GET') {
    try {
        $loc = db_local();
        $nodes = [];
        foreach (db_all($loc, 'SELECT id_edifice, x, y FROM cache_layout_nodes') as $r) {
            $nodes[] = [
                'id_edifice' => (int) $r['id_edifice'],
                'x'          => (float) $r['x'],
                'y'          => (float) $r['y'],
            ];
        }
        $edges = [];
        foreach (db_all($loc, 'SELECT id_dependence, control_points FROM cache_layout_edges') as $r) {
            $cp = json_decode((string) $r['control_points'], true);
            $edges[] = [
                'id_dependence'  => (int) $r['id_dependence'],
                'control_points' => is_array($cp) ? $cp : [],
            ];
        }
        json_ok(['nodes' => $nodes, 'edges' => $edges]);
    } catch (Throwable $e) {
        error_log('[panorama][layout] ' . $e->getMessage());
        json_error('Ошибка получения компоновки: ' . $e->getMessage(), 500);
    }
}

if ($method === 'POST') {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!csrf_verify($token)) {
        json_error('Неверный CSRF-токен', 403);
    }

    $body = file_get_contents('php://input');
    $data = json_decode($body, true);
    if (!is_array($data)) {
        json_error('Некорректный JSON', 400);
    }

    $nodesIn = isset($data['nodes']) && is_array($data['nodes']) ? $data['nodes'] : [];
    $edgesIn = isset($data['edges']) && is_array($data['edges']) ? $data['edges'] : [];

    if (count($nodesIn) > 10000 || count($edgesIn) > 50000) {
        json_error('Слишком много данных для сохранения', 413);
    }

    $nodes = [];
    foreach ($nodesIn as $n) {
        if (!is_array($n)) {
            continue;
        }
        $id = v_id($n['id_edifice'] ?? null);
        if ($id === null) {
            continue;
        }
        $x = v_float($n['x'] ?? null);
        $y = v_float($n['y'] ?? null);
        if ($x === null || $y === null) {
            continue;
        }
        $nodes[] = ['id' => $id, 'x' => $x, 'y' => $y];
    }

    $edges = [];
    foreach ($edgesIn as $e) {
        if (!is_array($e)) {
            continue;
        }
        $id = v_id($e['id_dependence'] ?? null);
        if ($id === null) {
            continue;
        }
        $cp = [];
        if (isset($e['control_points']) && is_array($e['control_points'])) {
            foreach ($e['control_points'] as $pt) {
                if (count($cp) >= 50) {
                    break;
                }
                if (!is_array($pt)) {
                    continue;
                }
                $px = v_float($pt['x'] ?? null);
                $py = v_float($pt['y'] ?? null);
                if ($px === null || $py === null) {
                    continue;
                }
                $cp[] = ['x' => $px, 'y' => $py];
            }
        }
        $edges[] = ['id' => $id, 'control_points' => $cp];
    }

    try {
        $loc = db_local();
        db_begin($loc);
        try {

            // Любая ошибка FK/SQL откатывает всю транзакцию (не сообщаем ложный успех).
            foreach ($nodes as $n) {
                db_exec(
                    $loc,
                    'INSERT INTO cache_layout_nodes (id_edifice, x, y) VALUES ($1, $2, $3)
                     ON CONFLICT (id_edifice) DO UPDATE
                       SET x=EXCLUDED.x, y=EXCLUDED.y, updated_at=NOW()',
                    [$n['id'], $n['x'], $n['y']]
                );
            }
            foreach ($edges as $e) {
                $cpJson = json_encode($e['control_points']);
                if ($cpJson === false) {
                    throw new RuntimeException('Не удалось сериализовать траекторию связи');
                }
                db_exec(
                    $loc,
                    'INSERT INTO cache_layout_edges (id_dependence, control_points)
                     VALUES ($1, $2::jsonb)
                     ON CONFLICT (id_dependence) DO UPDATE
                       SET control_points=EXCLUDED.control_points, updated_at=NOW()',
                    [$e['id'], $cpJson]
                );
            }

            db_commit($loc);
        } catch (Throwable $e) {
            db_rollback($loc);
            throw $e;
        }

        json_ok([
            'saved' => true,
            'nodes' => count($nodes),
            'edges' => count($edges),
        ]);
    } catch (Throwable $e) {
        error_log('[panorama][layout] ' . $e->getMessage());
        json_error('Ошибка сохранения компоновки: ' . $e->getMessage(), 500);
    }
}

json_error('Метод не поддерживается', 405);
