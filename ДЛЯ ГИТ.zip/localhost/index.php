<?php

/** Панорама инфраструктуры — единое офлайн-приложение. */

declare(strict_types=1);
require_once __DIR__ . '/lib/bootstrap.php';
$csrf = htmlspecialchars(csrf_token(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<!doctype html>
<html lang="ru">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <title>Цифровой контур управления</title>
  <link rel="stylesheet" href="assets/style.css?v=3">
  <script src="assets/graph.js?v=3" defer></script>
  <script src="assets/app.js?v=3" defer></script>
</head>

<body>
  <header class="app-header">
    <div class="brand"><span class="brand-mark" aria-hidden="true">P</span>
      <div>        
        <h1>ЦИФРОВОЙ КОНТУР УПРАВЛЕНИЯ</h1>
      </div>
    </div>
    <div class="header-actions">
      <span id="connection-pill" class="connection-indicator"><i class="signal-dot"></i><span id="connection-text">Проверка подключения</span></span>
      <button id="theme-toggle" class="btn btn-subtle" type="button">☀ Светлая тема</button>
    </div>
  </header>
  <div class="layout">
    <aside class="sidebar" aria-label="Параметры карты">
      <div class="sidebar-title">
        <div class="eyebrow">УПРАВЛЕНИЕ</div>
        <h2 id="current-view-title">Граф объектов</h2>
      </div>
      <div class="sidebar-block">
        <h3>Фильтры графа</h3>
        <label class="field"><span>Поиск по объектам</span><input id="graph-search" type="search" placeholder="Название, ID, адрес…" autocomplete="off"></label>
        <label class="field"><span>Тип ресурса</span><select id="filter-resource">
            <option value="">Все ресурсы</option>
            <option value="water">Водоснабжение</option>
            <option value="energy">Электроснабжение</option>
          </select></label>
        <label class="field"><span>Состояние</span><select id="filter-state">
            <option value="">Все состояния</option>
            <option value="accident">Авария</option>
            <option value="repair">Ремонт</option>
            <option value="affected">Под влиянием</option>
            <option value="normal">Норма</option>
          </select></label>
        <label class="check-field"><input id="filter-active-only" type="checkbox"><span>Только объекты с активными инцидентами и затронутые ими</span></label>
        <button id="reset-filters" class="btn btn-subtle btn-full" type="button">↺ Сбросить фильтры</button>
      </div>
      <div class="sidebar-block">
        <h3>Данные и операции</h3>
        <button id="sync-data" class="btn btn-primary btn-full" type="button">↻ Синхронизировать</button>
        <button id="export-xlsx" class="btn btn-secondary btn-full" type="button">↓ Экспорт объектов и событий · XLSX</button>
        <button id="btn-reset-data" class="btn btn-danger-outline btn-full" type="button">Удалить все локальные данные</button>
        <p id="sync-status" class="sidebar-note" aria-live="polite">Нет данных о синхронизации</p>
      </div>      
    </aside>
    <main class="workspace">
      <div class="heading-bar">
        <div>
          <div class="eyebrow">РАБОЧАЯ ПАНЕЛЬ / МОНИТОРИНГ</div>
          <h2>Карта инфраструктуры</h2>
          <p>Направленные зависимости, зоны влияния и история изменений</p>
        </div>
        <nav class="view-tabs" aria-label="Разделы"><button class="view-btn active" data-view="graph" type="button">Граф</button><button class="view-btn" data-view="events" type="button">События</button><button class="view-btn" data-view="objects" type="button">Объекты</button></nav>
      </div>
      <div class="stats" aria-label="Показатели">
        <article class="stat"><span>Всего объектов</span><strong id="stat-total">0</strong></article>
        <article class="stat"><span>Аварии</span><strong class="text-danger" id="stat-accident">0</strong></article>
        <article class="stat"><span>Ремонтные работы</span><strong class="text-warning" id="stat-repair">0</strong></article>
        <article class="stat"><span>Под влиянием аварий</span><strong class="text-violet" id="stat-affected">0</strong></article>
      </div>
      <section id="view-graph" class="panel graph-panel" aria-label="Граф инфраструктуры">
        <div class="graph-toolbar">
          <div class="toolbar-group"><button id="zoom-in" class="tool-btn" type="button" title="Приблизить" aria-label="Приблизить">＋</button><button id="zoom-out" class="tool-btn" type="button" title="Отдалить" aria-label="Отдалить">－</button><button id="zoom-reset" class="tool-btn tool-wide" type="button" title="Вписать граф">⤢ Вписать</button></div>
          <div class="toolbar-divider"></div>
          <div class="toolbar-group"><button id="tool-pan" class="tool-btn active" type="button" title="Перемещение и выбор узлов">✋ Навигация</button><button id="tool-edge" class="tool-btn" type="button" title="Настройка изгибов связей">⌁ Связи</button><button id="tool-draw" class="tool-btn" type="button" title="Рисовать пометки">✎ Маркер</button><button id="tool-erase" class="tool-btn" type="button" title="Стереть часть пометок">⌫ Ластик</button></div>
          <div id="draw-settings" class="toolbar-group draw-settings" hidden><label class="mini-field" title="Цвет маркера">Цвет <input id="draw-color" type="color" value="#ef4444"></label><label class="mini-field" title="Толщина линии">Толщина <input id="draw-size" type="range" min="2" max="20" value="5"></label><button id="clear-draw" class="tool-btn" type="button">Очистить пометки</button></div>
          <div class="toolbar-spacer"></div>
          <button id="btn-group-districts" class="tool-btn" type="button" aria-pressed="false">▦ Группировать районы</button>
        </div>
        <div id="graph-container" class="graph-container">
          <svg id="main-graph" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" role="img" aria-label="Интерактивный направленный граф объектов инфраструктуры">
            <defs>
              <marker id="arrow-water" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="userSpaceOnUse">
                <path d="M0 0L9 4.5 0 9Z" fill="#3b82f6" />
              </marker>
              <marker id="arrow-energy" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="userSpaceOnUse">
                <path d="M0 0L9 4.5 0 9Z" fill="#eab308" />
              </marker>
              <marker id="arrow-danger" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="userSpaceOnUse">
                <path d="M0 0L9 4.5 0 9Z" fill="#ef4444" />
              </marker>
            </defs>
            <g id="graph-viewport">
              <g id="layer-groups"></g>
              <g id="layer-edges"></g>
              <g id="layer-nodes"></g>
              <g id="layer-handles"></g>
              <g id="layer-draw"></g>
            </g>
          </svg>
          <div id="graph-empty" class="graph-empty" hidden>
            <div class="empty-icon">◇</div><strong>Граф пуст</strong>
            <p>Синхронизируйте данные с внешней БД, чтобы увидеть объекты и связи.</p>
          </div>
          <div class="minimap-container">
            <div class="minimap-title">МИНИ-КАРТА</div><svg id="minimap" viewBox="0 0 224 136" role="img" aria-label="Мини-карта для навигации">
              <g id="minimap-content"></g>
              <rect id="minimap-viewport" fill="rgba(59,130,246,.14)" stroke="#60a5fa" stroke-width="1.5" pointer-events="none" />
            </svg>
          </div>
          <div id="graph-tooltip" class="graph-tooltip" role="tooltip" hidden></div>
          <div class="graph-tip" id="graph-mode-hint">Перетащите узел для изменения компоновки · наведите курсор для зоны влияния</div>
        </div>
        <div class="timeline">
          <div class="timeline-main"><button id="timeline-play" class="btn btn-secondary timeline-play" type="button" title="Воспроизведение событий" disabled>▶</button>
            <div class="timeline-track">
              <div class="timeline-head"><strong>История изменений</strong><span id="timeline-label">Текущее состояние</span></div><input id="timeline-range" type="range" min="0" max="0" value="0" disabled>
            </div><button id="timeline-live" type="button" class="btn btn-subtle active">● Сейчас</button>
          </div>          
        </div>
        <div class="graph-legend"><span><i class="legend-dot water"></i> Вода</span><span><i class="legend-dot energy"></i> Электричество</span><span><i class="legend-dot accident"></i> Авария</span><span><i class="legend-dot repair"></i> Ремонт</span><span><i class="legend-dot affected"></i> Под влиянием</span><span><i class="legend-arrow"></i> Направление зависимости</span><span><b class="legend-index">7</b> Индекс критичности</span></div>
      </section>
      <section id="view-events" class="panel table-panel" hidden>
        <div class="panel-heading">
          <div>
            <div class="eyebrow">РЕЕСТР</div>
            <h3>События инфраструктуры</h3>
          </div>
          <div class="table-controls"><select id="events-mode-filter" aria-label="Режим событий">
              <option value="active">Активные</option>
              <option value="archive">Архив</option>
            </select><input id="events-search" type="search" placeholder="Поиск по событию…" aria-label="Поиск событий"></div>
        </div>
        <div class="table-scroll">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Объект</th>
                <th>Ресурс</th>
                <th>Возникновение</th>
                <th>Статус</th>
                <th></th>
              </tr>
            </thead>
            <tbody id="events-body">
              <tr>
                <td colspan="6" class="table-empty">Нет загруженных событий</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
      <section id="view-objects" class="panel table-panel" hidden>
        <div class="panel-heading">
          <div>
            <div class="eyebrow">РЕЕСТР</div>
            <h3>Объекты инфраструктуры</h3>
          </div><input id="objects-search" type="search" placeholder="Поиск объекта, адреса, района…" aria-label="Поиск объектов">
        </div>
        <div class="table-scroll">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Наименование</th>
                <th>Ресурсы</th>
                <th>Район</th>
                <th>Адрес</th>
                <th></th>
              </tr>
            </thead>
            <tbody id="objects-body">
              <tr>
                <td colspan="6" class="table-empty">Нет загруженных объектов</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>      
    </main>
  </div>
  <div id="node-modal" class="modal-overlay" hidden>
    <section class="modal-dialog" role="dialog" aria-modal="true" aria-labelledby="node-title" tabindex="-1">
      <header class="modal-heading">
        <div>
          <div class="eyebrow">КАРТОЧКА ОБЪЕКТА</div>
          <h2 id="node-title">Объект инфраструктуры</h2>
        </div><button id="close-node-modal" class="modal-close" type="button" aria-label="Закрыть карточку">×</button>
      </header>
      <div class="modal-body">
        <div id="node-info" class="node-info-grid"></div>
        <h3 class="modal-subhead">Полная история событий</h3>
        <div class="table-scroll history-scroll">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Ресурс</th>
                <th>Возникновение</th>
                <th>Статус события</th>
                <th>Архивный статус</th>
              </tr>
            </thead>
            <tbody id="node-history-body"></tbody>
          </table>
        </div>
      </div>
      <footer class="modal-actions"><button id="center-node-btn" class="btn btn-secondary" type="button">Показать на графе</button><button id="close-node-modal-bottom" class="btn btn-primary" type="button">Закрыть</button></footer>
    </section>
  </div>
  <div id="toast" class="toast" role="status" aria-live="polite" hidden></div>
</body>

</html>