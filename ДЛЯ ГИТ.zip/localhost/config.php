<?php

declare(strict_types=1);

// Прямой HTTP-доступ к файлу конфигурации запрещён.
if (
    PHP_SAPI !== 'cli'
    && isset($_SERVER['SCRIPT_FILENAME'])
    && realpath($_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__)
) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Not Found';
    exit;
}

return [
    'db' => [
        'local' => [
            'host'             => getenv('DEMO_LOCAL_HOST') ?: 'localhost',
            'port'             => (int) (getenv('DEMO_LOCAL_PORT') ?: 5432),
            'dbname'           => getenv('DEMO_LOCAL_DB') ?: 'postgres',
            'user'             => getenv('DEMO_LOCAL_USER') ?: 'postgres',
            'password'         => getenv('DEMO_LOCAL_PASSWORD') ?: 'postgres',
            'connect_timeout'  => 5,
            'application_name' => 'panorama-local',
        ],
        'external' => [
            'host'             => getenv('DEMO_EXTERNAL_HOST') ?: 'as.start',
            'port'             => (int) (getenv('DEMO_EXTERNAL_PORT') ?: 5432),
            'dbname'           => getenv('DEMO_EXTERNAL_DB') ?: 'main',
            'user'             => getenv('DEMO_EXTERNAL_USER') ?: 'anon',
            'password'         => getenv('DEMO_EXTERNAL_PASSWORD') ?: 'anon',
            'connect_timeout'  => 5,
            'application_name' => 'panorama-external',
        ],
    ],
    'app' => [
        'session_name'      => 'panorama_sid',
        'data_timezone'     => getenv('DEMO_DATA_TIMEZONE') ?: 'Europe/Moscow',
        'csrf_session_key'  => 'panorama_csrf',
        'csrf_token_bytes'  => 24,
    ],
];
