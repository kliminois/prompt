/* Клиент единого приложения: реальный граф, журналы, синхронизация и временная шкала. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";
  const escapeHtml = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  const resourceBadge = (r) =>
    `<span class="tag ${r === "water" ? "tag-water" : "tag-energy"}">${r === "water" ? "Водоснабжение" : "Электроснабжение"}</span>`;
  const statusBadge = (e) =>
    `<span class="tag ${e.id_status === 1 ? "tag-accident" : e.id_status === 2 ? "tag-repair" : "tag-done"}">${escapeHtml(e.status_name || (e.id_status === 1 ? "Активная авария" : e.id_status === 2 ? "Ремонтные работы" : "Норма"))}</span>`;
  const state = {
    view: "graph",
    graph: null,
    live: null,
    layout: null,
    at: null,
    timeline: [],
    playing: false,
    playTimer: null,
    requestId: 0,
    loading: false,
    syncing: false,
    modalOpen: false,
    selectedNode: null,
    toastTimer: null,
    firstLoad: true,
    lastHealth: 0,
    autoSyncEnabled: false,
  };
  let lastFocused = null;
  async function api(url, options = {}) {
    let response;
    try {
      response = await fetch(url, {
        credentials: "same-origin",
        cache: "no-store",
        ...options,
      });
    } catch (e) {
      throw new Error(
        "Нет связи с сервером приложения. Сохранённые данные остаются в локальной БД.",
      );
    }
    let json;
    try {
      json = await response.json();
    } catch (e) {
      throw new Error(
        "Некорректный ответ сервера (не JSON). Проверьте журнал PHP.",
      );
    }
    if (!response.ok || !json.ok)
      throw new Error(json.error || `Ошибка HTTP ${response.status}`);
    return json;
  }
  function showToast(message, error = false) {
    const el = $("toast");
    el.textContent = String(message);
    el.className = "toast" + (error ? " error" : "");
    el.hidden = false;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(
      () => (el.hidden = true),
      error ? 6500 : 3700,
    );
  }
  function setConnection(kind, text) {
    $("connection-pill").className = "connection-indicator " + kind;
    $("connection-text").textContent = text;
  }
  async function health() {
    try {
      const h = await api("api/health.php");
      if (h.local?.ok && h.local?.schema_ready) {
        setConnection(
          h.external?.ok ? "ok" : "bad",
          h.external?.ok
            ? "Локальная и внешняя БД доступны"
            : "Автономно · локальные данные доступны",
        );
      } else setConnection("bad", "Требуется настройка локальной БД");
    } catch (e) {
      setConnection("bad", "Ошибка подключения к приложению");
    }
  }
  function setView(view) {
    state.view = view;
    $$(".view-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.view === view);
      b.setAttribute(
        "aria-selected",
        b.dataset.view === view ? "true" : "false",
      );
    });
    ["graph", "events", "objects"].forEach((v) => {
      $(`view-${v}`).hidden = v !== view;
    });
    $("current-view-title").textContent = {
      graph: "Граф объектов",
      events: "Реестр событий",
      objects: "Реестр объектов",
    }[view];
    if (view === "events") loadEvents();
    else if (view === "objects") loadObjects();
    else
      requestAnimationFrame(() => {
        if (state.graph?.needsFitWhenVisible) state.graph.fit(true);
        else state.graph?.updateMinimap();
      });
  }
  function updateStats(nodes) {
    const counts = { accident: 0, repair: 0, affected: 0 };
    nodes.forEach((n) => {
      const sts = Object.values(n.states || {});
      if (sts.some((s) => s.state === "accident")) counts.accident++;
      else if (sts.some((s) => s.state === "repair")) counts.repair++;
      else if (sts.some((s) => s.state === "affected" || s.is_affected))
        counts.affected++;
    });
    $("stat-total").textContent = nodes.length;
    $("stat-accident").textContent = counts.accident;
    $("stat-repair").textContent = counts.repair;
    $("stat-affected").textContent = counts.affected;
  }
  function updateTimeline(points) {
    const wasLive = state.at === null;
    state.timeline = [...points];
    const slider = $("timeline-range");
    slider.max = Math.max(0, points.length);
    slider.disabled = points.length === 0;
    $("timeline-play").disabled = points.length === 0;
    if (wasLive) {
      slider.value = points.length;
      labelTimeline();
    } else {
      const idx = points.indexOf(state.at);
      slider.value = idx < 0 ? 0 : idx;
      if (idx < 0 && points.length) {
        state.at = points[0];
      }
      labelTimeline();
    }
  }
  function labelTimeline() {
    $("timeline-label").textContent =
      state.at === null
        ? "Текущее состояние"
        : state.at
          ? state.at
          : "Нет событий";
    $("timeline-live").classList.toggle("active", state.at === null);
    $("timeline-live").setAttribute(
      "aria-pressed",
      state.at === null ? "true" : "false",
    );
  }
  async function loadGraph({ silent = false } = {}) {
    if (state.loading) return;
    state.loading = true;
    try {
      const data = await api("api/graph.php");
      state.live = data;
      if (data.sync_state?.last_sync_at && state.firstLoad)
        $("sync-status").textContent =
          "Последняя синхронизация: " + data.sync_state.last_sync_at;
      if (state.firstLoad && data.nodes.length) state.autoSyncEnabled = true;
      state.graph.timestampOffset = data.timestamp_offset || "";
      updateStats(data.nodes);
      const before = state.timeline.join("|");
      const after = data.timeline.join("|");
      if (before !== after || state.firstLoad) updateTimeline(data.timeline);
      if (state.at === null) {
        state.graph.displayAt = null;
        state.graph.setData(
          data.nodes,
          data.edges,
          state.firstLoad ? state.layout : null,
        );
      } else {
        // Во время просмотра истории реальный опрос не меняет выбранный исторический кадр.
        const oldStates = new Map(
          state.graph.nodes.map((n) => [n.id, n.states]),
        );
        state.graph.setData(
          data.nodes.map((n) => ({
            ...n,
            states: oldStates.get(n.id) || n.states,
          })),
          data.edges,
        );
      }
      state.firstLoad = false;
      if (state.view === "events" && !silent) loadEvents();
      if (state.view === "objects" && !silent) loadObjects();
    } catch (e) {
      if (!silent) showToast(e.message, true);
      if (state.firstLoad) $("graph-empty").hidden = false;
    } finally {
      state.loading = false;
    }
  }
  async function setMoment(at) {
    stopPlayback();
    state.at = at;
    state.graph.displayAt = at;
    labelTimeline();
    $("timeline-range").value =
      at === null
        ? state.timeline.length
        : Math.max(0, state.timeline.indexOf(at));
    const req = ++state.requestId;
    if (at === null) {
      if (state.live) {
        state.graph.setData(state.live.nodes, state.live.edges);
        updateStats(state.live.nodes);
      }
      return;
    }
    try {
      const snapshot = await api("api/graph.php?at=" + encodeURIComponent(at));
      if (req !== state.requestId || state.at !== at) return;
      state.graph.setData(snapshot.nodes, snapshot.edges);
      updateStats(snapshot.nodes);
    } catch (e) {
      showToast(e.message, true);
    }
  }
  function stopPlayback() {
    state.playing = false;
    clearInterval(state.playTimer);
    state.playTimer = null;
    $("timeline-play").textContent = "▶";
    $("timeline-play").title = "Воспроизвести";
  }
  async function advanceFrame() {
    const count = state.timeline.length;
    if (!count) {
      stopPlayback();
      return;
    }
    let idx = state.at === null ? -1 : state.timeline.indexOf(state.at);
    if (idx >= count - 1) {
      stopPlayback();
      return;
    }
    state.at = state.timeline[idx + 1];
    state.graph.displayAt = state.at;
    $("timeline-range").value = idx + 1;
    labelTimeline();
    const request = ++state.requestId,
      at = state.at;
    try {
      const snapshot = await api("api/graph.php?at=" + encodeURIComponent(at));
      if (request !== state.requestId || state.at !== at) return;
      state.graph.setData(snapshot.nodes, snapshot.edges);
      updateStats(snapshot.nodes);
    } catch (e) {
      stopPlayback();
      showToast(e.message, true);
    }
  }
  function startPlayback() {
    if (!state.timeline.length) return;
    if (state.playing) {
      stopPlayback();
      return;
    }
    if (state.at === state.timeline[state.timeline.length - 1]) state.at = null;
    state.playing = true;
    $("timeline-play").textContent = "Ⅱ";
    $("timeline-play").title = "Пауза";
    advanceFrame();
    state.playTimer = setInterval(() => {
      if (!state.loading) advanceFrame();
    }, 1000);
  }
  function searchDebounce(fn, delay = 200) {
    let t;
    return () => {
      clearTimeout(t);
      t = setTimeout(fn, delay);
    };
  }
  function filterGraph() {
    state.graph.setFilters({
      search: $("graph-search").value,
      resource: $("filter-resource").value,
      state: $("filter-state").value,
      activeOnly: $("filter-active-only").checked,
    });
    const visible = state.graph.visibleNodes.length;
    if (state.graph.nodes.length) {
      $("graph-empty").hidden = visible > 0;
      if (!visible) {
        $("graph-empty").querySelector("strong").textContent =
          "Ничего не найдено";
        $("graph-empty").querySelector("p").textContent =
          "Попробуйте изменить фильтры или поисковый запрос.";
      }
    }
  }
  function setTool(mode) {
    ["pan", "edge", "draw", "erase"].forEach((m) =>
      $("tool-" + m).classList.toggle("active", m === mode),
    );    
    state.graph.setMode(mode);
    $("graph-mode-hint").textContent = {
      pan: "Перемещение: перетащите объект · выбор: нажмите на объект",
      edge: "Изгибы: нажмите на связь, затем перетащите контрольную точку",
      draw: "Маркер: рисуйте поверх графа мышью или пальцем",
      erase: "Ластик: проводите по фрагментам пометок",
    }[mode];
  }
  async function doSync({ manual = false } = {}) {
    if (state.syncing) return;
    state.syncing = true;
    $("btn-reset-data").disabled = true;
    if (manual) {
      $("sync-data").disabled = true;
      $("sync-data").textContent = "Синхронизация…";
    }
    try {
      const result = await api("api/sync.php", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
        body: JSON.stringify({ action: manual ? "sync" : "refresh" }),
      });
      $("sync-status").textContent =
        "Обновлено: " +
        (result.sync_state?.last_sync_at ||
          new Date().toLocaleTimeString("ru-RU"));
      setConnection("ok", "Локальная и внешняя БД доступны");
      state.autoSyncEnabled = true;
      await loadGraph({ silent: !manual });
      if (manual) {
        showToast("Объекты, события и связи синхронизированы");
        if (state.view === "events") loadEvents();
        if (state.view === "objects") loadObjects();
      }
    } catch (e) {
      setConnection("bad", "Автономно · внешняя БД недоступна");
      $("sync-status").textContent =
        "Внешний источник недоступен · отображается локальный кэш";
      if (manual) showToast(e.message, true);
    } finally {
      state.syncing = false;
      $("btn-reset-data").disabled = false;
      if (manual) {
        $("sync-data").disabled = false;
        $("sync-data").textContent = "↻ Синхронизировать";
      }
    }
  }
  async function resetData() {
    if (
      !window.confirm(
        "Удалить ВСЕ локально сохранённые объекты, связи, события и компоновку? Внешняя БД не затрагивается.",
      )
    )
      return;
    if (state.syncing) {
      showToast("Во время синхронизации сброс недоступен", true);
      return;
    }
    stopPlayback();
    state.requestId++;
    try {
      await api("api/sync.php", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
        body: JSON.stringify({ action: "reset" }),
      });
      state.autoSyncEnabled = false;
      state.firstLoad = false;
      state.layout = { nodes: [], edges: [] };
      state.at = null;
      state.timeline = [];
      state.live = null;
      state.graph.edgeControls.clear();
      state.graph.setGrouping(false);
      state.graph.clearAnnotations();
      try {
        localStorage.removeItem("panorama-groups-v3");
      } catch (_) {}
      $("btn-group-districts").classList.remove("active");
      $("btn-group-districts").setAttribute("aria-pressed", "false");
      state.graph.setData([], [], state.layout);
      updateTimeline([]);
      updateStats([]);
      $("graph-search").value = "";
      $("filter-resource").value = "";
      $("filter-state").value = "";
      $("filter-active-only").checked = false;
      filterGraph();
      $("events-body").innerHTML =
        '<tr><td colspan="6" class="table-empty">Нет данных</td></tr>';
      $("objects-body").innerHTML =
        '<tr><td colspan="6" class="table-empty">Нет данных</td></tr>';
      $("sync-status").textContent =
        "Система очищена · ожидается новая загрузка";
      showToast("Все локальные данные и пометки удалены");
    } catch (e) {
      showToast(e.message, true);
    }
  }
  async function loadEvents() {
    const tbody = $("events-body"),
      mode = $("events-mode-filter").value,
      search = $("events-search").value;
    try {
      const data = await api(
        `api/data.php?action=events&mode=${encodeURIComponent(mode)}&search=${encodeURIComponent(search)}&limit=5000`,
      );
      tbody.innerHTML = data.items.length
        ? data.items
            .map(
              (e) => `<tr>
        <td>#${e.id_event}</td><td>${escapeHtml(e.edifice_name)}</td>
        <td>${resourceBadge(e.resource_type)}</td><td>${escapeHtml(e.occurred_at)}</td><td>${statusBadge(e)}</td>
        <td><div class="table-actions"><button class="action-btn" data-node="${e.id_edifice}" type="button">Карточка</button></div></td></tr>`,
            )
            .join("")
        : '<tr><td colspan="6" class="table-empty">События по выбранным условиям отсутствуют</td></tr>';
    } catch (e) {
      tbody.innerHTML = `<tr><td colspan="6" class="table-empty">${escapeHtml(e.message)}</td></tr>`;
    }
  }
  async function loadObjects() {
    const tbody = $("objects-body"),
      search = $("objects-search").value;
    try {
      const data = await api(
        `api/data.php?action=objects&search=${encodeURIComponent(search)}`,
      );
      tbody.innerHTML = data.items.length
        ? data.items
            .map(
              (o) => `<tr>
        <td>#${o.id_edifice}</td><td>${escapeHtml(o.name)}</td><td><div class="tag-list">${o.resource_types.map(resourceBadge).join("")}</div></td>
        <td>${escapeHtml(o.district || "—")}</td><td>${escapeHtml([o.street, o.house_number].filter(Boolean).join(", ") || "—")}</td>
        <td><div class="table-actions"><button class="action-btn" data-node="${o.id_edifice}" type="button">Карточка</button><button class="action-btn" data-center="${o.id_edifice}" type="button">На графе</button></div></td></tr>`,
            )
            .join("")
        : '<tr><td colspan="6" class="table-empty">Объекты по выбранным условиям отсутствуют</td></tr>';
    } catch (e) {
      tbody.innerHTML = `<tr><td colspan="6" class="table-empty">${escapeHtml(e.message)}</td></tr>`;
    }
  }
  function infoCell(label, value) {
    return `<div class="info-cell"><small>${escapeHtml(label)}</small><div>${value}</div></div>`;
  }
  async function openNodeModal(id) {
    if (state.modalOpen) closeNodeModal();
    try {
      const data = await api(
        `api/data.php?action=history&id=${encodeURIComponent(id)}`,
      );
      const o = data.edifice;
      $("node-title").textContent = o.name;
      const current = state.graph?.nodeById.get(Number(id));
      $("node-info").innerHTML = [
        infoCell("ID объекта", "#" + o.id_edifice),
        infoCell(
          "Ресурсы",
          `<div class="tag-list">${o.resource_types.map(resourceBadge).join("")}</div>`,
        ),
        infoCell("Район", escapeHtml(o.district || "—")),
        infoCell(
          "Адрес",
          escapeHtml(
            [o.street, o.house_number].filter(Boolean).join(", ") || "—",
          ),
        ),
        infoCell(
          "Индекс критичности",
          String(current?.criticality ?? "—") + "/10",
        ),
      ].join("");
      $("node-history-body").innerHTML = data.events.length
        ? data.events
            .map(
              (e) =>
                `<tr><td>#${e.id_event}</td><td>${resourceBadge(e.resource_type)}</td><td>${escapeHtml(e.occurred_at)}</td><td>${statusBadge(e)}</td><td><span class="tag ${e.is_current ? "tag-live" : "tag-archive"}">${e.is_current ? "Текущий статус" : "В архиве"}</span></td></tr>`,
            )
            .join("")
        : '<tr><td colspan="5" class="table-empty">События не зарегистрированы</td></tr>';
      state.selectedNode = Number(id);
      lastFocused = document.activeElement;
      $("node-modal").hidden = false;
      document.body.style.overflow = "hidden";
      state.modalOpen = true;
      $("close-node-modal").focus();
    } catch (e) {
      showToast(e.message, true);
    }
  }
  function closeNodeModal() {
    $("node-modal").hidden = true;
    document.body.style.overflow = "";
    state.modalOpen = false;
    if (lastFocused?.isConnected) lastFocused.focus();
  }
  function showOnGraph(id) {
    closeNodeModal();
    setView("graph");
    const node = state.graph?.nodeById.get(Number(id));
    if (!node) {
      showToast("Объект не найден на графе", true);
      return;
    }
    // Навигация по результату поиска не должна оставлять объект скрытым фильтрами.
    $("graph-search").value = "";
    $("filter-resource").value = "";
    $("filter-state").value = "";
    $("filter-active-only").checked = false;
    filterGraph();
    if (
      state.graph.grouped &&
      state.graph.collapsed.has(state.graph.districtOf(node))
    )
      state.graph.toggleDistrict(state.graph.districtOf(node));
    requestAnimationFrame(() => state.graph.centerOnNode(id));
  }
  function initTheme() {
    const saved = (() => {
      try {
        return localStorage.getItem("panorama-theme-v3");
      } catch (_) {
        return null;
      }
    })();
    applyTheme(saved === "light");
    $("theme-toggle").addEventListener("click", () =>
      applyTheme(!document.body.classList.contains("theme-light")),
    );
  }
  function applyTheme(light) {
    document.body.classList.toggle("theme-light", light);
    $("theme-toggle").textContent = light ? "☾ Тёмная тема" : "☀ Светлая тема";
    try {
      localStorage.setItem("panorama-theme-v3", light ? "light" : "dark");
    } catch (_) {}
  }
  function initControls() {
    $$(".view-btn").forEach((b) =>
      b.addEventListener("click", () => setView(b.dataset.view)),
    );
    $("graph-search").addEventListener(
      "input",
      searchDebounce(filterGraph, 130),
    );
    ["filter-resource", "filter-state", "filter-active-only"].forEach((id) =>
      $(id).addEventListener("change", filterGraph),
    );
    $("reset-filters").addEventListener("click", () => {
      $("graph-search").value = "";
      $("filter-resource").value = "";
      $("filter-state").value = "";
      $("filter-active-only").checked = false;
      filterGraph();
    });
    $("zoom-in").addEventListener("click", () => state.graph.zoom(1.2));
    $("zoom-out").addEventListener("click", () => state.graph.zoom(0.8));
    $("zoom-reset").addEventListener("click", () => state.graph.fit());
    ["pan", "edge", "draw", "erase"].forEach((m) =>
      $("tool-" + m).addEventListener("click", () => setTool(m)),
    );
    $("draw-color").addEventListener(
      "input",
      (e) => (state.graph.drawColor = e.target.value),
    );
    $("draw-size").addEventListener(
      "input",
      (e) => (state.graph.drawSize = Number(e.target.value)),
    );
    $("clear-draw").addEventListener("click", () => {
      state.graph.clearAnnotations();
      showToast("Пометки удалены");
    });
    $("btn-group-districts").addEventListener("click", () => {
      const enabled = !state.graph.grouped;
      state.graph.setGrouping(enabled);
      $("btn-group-districts").classList.toggle("active", enabled);
      $("btn-group-districts").setAttribute(
        "aria-pressed",
        enabled ? "true" : "false",
      );
      $("btn-group-districts").textContent = enabled
        ? "▦ Районы · показать отдельно"
        : "▦ Группировать районы";
    });
    $("sync-data").addEventListener("click", () => doSync({ manual: true }));
    $("btn-reset-data").addEventListener("click", resetData);
    $("export-xlsx").addEventListener("click", () => {
      window.location.assign("api/export.php");
    });
    $("events-mode-filter").addEventListener("change", loadEvents);
    $("events-search").addEventListener("input", searchDebounce(loadEvents));
    $("objects-search").addEventListener("input", searchDebounce(loadObjects));
    $("events-body").addEventListener("click", (e) => {
      const b = e.target.closest("[data-node]");
      if (b) openNodeModal(b.dataset.node);
    });
    $("objects-body").addEventListener("click", (e) => {
      const b = e.target.closest("[data-node],[data-center]");
      if (!b) return;
      if (b.dataset.node) openNodeModal(b.dataset.node);
      else showOnGraph(b.dataset.center);
    });
    $("timeline-live").addEventListener("click", () => setMoment(null));
    $("timeline-play").addEventListener("click", startPlayback);
    $("timeline-range").addEventListener("input", (e) => {
      const index = Number(e.target.value);
      setMoment(index >= state.timeline.length ? null : state.timeline[index]);
    });
    $("close-node-modal").addEventListener("click", closeNodeModal);
    $("close-node-modal-bottom").addEventListener("click", closeNodeModal);
    $("center-node-btn").addEventListener("click", () =>
      showOnGraph(state.selectedNode),
    );
    $("node-modal").addEventListener("click", (e) => {
      if (e.target === $("node-modal")) closeNodeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (!state.modalOpen) return;
      if (e.key === "Escape") {
        e.preventDefault();
        closeNodeModal();
      }
      if (e.key === "Tab") {
        const focusable = [
          ...$("node-modal").querySelectorAll(
            "button:not(:disabled),a[href],input:not(:disabled)",
          ),
        ];
        if (!focusable.length) return;
        if (e.shiftKey && document.activeElement === focusable[0]) {
          e.preventDefault();
          focusable[focusable.length - 1].focus();
        } else if (
          !e.shiftKey &&
          document.activeElement === focusable[focusable.length - 1]
        ) {
          e.preventDefault();
          focusable[0].focus();
        }
      }
    });
  }
  async function init() {
    initTheme();
    state.graph = new GraphRenderer("graph-container", "minimap");
    state.graph.onSelect = openNodeModal;
    state.graph.onLayoutSave = async (payload) => {
      try {
        await api("api/layout.php", {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
          body: JSON.stringify(payload),
        });
      } catch (e) {
        showToast("Не удалось сохранить компоновку: " + e.message, true);
      }
    };
    initControls();
    await health();
    try {
      state.layout = await api("api/layout.php");
    } catch (_) {
      state.layout = { nodes: [], edges: [] };
    }
    await loadGraph();
    // Каждые 3 секунды проверяем внешнее состояние, без CDN и облака.
    // Ошибка соединения НЕ изменяет локальный кэш и НЕ блокирует просмотр.
    setInterval(() => {
      if (state.autoSyncEnabled) doSync();
    }, 3000);
    // Пересчет длительности на узлах в том числе при отключенной внешней БД.
    setInterval(() => {
      if (state.graph?.nodes.length && !state.graph.activePointer)
        state.graph.render();
    }, 30000);
  }
  window.addEventListener("DOMContentLoaded", init);
})();
