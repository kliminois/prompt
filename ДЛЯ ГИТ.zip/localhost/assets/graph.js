/* Панорама инфраструктуры. Нативный SVG, офлайн, ориентированный DAG, без внешних библиотек. */
"use strict";
class GraphRenderer {
  constructor(containerId, minimapId) {
    this.container = document.getElementById(containerId);
    this.svg = document.getElementById("main-graph");
    this.viewport = document.getElementById("graph-viewport");
    this.layers = Object.fromEntries(
      ["groups", "edges", "nodes", "handles", "draw"].map((k) => [
        k,
        document.getElementById("layer-" + k),
      ]),
    );
    this.minimap = document.getElementById(minimapId);
    this.miniContent = document.getElementById("minimap-content");
    this.miniViewport = document.getElementById("minimap-viewport");
    this.tooltip = document.getElementById("graph-tooltip");
    this.empty = document.getElementById("graph-empty");
    this.nodes = [];
    this.edges = [];
    this.nodeById = new Map();
    this.edgeById = new Map();
    this.edgeControls = new Map();
    this.transform = { x: 0, y: 0, k: 1 };
    this.mode = "pan";
    this.drawColor = "#ef4444";
    this.drawSize = 5;
    this.grouped = false;
    this.collapsed = new Set();
    this.filters = { search: "", resource: "", state: "", activeOnly: false };
    this.hoverId = null;
    this.selectedEdge = null;
    this.activePointer = null;
    this.strokes = [];
    this.drawing = null;
    this.onSelect = () => {};
    this.onLayoutSave = () => {};
    this.initialized = false;
    this.topologyKey = "";
    this.hasAnnotations = false;
    this.displayAt = null;
    this.visibleNodes = [];
    this.visibleEdges = [];
    this.visibleLookup = new Map();
    this._saveTimer = null;
    this.initEvents();
    this.loadAnnotations();
  }
  svgEl(name, attrs = {}, text = null) {
    const el = document.createElementNS("http://www.w3.org/2000/svg", name);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, String(v));
    if (text !== null) el.textContent = String(text);
    return el;
  }
  norm(s) {
    return String(s ?? "").toLocaleLowerCase("ru");
  }
  color(resource) {
    return resource === "water" ? "#3b82f6" : "#eab308";
  }
  resourceLabel(r) {
    return r === "water" ? "ВОДА" : "ЭЛЕКТРО";
  }
  stateLabel(s) {
    return (
      {
        accident: "АВАРИЯ",
        repair: "РЕМОНТ",
        affected: "ВЛИЯНИЕ",
        normal: "НОРМА",
      }[s] || "НОРМА"
    );
  }
  formatDuration(dateStr) {
    if (!dateStr) return "";
    const d = new Date(
      dateStr.replace(" ", "T") + (this.timestampOffset || ""),
    );
    if (!Number.isFinite(d.getTime())) return "";
    const end = this.displayAt
      ? new Date(
          this.displayAt.replace(" ", "T") + (this.timestampOffset || ""),
        ).getTime()
      : Date.now();
    const minutes = Math.max(0, Math.floor((end - d.getTime()) / 60000));
    const days = Math.floor(minutes / 1440),
      hours = Math.floor((minutes % 1440) / 60);
    return (
      (days ? `${days} д ` : "") +
      (hours ? `${hours} ч ` : "") +
      `${minutes % 60} мин`
    );
  }
  // Kahn + ранжирование по длине пути + barycentric ordering (стабильно, без случайных координат).
  static dagLayout(nodes, edges) {
    const byId = new Map(nodes.map((n) => [Number(n.id), n]));
    const indeg = new Map(nodes.map((n) => [Number(n.id), 0]));
    const out = new Map(nodes.map((n) => [Number(n.id), []]));
    const incoming = new Map(nodes.map((n) => [Number(n.id), []]));
    edges.forEach((e) => {
      if (!byId.has(Number(e.source)) || !byId.has(Number(e.dependent)))
        throw new Error("Связь с неизвестным объектом");
      out.get(Number(e.source)).push(Number(e.dependent));
      incoming.get(Number(e.dependent)).push(Number(e.source));
      indeg.set(Number(e.dependent), indeg.get(Number(e.dependent)) + 1);
    });
    const queue = [...indeg.keys()]
      .filter((id) => indeg.get(id) === 0)
      .sort((a, b) => a - b);
    const order = [],
      rank = new Map(nodes.map((n) => [Number(n.id), 0]));
    for (let head = 0; head < queue.length; head++) {
      const id = queue[head];
      order.push(id);
      for (const to of out.get(id)) {
        rank.set(to, Math.max(rank.get(to), rank.get(id) + 1));
        indeg.set(to, indeg.get(to) - 1);
        if (indeg.get(to) === 0) queue.push(to);
      }
    }
    if (order.length !== nodes.length)
      throw new Error("Недопустимый цикл в графе зависимостей (DAG)");
    const layers = new Map();
    for (const id of order) {
      const r = rank.get(id);
      if (!layers.has(r)) layers.set(r, []);
      layers.get(r).push(id);
    }
    const orderedLevels = [...layers.keys()].sort((a, b) => a - b);
    for (let pass = 0; pass < 4; pass++) {
      for (const level of orderedLevels.slice(1)) {
        const prev = new Map();
        for (const [r, ids] of layers)
          if (r < level) ids.forEach((id, i) => prev.set(id, i));
        layers.get(level).sort((a, b) => {
          const score = (id) => {
            const arr = incoming.get(id).filter((p) => prev.has(p));
            return arr.length
              ? arr.reduce((s, p) => s + prev.get(p), 0) / arr.length
              : Number.MAX_SAFE_INTEGER;
          };
          return score(a) - score(b) || a - b;
        });
      }
    }
    const coords = new Map();
    let maximum = Math.max(1, ...[...layers.values()].map((x) => x.length));
    for (const level of orderedLevels) {
      const ids = layers.get(level),
        offset = (maximum - ids.length) * 75;
      ids.forEach((id, i) =>
        coords.set(id, { x: 170 + level * 340, y: 130 + offset + i * 150 }),
      );
    }
    return coords;
  }
  static findCycle(nodes, edges) {
    const ids = new Set(nodes.map((n) => Number(n.id)));
    const indeg = new Map([...ids].map((id) => [id, 0]));
    const out = new Map([...ids].map((id) => [id, []]));
    for (const e of edges) {
      if (!ids.has(Number(e.source)) || !ids.has(Number(e.dependent)))
        return true;
      out.get(Number(e.source)).push(Number(e.dependent));
      indeg.set(Number(e.dependent), indeg.get(Number(e.dependent)) + 1);
    }
    const q = [...ids].filter((id) => indeg.get(id) === 0);
    let done = 0;
    for (let i = 0; i < q.length; i++) {
      done++;
      for (const id of out.get(q[i]))
        if (indeg.set(id, indeg.get(id) - 1).get(id) === 0) q.push(id);
    }
    return done !== ids.size;
  }
  setData(nodes, edges, layout = null) {
    const nextKey = JSON.stringify({
      nodes: nodes.map((n) => Number(n.id)).sort((a, b) => a - b),
      edges: edges
        .map((e) => [
          Number(e.id),
          Number(e.source),
          Number(e.dependent),
          e.resource_type,
        ])
        .sort((a, b) => a[0] - b[0]),
    });
    const structureChanged = nextKey !== this.topologyKey;
    const restoreGrouping = structureChanged && this.grouped;
    if (restoreGrouping) {
      // При смене топологии заново строим группы, не используя старые групповые
      // координаты как координаты основной DAG-схемы.
      this.nodes.forEach((n) => {
        const p = this.beforeGrouping?.get(n.id);
        if (p) {
          n.x = p.x;
          n.y = p.y;
        }
      });
      this.grouped = false;
      this.beforeGrouping = null;
      this.collapsed.clear();
    }
    if (structureChanged && GraphRenderer.findCycle(nodes, edges))
      throw new Error(
        "Источник содержит циклические зависимости. Визуализация запрещена.",
      );
    const previous = this.nodeById;
    const saved = new Map(
      (layout?.nodes || []).map((n) => [Number(n.id_edifice), n]),
    );
    const defaults = structureChanged
      ? GraphRenderer.dagLayout(nodes, edges)
      : new Map();
    this.nodes = nodes.map((raw) => {
      const id = Number(raw.id);
      const old = previous.get(id);
      const manual = saved.get(id),
        fallback = defaults.get(id);
      return {
        ...raw,
        id,
        x: old?.x ?? (manual ? Number(manual.x) : (fallback?.x ?? 100)),
        y: old?.y ?? (manual ? Number(manual.y) : (fallback?.y ?? 100)),
      };
    });
    this.edges = edges.map((e) => ({
      ...e,
      id: Number(e.id),
      source: Number(e.source),
      dependent: Number(e.dependent),
    }));
    this.nodeById = new Map(this.nodes.map((n) => [n.id, n]));
    this.edgeById = new Map(this.edges.map((e) => [e.id, e]));
    if (layout && !this.initialized)
      this.edgeControls = new Map(
        (layout.edges || []).map((e) => [
          Number(e.id_dependence),
          (e.control_points || [])
            .filter(
              (p) =>
                Number.isFinite(Number(p.x)) && Number.isFinite(Number(p.y)),
            )
            .map((p) => ({ x: Number(p.x), y: Number(p.y) }))
            .slice(0, 1),
        ]),
      );
    this.topologyKey = nextKey;
    this.initialized = true;
    this.render();
    this.empty.hidden = this.visibleNodes.length > 0;
    this.empty.querySelector("strong").textContent = this.nodes.length
      ? "Ничего не найдено"
      : "Граф пуст";
    this.empty.querySelector("p").textContent = this.nodes.length
      ? "Измените фильтры или поисковый запрос."
      : "Синхронизируйте данные с внешней БД, чтобы увидеть объекты и связи.";
    this.minimap.parentElement.hidden = this.nodes.length === 0;
    if (restoreGrouping) this.setGrouping(true);
    else if (structureChanged) this.fit(true);
  }
  updateStates(states) {
    this.nodes.forEach((n) => {
      if (states[n.id]) n.states = states[n.id];
    });
    this.render();
  }
  setFilters(next) {
    this.filters = { ...this.filters, ...next };
    this.render();
  }
  setMode(mode) {
    this.mode = mode;
    this.container.classList.toggle(
      "mode-marker",
      mode === "draw" || mode === "erase",
    );
    this.container.classList.toggle("mode-edge", mode === "edge");
    this.selectedEdge = null;
    this.hoverId = null;
    this.render();
  }
  setGrouping(enable) {
    enable = Boolean(enable);
    if (enable === this.grouped) return;
    if (enable) {
      // Групповая схема — отдельный слой. Сохраняем исходную DAG-компоновку,
      // чтобы выход из группировки никогда не накладывал узлы друг на друга.
      this.beforeGrouping = new Map(
        this.nodes.map((n) => [n.id, { x: n.x, y: n.y }]),
      );
      const groups = this.districtGroups();
      const cached = this.loadGroupedPositions();
      if (cached) {
        this.nodes.forEach((n) => {
          const v = cached[n.id];
          if (v) {
            n.x = v.x;
            n.y = v.y;
          }
        });
      } else {
        const entries = [...groups.entries()];
        let rowY = 165;
        for (let row = 0; row < Math.ceil(entries.length / 2); row++) {
          const groupsInRow = entries.slice(row * 2, row * 2 + 2);
          const tallest = Math.max(
            ...groupsInRow.map(([, items]) => Math.ceil(items.length / 2)),
          );
          for (let col = 0; col < groupsInRow.length; col++) {
            const [, items] = groupsInRow[col];
            const gx = 170 + col * 690;
            items.forEach((n, i) => {
              n.x = gx + (i % 2) * 275;
              n.y = rowY + Math.floor(i / 2) * 162;
            });
          }
          rowY += tallest * 162 + 170;
        }
      }
    } else {
      if (this.beforeGrouping)
        this.nodes.forEach((n) => {
          const v = this.beforeGrouping.get(n.id);
          if (v) {
            n.x = v.x;
            n.y = v.y;
          }
        });
      this.beforeGrouping = null;
      this.collapsed.clear();
    }
    this.grouped = enable;
    this.render();
    this.fit();
  }
  loadGroupedPositions() {
    try {
      const stored = JSON.parse(
        localStorage.getItem("panorama-groups-v3") || "null",
      );
      if (
        stored?.key === this.topologyKey &&
        stored.positions &&
        this.nodes.every(
          (n) =>
            stored.positions[n.id] &&
            Number.isFinite(stored.positions[n.id].x) &&
            Number.isFinite(stored.positions[n.id].y),
        )
      )
        return stored.positions;
    } catch (_) {
      /* storage may be disabled */
    }
    return null;
  }
  saveGroupedPositions() {
    const positions = {};
    this.nodes.forEach((n) => {
      positions[n.id] = { x: n.x, y: n.y };
    });
    try {
      localStorage.setItem(
        "panorama-groups-v3",
        JSON.stringify({ key: this.topologyKey, positions }),
      );
    } catch (_) {}
  }
  districtOf(n) {
    return String(n.district || "Без района");
  }
  districtGroups() {
    const result = new Map();
    this.nodes.forEach((n) => {
      const k = this.districtOf(n);
      if (!result.has(k)) result.set(k, []);
      result.get(k).push(n);
    });
    return new Map(
      [...result.entries()].sort((a, b) => a[0].localeCompare(b[0], "ru")),
    );
  }
  toggleDistrict(name) {
    if (this.collapsed.has(name)) this.collapsed.delete(name);
    else this.collapsed.add(name);
    this.render();
    this.fit();
  }
  matchingNodes() {
    const f = this.filters;
    const needle = this.norm(f.search).trim();
    return this.nodes.filter((n) => {
      if (
        needle &&
        ![n.name, n.id, n.district, n.street, n.house_number].some((v) =>
          this.norm(v).includes(needle),
        )
      )
        return false;
      const states = f.resource
        ? [n.states?.[f.resource]].filter(Boolean)
        : Object.values(n.states || {});
      if (f.resource && !n.resource_types.includes(f.resource)) return false;
      if (
        f.state &&
        !states.some(
          (s) =>
            s.state === f.state || (f.state === "affected" && s.is_affected),
        )
      )
        return false;
      if (
        f.activeOnly &&
        !states.some(
          (s) =>
            ["accident", "repair", "affected"].includes(s.state) ||
            s.is_affected,
        )
      )
        return false;
      return true;
    });
  }
  collapseRepresentative(district, items) {
    const allStates = {};
    const resources = [...new Set(items.flatMap((n) => n.resource_types))];
    const priority = { normal: 0, affected: 1, repair: 2, accident: 3 };
    items.forEach((n) =>
      Object.entries(n.states || {}).forEach(([r, st]) => {
        if (!allStates[r] || priority[st.state] > priority[allStates[r].state])
          allStates[r] = st;
      }),
    );
    const x = items.reduce((a, n) => a + n.x, 0) / items.length;
    const y = items.reduce((a, n) => a + n.y, 0) / items.length;
    return {
      key: "district:" + district,
      district,
      name: district,
      group: true,
      members: items.map((n) => n.id),
      count: items.length,
      resource_types: resources,
      states: allStates,
      criticality: Math.max(0, ...items.map((n) => n.criticality)),
      x,
      y,
    };
  }
  buildVisible() {
    const matching = this.matchingNodes(),
      selected = new Set(matching.map((n) => n.id));
    const visible = [],
      lookup = new Map();
    if (this.grouped) {
      for (const [name, items] of this.districtGroups()) {
        const filtered = items.filter((n) => selected.has(n.id));
        if (!filtered.length) continue;
        if (this.collapsed.has(name)) {
          const group = this.collapseRepresentative(name, filtered);
          visible.push(group);
          filtered.forEach((n) => lookup.set(n.id, group));
        } else
          filtered.forEach((n) => {
            visible.push(n);
            lookup.set(n.id, n);
          });
      }
    } else
      matching.forEach((n) => {
        visible.push(n);
        lookup.set(n.id, n);
      });
    const edgeMap = new Map();
    for (const e of this.edges) {
      if (this.filters.resource && e.resource_type !== this.filters.resource)
        continue;
      const s = lookup.get(e.source),
        d = lookup.get(e.dependent);
      if (!s || !d || s === d) continue;
      const from = s.group ? s.key : s.id,
        to = d.group ? d.key : d.id;
      const key = `${from}->${to}/${e.resource_type}`;
      if (!edgeMap.has(key))
        edgeMap.set(key, {
          key,
          source: s,
          dependent: d,
          resource_type: e.resource_type,
          ids: [],
        });
      edgeMap.get(key).ids.push(e.id);
    }
    this.visibleNodes = visible;
    this.visibleEdges = [...edgeMap.values()];
    this.visibleLookup = lookup;
  }
  // Распространение только source -> dependent и ТОЛЬКО в пределах ресурса зависимости.
  influenceFrom(startId, resource) {
    const visited = new Set([startId]),
      edgeIds = new Set(),
      queue = [startId];
    for (let i = 0; i < queue.length; i++) {
      const id = queue[i];
      for (const e of this.edges) {
        if (e.source !== id || e.resource_type !== resource) continue;
        const from = this.nodeById.get(e.source),
          to = this.nodeById.get(e.dependent);
        if (
          !from?.resource_types.includes(resource) ||
          !to?.resource_types.includes(resource)
        )
          continue;
        edgeIds.add(e.id);
        if (!visited.has(e.dependent)) {
          visited.add(e.dependent);
          queue.push(e.dependent);
        }
      }
    }
    return { nodes: visited, edges: edgeIds };
  }
  currentHighlights() {
    const source = new Set(),
      affected = new Set(),
      edges = new Set();
    const collect = (id, resource) => {
      source.add(id);
      const z = this.influenceFrom(id, resource);
      z.nodes.forEach((n) => {
        if (n !== id) affected.add(n);
      });
      z.edges.forEach((e) => edges.add(e));
    };
    for (const n of this.nodes)
      for (const [r, st] of Object.entries(n.states || {}))
        if (st.state === "accident") collect(n.id, r);
    if (this.hoverId !== null) {
      const n = this.nodeById.get(this.hoverId);
      if (n)
        for (const r of n.resource_types)
          if (!this.filters.resource || this.filters.resource === r)
            collect(n.id, r);
    }
    return { source, affected, edges };
  }
  shortLabel(s, max = 25) {
    const v = String(s || "");
    return v.length > max ? v.slice(0, max - 1) + "…" : v;
  }
  render() {
    this.buildVisible();
    const highlight = this.currentHighlights();
    this.renderGroups();
    this.layers.edges.replaceChildren();
    this.layers.nodes.replaceChildren();
    this.layers.handles.replaceChildren();
    for (const e of this.visibleEdges) this.drawEdge(e, highlight);
    for (const n of this.visibleNodes) this.drawNode(n, highlight);
    this.drawEdgeHandle();
    this.redrawAnnotations();
    this.updateMinimap();
  }
  renderGroups() {
    this.layers.groups.replaceChildren();
    if (!this.grouped) return;
    for (const [district, items] of this.districtGroups()) {
      const subset = items.filter((n) => this.visibleLookup.has(n.id));
      if (!subset.length || this.collapsed.has(district)) continue;
      const minX = Math.min(...subset.map((n) => n.x)) - 143,
        maxX = Math.max(...subset.map((n) => n.x)) + 143;
      const minY = Math.min(...subset.map((n) => n.y)) - 95,
        maxY = Math.max(...subset.map((n) => n.y)) + 85;
      this.layers.groups.appendChild(
        this.svgEl("rect", {
          x: minX,
          y: minY,
          width: maxX - minX,
          height: maxY - minY,
          rx: 17,
          class: "district-boundary",
        }),
      );
      const header = this.svgEl("g", {
        class: "district-header",
        "data-district": district,
        role: "button",
        "aria-label": `Свернуть район ${district}`,
      });
      header.appendChild(
        this.svgEl("rect", {
          x: minX + 15,
          y: minY - 18,
          width: Math.max(130, Math.min(310, district.length * 9 + 92)),
          height: 31,
          rx: 10,
          class: "district-header-bg",
        }),
      );
      header.appendChild(
        this.svgEl(
          "text",
          { x: minX + 28, y: minY + 3, class: "district-header-text" },
          `▾  ${district} · ${subset.length}`,
        ),
      );
      this.layers.groups.appendChild(header);
    }
  }
  boundsFor(n) {
    return { halfW: 118, halfH: 51 };
  }
  edgePoint(a, b) {
    const dx = b.x - a.x,
      dy = b.y - a.y,
      { halfW: w, halfH: h } = this.boundsFor(a);
    if (Math.abs(dx) < 0.0001 && Math.abs(dy) < 0.0001)
      return { x: a.x, y: a.y };
    const t = Math.min(
      Math.abs(w / (dx || 0.0001)),
      Math.abs(h / (dy || 0.0001)),
    );
    return { x: a.x + dx * t, y: a.y + dy * t };
  }
  edgePath(e) {
    const cp = e.ids.length === 1 ? this.edgeControls.get(e.ids[0])?.[0] : null;
    const start = this.edgePoint(e.source, cp || e.dependent),
      end = this.edgePoint(e.dependent, cp || e.source);
    return cp
      ? `M ${start.x} ${start.y} Q ${cp.x} ${cp.y} ${end.x} ${end.y}`
      : `M ${start.x} ${start.y} L ${end.x} ${end.y}`;
  }
  drawEdge(e, h) {
    const active = e.ids.some((id) => h.edges.has(id));
    const activeColor = e.resource_type === "water" ? "#38bdf8" : "#fbbf24";
    const cls =
      "edge-path " +
      (active ? "influence-edge " : "") +
      (e.resource_type === "energy" ? "energy-edge" : "water-edge");
    const path = this.svgEl("path", {
      d: this.edgePath(e),
      class: cls,
      "data-edge": e.ids.length === 1 ? e.ids[0] : "",
      "marker-end": `url(#arrow-${e.resource_type})`,
    });
    path.setAttribute(
      "stroke",
      active ? activeColor : this.color(e.resource_type),
    );
    const hit = this.svgEl("path", {
      d: path.getAttribute("d"),
      class: "edge-hit",
      "data-edge": e.ids.length === 1 ? e.ids[0] : "",
    });
    this.layers.edges.append(path, hit);
  }
  drawNode(n, h) {
    const isSource = n.group
      ? n.members.some((id) => h.source.has(id))
      : h.source.has(n.id);
    const isAffected = n.group
      ? n.members.some((id) => h.affected.has(id))
      : h.affected.has(n.id);
    const group = this.svgEl("g", {
      class: `graph-node${n.group ? " group-node" : ""}${isSource ? " origin-node" : ""}${isAffected ? " impacted-node" : ""}`,
      transform: `translate(${n.x} ${n.y})`,
    });
    if (n.group) group.dataset.district = n.district;
    else group.dataset.id = String(n.id);
    group.appendChild(
      this.svgEl("rect", {
        x: -118,
        y: -51,
        width: 236,
        height: 102,
        rx: 14,
        class: "node-card",
      }),
    );
    group.appendChild(
      this.svgEl("rect", {
        x: -118,
        y: -51,
        width: 5,
        height: 102,
        rx: 3,
        fill: n.group
          ? "#8b5cf6"
          : n.resource_types.length > 1
            ? "#8b5cf6"
            : this.color(n.resource_types[0]),
      }),
    );
    group.appendChild(
      this.svgEl(
        "text",
        { x: -103, y: -23, class: "node-title" },
        this.shortLabel(n.name, n.group ? 20 : 27),
      ),
    );
    group.appendChild(
      this.svgEl("rect", {
        x: 84,
        y: -41,
        width: 26,
        height: 24,
        rx: 7,
        class: "node-index-bg",
      }),
    );
    group.appendChild(
      this.svgEl("text", { x: 97, y: -24, class: "node-index" }, n.criticality),
    );
    if (n.group)
      group.appendChild(
        this.svgEl(
          "text",
          { x: -102, y: 45, class: "node-sublabel" },
          `▦ Район · ${n.count} объектов · развернуть`,
        ),
      );
    else
      group.appendChild(
        this.svgEl(
          "text",
          { x: -103, y: 45, class: "node-sublabel" },
          `#${n.id}  ·  ${this.shortLabel(this.districtOf(n), 22)}`,
        ),
      );
    const resources = n.resource_types.slice(0, 2);
    resources.forEach((r, i) => {
      const st = n.states?.[r];
      const state = st?.state || "normal";
      const x = -102 + i * 105;
      group.appendChild(
        this.svgEl("rect", {
          x,
          y: -10,
          width: 98,
          height: 27,
          rx: 7,
          class: `node-status status-${state} resource-${r}`,
        }),
      );
      group.appendChild(
        this.svgEl(
          "text",
          { x: x + 7, y: 8, class: "node-status-label" },
          `${r === "water" ? "◉" : "◆"} ${this.stateLabel(state)}`,
        ),
      );
    });
    const incidentResources = n.resource_types
      .map((r) => ({ r, st: n.states?.[r] }))
      .filter((x) => x.st);
    const priority = { accident: 3, affected: 2, repair: 1, normal: 0 };
    incidentResources.sort(
      (a, b) => (priority[b.st.state] || 0) - (priority[a.st.state] || 0),
    );
    const incident = incidentResources.find(
      (x) => x.st.state !== "normal" || x.st.is_affected,
    );
    if (incident) {
      const st = incident.st;
      const started =
        st.state === "accident" || st.state === "repair"
          ? st.occurred_at
          : st.accident_occurred_at;
      const duration = this.formatDuration(started);
      if (duration)
        group.appendChild(
          this.svgEl(
            "text",
            { x: -103, y: 31, class: "node-duration" },
            `◷ ${this.shortLabel(duration, 20)} · ${incident.r === "water" ? "вода" : "электро"}`,
          ),
        );
    }
    group.appendChild(
      this.svgEl("title", {}, `${n.name} · критичность ${n.criticality}/10`),
    );
    this.layers.nodes.appendChild(group);
  }
  drawEdgeHandle() {
    if (this.mode !== "edge" || this.selectedEdge === null) return;
    const original = this.edgeById.get(this.selectedEdge),
      from = original && this.visibleLookup.get(original.source),
      to = original && this.visibleLookup.get(original.dependent);
    if (!from || !to || from === to) return;
    const cp = this.edgeControls.get(original.id)?.[0] || {
      x: (from.x + to.x) / 2,
      y: (from.y + to.y) / 2,
    };
    this.layers.handles.appendChild(
      this.svgEl("circle", {
        cx: cp.x,
        cy: cp.y,
        r: 11,
        class: "edge-handle",
        "data-edge": original.id,
      }),
    );
  }
  showTooltip(node, e) {
    if (!node || this.mode === "draw" || this.mode === "erase") {
      this.tooltip.hidden = true;
      return;
    }
    const escaped = (s) =>
      String(s ?? "").replace(
        /[&<>"']/g,
        (c) =>
          ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
          })[c],
      );
    const rows = node.group
      ? [`<div>${node.count} объектов в районе</div>`]
      : [
          `<div class="tooltip-line">Критичность <b>${node.criticality}/10</b></div>`,
        ];
    if (!node.group) {
      const ids = new Set();
      node.resource_types.forEach((r) =>
        this.influenceFrom(node.id, r).nodes.forEach((id) => {
          if (id !== node.id) ids.add(id);
        }),
      );
      rows.push(
        `<div class="tooltip-line">Всего зависимых объектов <b>${ids.size}</b></div>`,
      );
    }
    for (const r of node.resource_types) {
      const st = node.states?.[r];
      if (!st) continue;
      let label = this.stateLabel(st.state);
      const start =
        st.state === "accident"
          ? st.occurred_at
          : st.is_affected
            ? st.accident_occurred_at
            : null;
      if (start) label += " · " + this.formatDuration(start);
      rows.push(
        `<div class="tooltip-line"><span>${r === "water" ? "Вода" : "Электро"}</span><b>${escaped(label)}</b></div>`,
      );
      if (st.state === "accident") {
        const influence = this.influenceFrom(node.id, r);
        rows.push(
          `<div class="tooltip-line">Затронуто (${r === "water" ? "вода" : "электро"}) <b>${influence.nodes.size - 1}</b></div>`,
        );
      }
    }
    this.tooltip.innerHTML = `<strong>${escaped(node.name)}</strong>${rows.join("")}`;
    this.tooltip.hidden = false;
    const rect = this.container.getBoundingClientRect();
    this.tooltip.style.left =
      Math.max(8, Math.min(e.clientX - rect.left + 17, rect.width - 290)) +
      "px";
    this.tooltip.style.top =
      Math.max(8, Math.min(e.clientY - rect.top + 18, rect.height - 140)) +
      "px";
  }
  clientPoint(e) {
    const rect = this.svg.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left - this.transform.x) / this.transform.k,
      y: (e.clientY - rect.top - this.transform.y) / this.transform.k,
    };
  }
  initEvents() {
    this.container.addEventListener(
      "wheel",
      (e) => {
        if (!this.nodes.length) return;
        e.preventDefault();
        this.zoom(e.deltaY > 0 ? 0.88 : 1.12, e.clientX, e.clientY);
      },
      { passive: false },
    );
    this.svg.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const nodeEl = e.target.closest(".graph-node");
      const groupHeader = e.target.closest(".district-header");
      const handle = e.target.closest(".edge-handle");
      const path = e.target.closest(".edge-hit");
      const point = this.clientPoint(e);
      if (this.mode === "draw") {
        this.drawing = {
          color: this.drawColor,
          size: this.drawSize,
          points: [point],
        };
        this.strokes.push(this.drawing);
        this.activePointer = { kind: "draw", id: e.pointerId };
      } else if (this.mode === "erase") {
        this.eraseAt(point);
        this.activePointer = { kind: "erase", id: e.pointerId };
      } else if (groupHeader) {
        this.toggleDistrict(groupHeader.dataset.district);
        return;
      } else if (this.mode === "edge") {
        if (handle) {
          const id = Number(handle.dataset.edge);
          this.selectedEdge = id;
          this.activePointer = {
            kind: "edge",
            id: e.pointerId,
            edge: id,
            moved: false,
          };
        } else if (path && path.dataset.edge) {
          this.selectedEdge = Number(path.dataset.edge);
          this.render();
          return;
        } else {
          this.activePointer = {
            kind: "pan",
            id: e.pointerId,
            x: e.clientX,
            y: e.clientY,
            moved: false,
          };
        }
      } else if (nodeEl?.dataset.district) {
        this.toggleDistrict(nodeEl.dataset.district);
        return;
      } else if (nodeEl?.dataset.id) {
        const id = Number(nodeEl.dataset.id),
          n = this.nodeById.get(id);
        this.activePointer = {
          kind: "node",
          id: e.pointerId,
          node: id,
          dx: n.x - point.x,
          dy: n.y - point.y,
          moved: false,
          startX: e.clientX,
          startY: e.clientY,
        };
      } else
        this.activePointer = {
          kind: "pan",
          id: e.pointerId,
          x: e.clientX,
          y: e.clientY,
          moved: false,
        };
      if (this.activePointer) {
        e.preventDefault();
        this.svg.setPointerCapture(e.pointerId);
      }
    });
    this.svg.addEventListener("pointermove", (e) => {
      const active = this.activePointer;
      if (active && active.id === e.pointerId) {
        const p = this.clientPoint(e);
        if (active.kind === "node") {
          if (
            Math.hypot(e.clientX - active.startX, e.clientY - active.startY) > 4
          )
            active.moved = true;
          if (active.moved) {
            const n = this.nodeById.get(active.node);
            n.x = p.x + active.dx;
            n.y = p.y + active.dy;
            this.render();
          }
        } else if (active.kind === "pan") {
          if (
            Math.abs(active.x - e.clientX) + Math.abs(active.y - e.clientY) >
            2
          )
            active.moved = true;
          this.transform.x += e.clientX - active.x;
          this.transform.y += e.clientY - active.y;
          active.x = e.clientX;
          active.y = e.clientY;
          this.applyTransform();
        } else if (active.kind === "edge") {
          this.edgeControls.set(active.edge, [{ x: p.x, y: p.y }]);
          active.moved = true;
          this.render();
        } else if (active.kind === "draw") {
          const pts = this.drawing?.points;
          if (
            pts &&
            Math.hypot(
              p.x - pts[pts.length - 1].x,
              p.y - pts[pts.length - 1].y,
            ) >
              1.3 / this.transform.k
          ) {
            pts.push(p);
            this.redrawAnnotations();
          }
        } else if (active.kind === "erase") this.eraseAt(p);
        this.tooltip.hidden = true;
        return;
      }
      if (this.mode === "draw" || this.mode === "erase") return;
      const el = e.target.closest(".graph-node");
      let n = null;
      if (el?.dataset.id) n = this.nodeById.get(Number(el.dataset.id));
      else if (el?.dataset.district)
        n = this.visibleNodes.find(
          (x) => x.group && x.district === el.dataset.district,
        );
      const newHover = n?.group ? null : (n?.id ?? null);
      if (newHover !== this.hoverId) {
        this.hoverId = newHover;
        this.render();
      }
      this.showTooltip(n, e);
    });
    const finish = (e) => {
      const a = this.activePointer;
      if (!a || a.id !== e.pointerId) return;
      if (a.kind === "node") {
        if (a.moved) this.persistLayout("nodes");
        else this.onSelect(a.node);
      } else if (a.kind === "edge" && a.moved) this.persistLayout("edges");
      else if (a.kind === "draw" || a.kind === "erase") this.saveAnnotations();
      this.activePointer = null;
      this.drawing = null;
      try {
        this.svg.releasePointerCapture(e.pointerId);
      } catch (_) {
        /* pointer may already be released */
      }
    };
    this.svg.addEventListener("pointerup", finish);
    this.svg.addEventListener("pointercancel", finish);
    this.svg.addEventListener("pointerleave", () => {
      if (!this.activePointer) {
        this.hoverId = null;
        this.render();
        this.tooltip.hidden = true;
      }
    });
    this.minimap.addEventListener("pointerdown", (e) => {
      if (!this.nodes.length) return;
      e.preventDefault();
      const rect = this.minimap.getBoundingClientRect(),
        mx = ((e.clientX - rect.left) * 224) / rect.width,
        my = ((e.clientY - rect.top) * 136) / rect.height;
      const info = this.miniInfo();
      const x = (mx - info.ox) / info.scale + info.bbox.minX,
        y = (my - info.oy) / info.scale + info.bbox.minY;
      this.transform.x = this.container.clientWidth / 2 - x * this.transform.k;
      this.transform.y = this.container.clientHeight / 2 - y * this.transform.k;
      this.applyTransform();
    });
    if (typeof ResizeObserver !== "undefined")
      this.resizeObserver = new ResizeObserver(() => this.updateMinimap());
    this.resizeObserver?.observe(this.container);
  }
  zoom(factor, clientX, clientY) {
    const rect = this.container.getBoundingClientRect();
    const px = clientX === undefined ? rect.width / 2 : clientX - rect.left;
    const py = clientY === undefined ? rect.height / 2 : clientY - rect.top;
    const old = this.transform.k,
      next = Math.max(0.14, Math.min(3, old * factor));
    this.transform.x = px - ((px - this.transform.x) * next) / old;
    this.transform.y = py - ((py - this.transform.y) * next) / old;
    this.transform.k = next;
    this.applyTransform();
  }
  applyTransform() {
    const t = this.transform;
    this.viewport.setAttribute(
      "transform",
      `translate(${t.x} ${t.y}) scale(${t.k})`,
    );
    this.updateMinimap();
  }
  getGraphBBox() {
    const ns = this.visibleNodes.length ? this.visibleNodes : this.nodes;
    if (!ns.length) return { minX: 0, minY: 0, width: 400, height: 300 };
    const minX = Math.min(...ns.map((n) => n.x)) - 155,
      maxX = Math.max(...ns.map((n) => n.x)) + 155;
    const minY = Math.min(...ns.map((n) => n.y)) - 103,
      maxY = Math.max(...ns.map((n) => n.y)) + 103;
    return { minX, minY, width: maxX - minX, height: maxY - minY };
  }
  fit(readable = false) {
    if (!this.nodes.length) return;
    const b = this.getGraphBBox(),
      w = this.container.clientWidth,
      h = this.container.clientHeight;
    if (w <= 0 || h <= 0) {
      this.needsFitWhenVisible = true;
      return;
    }
    this.needsFitWhenVisible = false;
    const fitted = Math.max(
      0.14,
      Math.min(1.15, Math.min((w - 35) / b.width, (h - 35) / b.height)),
    );
    const k = readable ? Math.max(0.75, fitted) : fitted;
    const x =
      readable && k > fitted + 0.03
        ? 28 - b.minX * k
        : w / 2 - (b.minX + b.width / 2) * k;
    this.transform = { k, x, y: h / 2 - (b.minY + b.height / 2) * k };
    this.applyTransform();
  }
  centerOnNode(id) {
    const n = this.nodeById.get(Number(id));
    if (!n) return;
    this.transform.x = this.container.clientWidth / 2 - n.x * this.transform.k;
    this.transform.y = this.container.clientHeight / 2 - n.y * this.transform.k;
    this.applyTransform();
  }
  miniInfo() {
    const bbox = this.getGraphBBox();
    const scale = Math.min(208 / bbox.width, 120 / bbox.height);
    return {
      bbox,
      scale,
      ox: (224 - bbox.width * scale) / 2,
      oy: (136 - bbox.height * scale) / 2,
    };
  }
  updateMinimap() {
    if (!this.nodes.length) return;
    const { bbox, scale, ox, oy } = this.miniInfo();
    const xy = (n) => ({
      x: ox + (n.x - bbox.minX) * scale,
      y: oy + (n.y - bbox.minY) * scale,
    });
    const fragment = document.createDocumentFragment();
    for (const e of this.visibleEdges) {
      const a = xy(e.source),
        b = xy(e.dependent);
      fragment.appendChild(
        this.svgEl("line", {
          x1: a.x,
          y1: a.y,
          x2: b.x,
          y2: b.y,
          class: "mini-edge",
        }),
      );
    }
    for (const n of this.visibleNodes) {
      const p = xy(n);
      fragment.appendChild(
        this.svgEl("circle", {
          cx: p.x,
          cy: p.y,
          r: n.group ? 5 : 3.2,
          fill: n.group
            ? "#a78bfa"
            : n.resource_types.includes("water")
              ? "#60a5fa"
              : "#eab308",
        }),
      );
    }
    this.miniContent.replaceChildren(fragment);
    const { x, y, k } = this.transform;
    const vl = -x / k,
      vt = -y / k,
      vw = this.container.clientWidth / k,
      vh = this.container.clientHeight / k;
    for (const [key, value] of Object.entries({
      x: ox + (vl - bbox.minX) * scale,
      y: oy + (vt - bbox.minY) * scale,
      width: vw * scale,
      height: vh * scale,
    }))
      this.miniViewport.setAttribute(key, String(value));
  }
  persistLayout(kind = "both") {
    if (this.grouped && kind === "nodes") {
      this.saveGroupedPositions();
      return;
    }
    clearTimeout(this._saveTimer);
    this._saveTimer = setTimeout(() => {
      this.onLayoutSave({
        nodes:
          this.grouped || kind === "edges"
            ? []
            : this.nodes.map((n) => ({ id_edifice: n.id, x: n.x, y: n.y })),
        edges:
          kind === "nodes"
            ? []
            : [...this.edgeControls.entries()].map(([id, control_points]) => ({
                id_dependence: id,
                control_points,
              })),
      });
    }, 350);
  }
  pathD(points) {
    return points
      .map((p, i) => `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
      .join(" ");
  }
  redrawAnnotations() {
    this.layers.draw.replaceChildren();
    for (const stroke of this.strokes) {
      if (!stroke.points.length) continue;
      const points =
        stroke.points.length === 1
          ? [
              stroke.points[0],
              { x: stroke.points[0].x + 0.01, y: stroke.points[0].y + 0.01 },
            ]
          : stroke.points;
      this.layers.draw.appendChild(
        this.svgEl("path", {
          d: this.pathD(points),
          stroke: stroke.color,
          "stroke-width": stroke.size,
          fill: "none",
          opacity: ".66",
          "stroke-linecap": "round",
          "stroke-linejoin": "round",
          class: "annotation-line",
        }),
      );
    }
  }
  eraseAt(p) {
    // Стирание отдельного участка: разбиение полилинии на независимые фрагменты.
    const out = [];
    const radius = 12 / this.transform.k;
    for (const stroke of this.strokes) {
      let segment = [];
      const parts = [];
      const close = (q) =>
        Math.hypot(q.x - p.x, q.y - p.y) < radius + stroke.size / 2;
      const points = [];
      for (let i = 0; i < stroke.points.length; i++) {
        points.push(stroke.points[i]);
        if (i > 0) {
          const a = stroke.points[i - 1],
            b = stroke.points[i],
            dist = Math.hypot(b.x - a.x, b.y - a.y);
          const count = Math.min(
            50,
            Math.floor(dist / Math.max(1, radius / 3)),
          );
          for (let j = 1; j < count; j++)
            points.splice(points.length - 1, 0, {
              x: a.x + ((b.x - a.x) * j) / count,
              y: a.y + ((b.y - a.y) * j) / count,
            });
        }
      }
      for (const q of points) {
        if (close(q)) {
          if (segment.length > 1) parts.push(segment);
          segment = [];
        } else segment.push(q);
      }
      if (segment.length > 1) parts.push(segment);
      parts.forEach((part) => out.push({ ...stroke, points: part }));
    }
    this.strokes = out;
    this.redrawAnnotations();
  }
  loadAnnotations() {
    try {
      const val = JSON.parse(
        localStorage.getItem("panorama-annotations-v3") || "[]",
      );
      if (Array.isArray(val))
        this.strokes = val
          .filter((s) => Array.isArray(s.points) && s.points.length < 10000)
          .slice(0, 300);
    } catch (_) {
      this.strokes = [];
    }
  }
  saveAnnotations() {
    try {
      localStorage.setItem(
        "panorama-annotations-v3",
        JSON.stringify(this.strokes),
      );
    } catch (_) {
      /* storage blocked */
    }
  }
  clearAnnotations() {
    this.strokes = [];
    this.redrawAnnotations();
    try {
      localStorage.removeItem("panorama-annotations-v3");
    } catch (_) {}
  }
}
window.GraphRenderer = GraphRenderer;
