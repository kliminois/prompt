<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/validate.php';
require_once __DIR__ . '/graph.php';

/** Преобразует PHP-массив строк в литерал PG-массива. */
function pg_array_literal(array $values): string
{
    if (empty($values)) {
        return '{}';
    }
    $parts = [];
    foreach ($values as $v) {
        if ($v === null) {
            $parts[] = 'NULL';
            continue;
        }
        $s = (string) $v;
        $parts[] = '"' . str_replace(['\\', '"'], ['\\\\', '\\"'], $s) . '"';
    }
    return '{' . implode(',', $parts) . '}';
}

/**
 * Синхронизация локального кэша с внешней БД.
 * Использует upsert + удаление отсутствующих; layout сохраняется.
 */
function sync_from_external(): array
{
    $stats = [
        'edifices_upserted'     => 0,
        'dependencies_upserted' => 0,
        'events_upserted'       => 0,
        'statuses_upserted'     => 0,
        'edifices_removed'      => 0,
        'dependencies_removed'  => 0,
        'events_removed'        => 0,
        'started_at'            => date('c'),
    ];

    $ext = db_external();

    $edifices = db_all(
        $ext,
        'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                district, street, house_number
           FROM public.edifices
          ORDER BY id_edifice'
    );
    $deps = db_all(
        $ext,
        'SELECT id_dependence, resource_type, id_edifice_source, id_edifice_dependent
           FROM public.edifice_dependencies
          ORDER BY id_dependence'
    );
    $events = db_all(
        $ext,
        "SELECT id_event, id_edifice, resource_type,
                to_char(occurred_at, 'YYYY-MM-DD HH24:MI:SS') AS occurred_at,
                id_status
           FROM public.events
          ORDER BY id_event"
    );
    $statuses = db_all(
        $ext,
        'SELECT id_status, name FROM public.event_statuses ORDER BY id_status'
    );

    // Проверка целостности всего полученного снимка ДО первой записи в локальный кэш.
    $validatedEdifices = [];
    foreach ($edifices as $e) {
        $validatedEdifices[] = [
            'id_edifice' => (int) $e['id_edifice'],
            'resource_types' => json_decode((string) $e['resource_type_json'], true) ?: [],
        ];
    }
    $validatedDependencies = [];
    foreach ($deps as $d) {
        $validatedDependencies[] = [
            'id_dependence' => (int) $d['id_dependence'],
            'source' => (int) $d['id_edifice_source'],
            'dependent' => (int) $d['id_edifice_dependent'],
            'resource_type' => (string) $d['resource_type'],
        ];
    }
    graph_assert_valid($validatedEdifices, $validatedDependencies);

    $loc = db_local();
    db_begin($loc);
    try {
        foreach ($statuses as $s) {
            db_exec(
                $loc,
                'INSERT INTO cache_event_statuses (id_status, name) VALUES ($1, $2)
                 ON CONFLICT (id_status) DO UPDATE SET name = EXCLUDED.name',
                [(int) $s['id_status'], (string) $s['name']]
            );
            $stats['statuses_upserted']++;
        }

        $extEdificeIds = [];
        foreach ($edifices as $e) {
            $id = (int) $e['id_edifice'];
            $extEdificeIds[] = $id;

            $resourcesRaw = json_decode((string) ($e['resource_type_json'] ?? '[]'), true);
            if (!is_array($resourcesRaw)) {
                $resourcesRaw = [];
            }
            $resources = [];
            foreach ($resourcesRaw as $r) {
                if (is_string($r) && in_array($r, ['water', 'energy'], true)) {
                    $resources[] = $r;
                }
            }
            $pgArray = pg_array_literal($resources);

            db_exec(
                $loc,
                'INSERT INTO cache_edifices
                     (id_edifice, name, resource_type, district, street, house_number)
                 VALUES ($1, $2, $3::varchar[], $4, $5, $6)
                 ON CONFLICT (id_edifice) DO UPDATE SET
                     name          = EXCLUDED.name,
                     resource_type = EXCLUDED.resource_type,
                     district      = EXCLUDED.district,
                     street        = EXCLUDED.street,
                     house_number  = EXCLUDED.house_number',
                [
                    $id,
                    (string) $e['name'],
                    $pgArray,
                    $e['district'] !== null ? (string) $e['district'] : null,
                    $e['street'] !== null ? (string) $e['street'] : null,
                    $e['house_number'] !== null ? (string) $e['house_number'] : null,
                ]
            );
            $stats['edifices_upserted']++;
        }

        if (empty($extEdificeIds)) {
            $stats['edifices_removed'] = db_exec($loc, 'DELETE FROM cache_edifices');
        } else {
            $placeholders = [];
            $params = [];
            foreach ($extEdificeIds as $i => $id) {
                $placeholders[] = '$' . ($i + 1);
                $params[] = $id;
            }
            $stats['edifices_removed'] = db_exec(
                $loc,
                'DELETE FROM cache_edifices WHERE id_edifice NOT IN (' . implode(',', $placeholders) . ')',
                $params
            );
        }

        $validEdificeIds = array_flip($extEdificeIds);
        $extDepIds = [];
        foreach ($deps as $d) {
            $id = (int) $d['id_dependence'];
            $src = (int) $d['id_edifice_source'];
            $dst = (int) $d['id_edifice_dependent'];
            if (!isset($validEdificeIds[$src]) || !isset($validEdificeIds[$dst])) {
                continue;
            }
            if ($src === $dst) {
                continue;
            }
            $res = v_enum((string) $d['resource_type'], ['water', 'energy'], null);
            if ($res === null) {
                continue;
            }
            db_exec(
                $loc,
                'INSERT INTO cache_edifice_dependencies
                     (id_dependence, resource_type, id_edifice_source, id_edifice_dependent)
                 VALUES ($1, $2, $3, $4)
                 ON CONFLICT (id_dependence) DO UPDATE SET
                     resource_type        = EXCLUDED.resource_type,
                     id_edifice_source    = EXCLUDED.id_edifice_source,
                     id_edifice_dependent = EXCLUDED.id_edifice_dependent',
                [$id, $res, $src, $dst]
            );
            $extDepIds[] = $id;
            $stats['dependencies_upserted']++;
        }

        if (empty($extDepIds)) {
            $stats['dependencies_removed'] = db_exec($loc, 'DELETE FROM cache_edifice_dependencies');
        } else {
            $placeholders = [];
            $params = [];
            foreach ($extDepIds as $i => $id) {
                $placeholders[] = '$' . ($i + 1);
                $params[] = $id;
            }
            $stats['dependencies_removed'] = db_exec(
                $loc,
                'DELETE FROM cache_edifice_dependencies WHERE id_dependence NOT IN (' . implode(',', $placeholders) . ')',
                $params
            );
        }

        $extEventIds = [];
        foreach ($events as $ev) {
            $id = (int) $ev['id_event'];
            $edificeId = (int) $ev['id_edifice'];
            if (!isset($validEdificeIds[$edificeId])) {
                continue;
            }
            $res = v_enum((string) $ev['resource_type'], ['water', 'energy'], null);
            if ($res === null) {
                continue;
            }
            $occurredAt = v_datetime((string) $ev['occurred_at']);
            if ($occurredAt === null) {
                continue;
            }
            db_exec(
                $loc,
                'INSERT INTO cache_events
                     (id_event, id_edifice, resource_type, occurred_at, id_status)
                 VALUES ($1, $2, $3, $4::timestamp, $5)
                 ON CONFLICT (id_event) DO UPDATE SET
                     id_edifice    = EXCLUDED.id_edifice,
                     resource_type = EXCLUDED.resource_type,
                     occurred_at   = EXCLUDED.occurred_at,
                     id_status     = EXCLUDED.id_status',
                [$id, $edificeId, $res, $occurredAt, (int) $ev['id_status']]
            );
            $extEventIds[] = $id;
            $stats['events_upserted']++;
        }

        if (empty($extEventIds)) {
            $stats['events_removed'] = db_exec($loc, 'DELETE FROM cache_events');
        } else {
            $placeholders = [];
            $params = [];
            foreach ($extEventIds as $i => $id) {
                $placeholders[] = '$' . ($i + 1);
                $params[] = $id;
            }
            $stats['events_removed'] = db_exec(
                $loc,
                'DELETE FROM cache_events WHERE id_event NOT IN (' . implode(',', $placeholders) . ')',
                $params
            );
        }

        $message = sprintf(
            'Объекты: +%d/-%d; связи: +%d/-%d; события: +%d/-%d; статусы: %d',
            $stats['edifices_upserted'],
            $stats['edifices_removed'],
            $stats['dependencies_upserted'],
            $stats['dependencies_removed'],
            $stats['events_upserted'],
            $stats['events_removed'],
            $stats['statuses_upserted']
        );

        db_exec(
            $loc,
            'UPDATE cache_sync_state
                SET last_sync_at = NOW(), last_status = $1, last_message = $2, updated_at = NOW()
              WHERE id = 1',
            ['ok', $message]
        );

        db_commit($loc);
    } catch (Throwable $e) {
        db_rollback($loc);
        try {
            db_exec(
                $loc,
                'UPDATE cache_sync_state
                    SET last_status = $1, last_message = $2, updated_at = NOW()
                  WHERE id = 1',
                ['error', $e->getMessage()]
            );
        } catch (Throwable $ignored) {
            error_log('[panorama][sync] failed to record error: ' . $ignored->getMessage());
        }
        throw $e;
    }

    $stats['finished_at'] = date('c');
    return $stats;
}

/** Текущее состояние синхронизации. */
function sync_state(): ?array
{
    $loc = db_local();
    $row = db_one(
        $loc,
        "SELECT to_char(last_sync_at, 'YYYY-MM-DD HH24:MI:SS') AS last_sync_at,
                last_status, last_message,
                to_char(updated_at, 'YYYY-MM-DD HH24:MI:SS') AS updated_at
           FROM cache_sync_state
          WHERE id = 1"
    );
    return $row === null ? null : $row;
}

/**
 * Быстрое периодическое обновление событий и справочника статусов.
 * Данные обновляются одной транзакцией; удаление/изменение внешних событий
 * безопасно синхронизируется без потери графа и пользовательской компоновки.
 * Для изменения топологии используется полный sync_from_external().
 */
function sync_refresh_events(): array
{
    $ext = db_external();
    $events = db_all(
        $ext,
        "SELECT id_event, id_edifice, resource_type,
                to_char(occurred_at, 'YYYY-MM-DD HH24:MI:SS') AS occurred_at, id_status
           FROM public.events ORDER BY id_event"
    );
    $statuses = db_all($ext, 'SELECT id_status, name FROM public.event_statuses ORDER BY id_status');
    $objects = db_all($ext, 'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                                   district, street, house_number FROM public.edifices ORDER BY id_edifice');
    $edges = db_all($ext, 'SELECT id_dependence, id_edifice_source, id_edifice_dependent, resource_type
                              FROM public.edifice_dependencies ORDER BY id_dependence');
    $loc = db_local();
    // Топология меняется редко: сравнение точных идентификаторов/концов/ресурсов.
    // При появлении новой вершины/связи полный импорт и пересчёт критичности.
    $localNodes = db_all($loc, 'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                                      district, street, house_number FROM cache_edifices ORDER BY id_edifice');
    $localEdges = db_all($loc, 'SELECT id_dependence, id_edifice_source, id_edifice_dependent, resource_type
                                 FROM cache_edifice_dependencies ORDER BY id_dependence');
    if ($objects !== $localNodes || $edges !== $localEdges) {
        $stats = sync_from_external();
        return ['full' => true, 'events' => $stats['events_upserted']];
    }
    $payload = [];
    foreach ($events as $ev) {
        if (!in_array((string) $ev['resource_type'], ['water', 'energy'], true)) {
            throw new InvalidArgumentException('Некорректный ресурс события #' . $ev['id_event']);
        }
        $when = v_datetime((string) $ev['occurred_at']);
        if ($when === null) {
            throw new InvalidArgumentException('Некорректная дата события #' . $ev['id_event']);
        }
        $payload[] = [
            'id_event' => (int) $ev['id_event'],
            'id_edifice' => (int) $ev['id_edifice'],
            'resource_type' => (string) $ev['resource_type'],
            'occurred_at' => $when,
            'id_status' => (int) $ev['id_status'],
        ];
    }
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new RuntimeException('Ошибка сериализации изменений событий');
    }
    db_begin($loc);
    try {
        foreach ($statuses as $s) {
            db_exec(
                $loc,
                'INSERT INTO cache_event_statuses (id_status, name) VALUES ($1, $2)
                 ON CONFLICT (id_status) DO UPDATE SET name=EXCLUDED.name
                 WHERE cache_event_statuses.name IS DISTINCT FROM EXCLUDED.name',
                [(int) $s['id_status'], (string) $s['name']]
            );
        }
        $columns = '(id_event integer, id_edifice integer, resource_type text, occurred_at text, id_status integer)';
        db_exec(
            $loc,
            'INSERT INTO cache_events (id_event, id_edifice, resource_type, occurred_at, id_status)
             SELECT e.id_event, e.id_edifice, e.resource_type, e.occurred_at::timestamp, e.id_status::smallint
               FROM jsonb_to_recordset($1::jsonb) AS e' . $columns . '
             WHERE TRUE
             ON CONFLICT (id_event) DO UPDATE SET
               id_edifice=EXCLUDED.id_edifice, resource_type=EXCLUDED.resource_type,
               occurred_at=EXCLUDED.occurred_at, id_status=EXCLUDED.id_status
             WHERE (cache_events.id_edifice, cache_events.resource_type, cache_events.occurred_at, cache_events.id_status)
               IS DISTINCT FROM (EXCLUDED.id_edifice, EXCLUDED.resource_type, EXCLUDED.occurred_at, EXCLUDED.id_status)',
            [$json]
        );
        db_exec(
            $loc,
            'DELETE FROM cache_events WHERE id_event NOT IN
             (SELECT e.id_event FROM jsonb_to_recordset($1::jsonb) AS e(id_event integer))',
            [$json]
        );
        db_exec(
            $loc,
            'UPDATE cache_sync_state SET last_sync_at=NOW(), last_status=$1,
              last_message=$2, updated_at=NOW() WHERE id=1',
            ['ok', 'Автоматическое обновление событий: ' . count($events)]
        );
        db_commit($loc);
    } catch (Throwable $e) {
        db_rollback($loc);
        throw $e;
    }
    return ['full' => false, 'events' => count($events)];
}
