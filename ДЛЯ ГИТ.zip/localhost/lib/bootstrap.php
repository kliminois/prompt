<?php

declare(strict_types=1);

require_once __DIR__ . '/response.php';

/**
 * Возвращает конфигурацию приложения (однократное чтение).
 */
function app_config(): array
{
    static $cache = null;
    if ($cache === null) {
        $loaded = require __DIR__ . '/../config.php';
        if (!is_array($loaded)) {
            throw new RuntimeException('Конфигурация должна возвращать массив');
        }
        $cache = $loaded;
    }
    return $cache;
}

/**
 * Лениво стартует сессию с безопасными cookie-опциями.
 */
function app_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $cfg = app_config();
    session_name((string) $cfg['app']['session_name']);
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
        'cookie_path'     => '/',
        'use_strict_mode' => true,
    ]);
}

/**
 * Возвращает CSRF-токен сессии (создаёт при первом обращении).
 */
function csrf_token(): string
{
    app_session();
    $cfg = app_config();
    $key = (string) $cfg['app']['csrf_session_key'];
    if (!isset($_SESSION[$key]) || !is_string($_SESSION[$key]) || $_SESSION[$key] === '') {
        $bytes = (int) ($cfg['app']['csrf_token_bytes'] ?? 24);
        if ($bytes < 16) {
            $bytes = 16;
        }
        $_SESSION[$key] = bin2hex(random_bytes($bytes));
    }
    return (string) $_SESSION[$key];
}

/**
 * Проверяет CSRF-токен без учёта времени сравнения.
 */
function csrf_verify(?string $token): bool
{
    if ($token === null || $token === '') {
        return false;
    }
    app_session();
    $cfg = app_config();
    $key = (string) $cfg['app']['csrf_session_key'];
    if (!isset($_SESSION[$key]) || !is_string($_SESSION[$key])) {
        return false;
    }
    return hash_equals($_SESSION[$key], $token);
}

/**
 * Устанавливает общие обработчики исключений и фатальных ошибок.
 * Никогда не выводит стек или пути к файлам клиенту.
 */
function api_setup(): void
{
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    error_reporting(E_ALL);

    set_exception_handler(static function (Throwable $e): void {
        error_log('[panorama][exception] ' . $e->getMessage()
            . ' @ ' . $e->getFile() . ':' . $e->getLine());
        if (!headers_sent()) {
            json_error('Внутренняя ошибка сервера', 500);
        }
    });

    register_shutdown_function(static function (): void {
        $err = error_get_last();
        if ($err === null) {
            return;
        }
        $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
        if (!in_array($err['type'], $fatalTypes, true)) {
            return;
        }
        error_log('[panorama][fatal] ' . $err['message']
            . ' @ ' . $err['file'] . ':' . $err['line']);
        if (!headers_sent()) {
            json_error('Критическая ошибка сервера', 500);
        }
    });
}

api_setup();
