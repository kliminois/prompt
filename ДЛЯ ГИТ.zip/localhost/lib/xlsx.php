<?php

declare(strict_types=1);

/**
 * Минимальный XLSX-генератор без CDN/Node.
 * Требует расширение php-zip (ZipArchive).
 */
final class XlsxWriter
{
    /** @var array<int,array{name:string,rows:array,colWidths:array}> */
    private $sheets = [];

    /** @var array<int,string> */
    private $sharedStrings = [];

    /** @var array<string,int> */
    private $sharedStringIndex = [];

    public function __construct()
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('Расширение zip не установлено — экспорт XLSX недоступен');
        }
    }

    /**
     * @param string $name      Имя листа
     * @param array  $rows      Строки данных
     * @param array  $colWidths Ширины столбцов [1=>ширина, 2=>ширина, ...].
     *                          По умолчанию первые 10 столбцов получают ширину 40.
     */
    public function addSheet(string $name, array $rows, array $colWidths = []): void
    {
        if (count($this->sheets) >= 20) {
            throw new RuntimeException('Слишком много листов XLSX');
        }
        $safe = preg_replace('/[\\\\\\/\\?\\*\\[\\]:]/', ' ', $name);
        $safe = $safe === null ? 'Sheet' : $safe;
        $safe = trim($safe);
        if ($safe === '') {
            $safe = 'Sheet';
        }
        if (function_exists('mb_substr')) {
            $safe = mb_substr($safe, 0, 31, 'UTF-8');
        } else {
            $safe = substr($safe, 0, 31);
        }

        // Ширины по умолчанию: столбцы A–F = 40
        if (empty($colWidths)) {
            $colWidths = [1 => 40, 2 => 40, 3 => 40, 4 => 40, 5 => 40, 6 => 40, 7 => 40, 8 => 40, 9 => 40, 10 => 40];
        }

        $this->sheets[] = ['name' => $safe, 'rows' => $rows, 'colWidths' => $colWidths];
    }

    private function pushString(string $value): int
    {
        if (isset($this->sharedStringIndex[$value])) {
            return $this->sharedStringIndex[$value];
        }
        $idx = count($this->sharedStrings);
        $this->sharedStrings[] = $value;
        $this->sharedStringIndex[$value] = $idx;
        return $idx;
    }

    private function colLetter(int $index): string
    {
        $index++;
        $letter = '';
        while ($index > 0) {
            $rem = ($index - 1) % 26;
            $letter = chr(65 + $rem) . $letter;
            $index = (int) (($index - $rem - 1) / 26);
        }
        return $letter;
    }

    private function xml(string $value): string
    {
        return str_replace(
            ['&', '<', '>', '"', "'"],
            ['&amp;', '&lt;', '&gt;', '&quot;', '&apos;'],
            $value
        );
    }

    private function buildSheetXml(array $rows, array $colWidths): string
    {
        $out = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $out .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';

        // ─── Ширины столбцов ───
        if (!empty($colWidths)) {
            $out .= '<cols>';
            foreach ($colWidths as $colNum => $width) {
                $out .= '<col min="' . (int)$colNum . '" max="' . (int)$colNum
                    . '" width="' . (float)$width . '" customWidth="1"/>';
            }
            $out .= '</cols>';
        }

        $out .= '<sheetData>';
        foreach ($rows as $rowIndex => $row) {
            $out .= '<row r="' . ($rowIndex + 1) . '">';
            $col = 0;
            foreach ($row as $cell) {
                $ref = $this->colLetter($col) . ($rowIndex + 1);
                if ($cell === null || $cell === '') {
                    $col++;
                    continue;
                }
                if (is_int($cell) || is_float($cell)) {
                    $out .= '<c r="' . $ref . '"><v>' . $cell . '</v></c>';
                } else {
                    $idx = $this->pushString((string) $cell);
                    $out .= '<c r="' . $ref . '" t="s"><v>' . $idx . '</v></c>';
                }
                $col++;
            }
            $out .= '</row>';
        }
        $out .= '</sheetData></worksheet>';
        return $out;
    }

    private function buildSharedStringsXml(): string
    {
        $count = count($this->sharedStrings);
        $out = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $out .= '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="'
            . $count . '" uniqueCount="' . $count . '">';
        foreach ($this->sharedStrings as $s) {
            $out .= '<si><t xml:space="preserve">' . $this->xml($s) . '</t></si>';
        }
        $out .= '</sst>';
        return $out;
    }

    private function buildWorkbookXml(): string
    {
        $out = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $out .= '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
            . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
        foreach ($this->sheets as $i => $sheet) {
            $out .= '<sheet name="' . $this->xml($sheet['name']) . '" sheetId="' . ($i + 1)
                . '" r:id="rId' . ($i + 1) . '"/>';
        }
        $out .= '</sheets></workbook>';
        return $out;
    }

    private function buildWorkbookRelsXml(): string
    {
        $out = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $out .= '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
        foreach ($this->sheets as $i => $sheet) {
            $out .= '<Relationship Id="rId' . ($i + 1)
                . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"'
                . ' Target="worksheets/sheet' . ($i + 1) . '.xml"/>';
        }
        $out .= '<Relationship Id="rId' . (count($this->sheets) + 1)
            . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings"'
            . ' Target="sharedStrings.xml"/>';
        $out .= '</Relationships>';
        return $out;
    }

    private function buildRootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1"'
            . ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"'
            . ' Target="xl/workbook.xml"/></Relationships>';
    }

    private function buildContentTypesXml(): string
    {
        $out = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $out .= '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">';
        $out .= '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>';
        $out .= '<Default Extension="xml" ContentType="application/xml"/>';
        $out .= '<Override PartName="/xl/workbook.xml"'
            . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>';
        foreach ($this->sheets as $i => $sheet) {
            $out .= '<Override PartName="/xl/worksheets/sheet' . ($i + 1) . '.xml"'
                . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        $out .= '<Override PartName="/xl/sharedStrings.xml"'
            . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>';
        $out .= '<Override PartName="/xl/styles.xml"'
            . ' ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        $out .= '</Types>';
        return $out;
    }

    private function buildStylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>'
            . '<fills count="2"><fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>'
            . '</styleSheet>';
    }

    public function output(string $filename): void
    {
        $sheetXmls = [];
        foreach ($this->sheets as $i => $sheet) {
            $sheetXmls[$i] = $this->buildSheetXml($sheet['rows'], $sheet['colWidths']);
        }

        $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');
        if ($tmp === false) {
            throw new RuntimeException('Не удалось создать временный файл XLSX');
        }

        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
            @unlink($tmp);
            throw new RuntimeException('Не удалось открыть ZIP-контейнер XLSX');
        }

        $zip->addFromString('[Content_Types].xml', $this->buildContentTypesXml());
        $zip->addFromString('_rels/.rels', $this->buildRootRelsXml());
        $zip->addFromString('xl/workbook.xml', $this->buildWorkbookXml());
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->buildWorkbookRelsXml());
        $zip->addFromString('xl/sharedStrings.xml', $this->buildSharedStringsXml());
        $zip->addFromString('xl/styles.xml', $this->buildStylesXml());
        foreach ($sheetXmls as $i => $xml) {
            $zip->addFromString('xl/worksheets/sheet' . ($i + 1) . '.xml', $xml);
        }
        $zip->close();

        $size = filesize($tmp);
        if (!headers_sent()) {
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            if ($size !== false) {
                header('Content-Length: ' . $size);
            }
            header('Cache-Control: no-store');
            header('X-Content-Type-Options: nosniff');
        }
        readfile($tmp);
        @unlink($tmp);
        exit;
    }
}