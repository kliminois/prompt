<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';

/** Полная загрузка данных кэша для графа. */
function graph_load_data(): array
{
    $loc = db_local();

    $edificesRows = db_all(
        $loc,
        'SELECT id_edifice, name, array_to_json(resource_type) AS resource_type_json,
                district, street, house_number
           FROM cache_edifices
          ORDER BY id_edifice'
    );
    $depsRows = db_all(
        $loc,
        'SELECT id_dependence, resource_type, id_edifice_source, id_edifice_dependent
           FROM cache_edifice_dependencies
          ORDER BY id_dependence'
    );
    $eventRows = db_all(
        $loc,
        "SELECT id_event, id_edifice, resource_type,
                to_char(occurred_at, 'YYYY-MM-DD HH24:MI:SS') AS occurred_at,
                id_status
           FROM cache_events
          ORDER BY occurred_at, id_event"
    );

    $edifices = [];
    foreach ($edificesRows as $row) {
        $resources = json_decode((string) ($row['resource_type_json'] ?? '[]'), true);
        if (!is_array($resources)) {
            $resources = [];
        }
        $clean = [];
        foreach ($resources as $r) {
            if (is_string($r) && in_array($r, ['water', 'energy'], true)) {
                $clean[] = $r;
            }
        }
        $edifices[] = [
            'id_edifice'     => (int) $row['id_edifice'],
            'name'           => (string) $row['name'],
            'resource_types' => $clean,
            'district'       => $row['district'],
            'street'         => $row['street'],
            'house_number'   => $row['house_number'],
        ];
    }

    $dependencies = [];
    foreach ($depsRows as $row) {
        $dependencies[] = [
            'id_dependence' => (int) $row['id_dependence'],
            'resource_type' => (string) $row['resource_type'],
            'source'        => (int) $row['id_edifice_source'],
            'dependent'     => (int) $row['id_edifice_dependent'],
        ];
    }

    $events = [];
    foreach ($eventRows as $row) {
        $events[] = [
            'id_event'      => (int) $row['id_event'],
            'id_edifice'    => (int) $row['id_edifice'],
            'resource_type' => (string) $row['resource_type'],
            'occurred_at'   => (string) $row['occurred_at'],
            'id_status'     => (int) $row['id_status'],
        ];
    }

    return [
        'edifices'     => $edifices,
        'dependencies' => $dependencies,
        'events'       => $events,
    ];
}

/**
 * Индекс критичности 0..10.
 * Считает уникальные downstream-объекты (source → dependent, любые ресурсы).
 */
function graph_criticality(array $edifices, array $dependencies): array
{
    $adj = [];
    foreach ($edifices as $e) {
        $adj[$e['id_edifice']] = [];
    }
    foreach ($dependencies as $d) {
        $src = $d['source'];
        $dst = $d['dependent'];
        if (isset($adj[$src])) {
            $adj[$src][$dst] = true;
        }
    }

    $counts = [];
    $maxCount = 0;
    foreach (array_keys($adj) as $id) {
        $visited = [];
        $stack = array_keys($adj[$id]);
        while (!empty($stack)) {
            $cur = array_pop($stack);
            if (isset($visited[$cur])) {
                continue;
            }
            $visited[$cur] = true;
            if (isset($adj[$cur])) {
                foreach (array_keys($adj[$cur]) as $next) {
                    if (!isset($visited[$next])) {
                        $stack[] = $next;
                    }
                }
            }
        }
        unset($visited[$id]);
        $counts[$id] = count($visited);
        if ($counts[$id] > $maxCount) {
            $maxCount = $counts[$id];
        }
    }

    $criticality = [];
    foreach ($counts as $id => $c) {
        if ($maxCount === 0 || $c === 0) {
            $criticality[$id] = 0;
        } else {
            $criticality[$id] = $c === $maxCount ? 10 : max(1, min(9, (int) round(10 * $c / $maxCount)));
        }
    }
    return $criticality;
}

/**
 * Состояния объектов по ресурсам на момент $at (null = текущее).
 *
 * Возвращает [edificeId => [resource => [
 *   state, status_id, event_id, occurred_at,
 *   is_affected, accident_source_id, accident_occurred_at
 * ]]]
 */
function graph_states(array $edifices, array $dependencies, array $events, ?string $at = null): array
{
    $cutoff = $at ?? (new DateTimeImmutable('now', new DateTimeZone((string) (app_config()['app']['data_timezone'] ?? 'Europe/Moscow'))))->format('Y-m-d H:i:s');
    $byKey = [];
    foreach ($events as $ev) {
        if ($ev['occurred_at'] > $cutoff) {
            continue;
        }
        $key = $ev['id_edifice'] . ':' . $ev['resource_type'];
        $cur = $byKey[$key] ?? null;
        if (
            $cur === null
            || $ev['occurred_at'] > $cur['occurred_at']
            || ($ev['occurred_at'] === $cur['occurred_at'] && $ev['id_event'] > $cur['id_event'])
        ) {
            $byKey[$key] = $ev;
        }
    }

    $self = [];
    foreach ($edifices as $e) {
        $id = $e['id_edifice'];
        foreach ($e['resource_types'] as $res) {
            $self[$id][$res] = $byKey[$id . ':' . $res] ?? null;
        }
    }

    $adj = [];
    foreach ($dependencies as $d) {
        $adj[$d['source']][$d['resource_type']][$d['dependent']] = true;
    }

    $affected = [];
    foreach ($self as $edificeId => $resStates) {
        foreach ($resStates as $res => $ev) {
            if ($ev === null || $ev['id_status'] !== 1) {
                continue;
            }
            $queue = [];
            if (isset($adj[$edificeId][$res])) {
                foreach (array_keys($adj[$edificeId][$res]) as $next) {
                    $queue[] = $next;
                }
            }
            $visited = [];
            while (!empty($queue)) {
                $cur = array_shift($queue);
                if (isset($visited[$cur])) {
                    continue;
                }
                $visited[$cur] = true;
                if (!array_key_exists($res, $self[$cur] ?? [])) {
                    continue;
                }
                $curAff = $affected[$cur][$res] ?? null;
                if ($curAff === null || $ev['occurred_at'] < $curAff['occurred_at']) {
                    $affected[$cur][$res] = [
                        'source_id'   => $edificeId,
                        'occurred_at' => $ev['occurred_at'],
                    ];
                }
                if (isset($adj[$cur][$res])) {
                    foreach (array_keys($adj[$cur][$res]) as $next) {
                        if (!isset($visited[$next])) {
                            $queue[] = $next;
                        }
                    }
                }
            }
        }
    }

    $result = [];
    foreach ($edifices as $e) {
        $id = $e['id_edifice'];
        foreach ($e['resource_types'] as $res) {
            $ev = $self[$id][$res];
            $aff = $affected[$id][$res] ?? null;
            $statusId = $ev !== null ? $ev['id_status'] : 3;

            if ($statusId === 1) {
                $state = 'accident';
                $sourceId = $id;
                $accidentAt = $ev['occurred_at'];
            } elseif ($statusId === 2) {
                $state = 'repair';
                $sourceId = null;
                $accidentAt = null;
            } elseif ($aff !== null) {
                $state = 'affected';
                $sourceId = $aff['source_id'];
                $accidentAt = $aff['occurred_at'];
            } else {
                $state = 'normal';
                $sourceId = null;
                $accidentAt = null;
            }

            $result[$id][$res] = [
                'state'               => $state,
                'status_id'           => $statusId,
                'event_id'            => $ev !== null ? $ev['id_event'] : null,
                'occurred_at'         => $ev !== null ? $ev['occurred_at'] : null,
                'is_affected'         => $aff !== null,
                'accident_source_id'  => $sourceId !== null ? $sourceId : ($aff['source_id'] ?? null),
                'accident_occurred_at' => $accidentAt !== null ? $accidentAt : ($aff['occurred_at'] ?? null),
            ];
        }
    }
    return $result;
}

/** Отсортированный список моментов изменения статусов. */
function graph_timeline(array $events): array
{
    // Точки соответствуют только фактическим изменениям статусов
    // объекта/ресурса, а не равномерному шагу времени и не дубликатам статусов.
    usort($events, static function (array $a, array $b): int {
        $cmp = strcmp((string) $a['occurred_at'], (string) $b['occurred_at']);
        return $cmp !== 0 ? $cmp : ((int) $a['id_event'] <=> (int) $b['id_event']);
    });
    $last = [];
    $times = [];
    foreach ($events as $ev) {
        $key = $ev['id_edifice'] . ':' . $ev['resource_type'];
        $status = (int) $ev['id_status'];
        if (!array_key_exists($key, $last) || $last[$key] !== $status) {
            $times[(string) $ev['occurred_at']] = true;
        }
        $last[$key] = $status;
    }
    $points = array_keys($times);
    sort($points, SORT_STRING);
    return $points;
}


/** Количество объектов по районам. */
function graph_districts(array $edifices): array
{
    $out = [];
    foreach ($edifices as $e) {
        $d = is_string($e['district']) && $e['district'] !== '' ? $e['district'] : 'Без района';
        if (!isset($out[$d])) {
            $out[$d] = 0;
        }
        $out[$d]++;
    }
    return $out;
}

/**
 * Проверяет строгую ацикличность всех направленных зависимостей, независимо от ресурса.
 * Возвращает путь замыкающегося цикла для диагностики. Ничего не исправляет молча.
 *
 * @return int[] пустой массив при отсутствии циклов
 */
function graph_find_cycle(array $edifices, array $dependencies): array
{
    $adj = [];
    foreach ($edifices as $e) {
        $adj[(int) $e['id_edifice']] = [];
    }
    foreach ($dependencies as $edge) {
        $from = (int) $edge['source'];
        $to = (int) $edge['dependent'];
        if ($from === $to) {
            return [$from, $to];
        }
        if (!isset($adj[$from]) || !isset($adj[$to])) {
            throw new InvalidArgumentException('Связь указывает на несуществующий объект: ' . $from . ' → ' . $to);
        }
        $adj[$from][$to] = true;
    }
    $color = []; // 1: активный путь, 2: проверен
    $path = [];
    $index = [];
    foreach (array_keys($adj) as $start) {
        if (isset($color[$start])) {
            continue;
        }
        // Итеративный DFS, чтобы не упереться в лимит рекурсии.
        $stack = [['id' => $start, 'next' => array_keys($adj[$start]), 'i' => 0]];
        $color[$start] = 1;
        $path[] = $start;
        $index[$start] = count($path) - 1;
        while ($stack) {
            $top = count($stack) - 1;
            if ($stack[$top]['i'] >= count($stack[$top]['next'])) {
                $id = $stack[$top]['id'];
                $color[$id] = 2;
                unset($index[$id]);
                array_pop($path);
                array_pop($stack);
                continue;
            }
            $next = $stack[$top]['next'][$stack[$top]['i']++];
            if (($color[$next] ?? 0) === 1) {
                return array_merge(array_slice($path, $index[$next]), [$next]);
            }
            if (!isset($color[$next])) {
                $color[$next] = 1;
                $path[] = $next;
                $index[$next] = count($path) - 1;
                $stack[] = ['id' => $next, 'next' => array_keys($adj[$next]), 'i' => 0];
            }
        }
    }
    return [];
}

/** Проверка структуры перед импортом: DAG + совместимость ресурса на концах связи. */
function graph_assert_valid(array $edifices, array $dependencies): void
{
    $resources = [];
    foreach ($edifices as $e) {
        $resources[(int) $e['id_edifice']] = $e['resource_types'];
    }
    foreach ($dependencies as $d) {
        $from = (int) $d['source'];
        $to = (int) $d['dependent'];
        $res = (string) $d['resource_type'];
        if (
            !in_array($res, ['water', 'energy'], true)
            || !isset($resources[$from], $resources[$to])
            || !in_array($res, $resources[$from], true)
            || !in_array($res, $resources[$to], true)
        ) {
            throw new InvalidArgumentException('Некорректная зависимость #' . $d['id_dependence']
                . ': ' . $from . ' → ' . $to . ' (' . $res . ')');
        }
    }
    $cycle = graph_find_cycle($edifices, $dependencies);
    if ($cycle) {
        throw new InvalidArgumentException('Обнаружен недопустимый цикл зависимостей: ' . implode(' → ', $cycle));
    }
}
