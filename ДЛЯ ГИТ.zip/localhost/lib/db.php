<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * Собирает conninfo-строку для pg_connect.
 * Значения экранируются по правилам libpq.
 */
function db_build_conninfo(array $cfg): string
{
    $escape = static function (string $value): string {
        return "'" . str_replace(['\\', "'"], ['\\\\', "\\'"], $value) . "'";
    };

    return sprintf(
        'host=%s port=%d dbname=%s user=%s password=%s connect_timeout=%d application_name=%s',
        $escape((string) $cfg['host']),
        (int) $cfg['port'],
        $escape((string) $cfg['dbname']),
        $escape((string) $cfg['user']),
        $escape((string) $cfg['password']),
        (int) $cfg['connect_timeout'],
        $escape((string) $cfg['application_name'])
    );
}

/**
 * Открывает (и кеширует в пределах запроса) соединение pg.
 *
 * @return resource|\PgSql\Connection
 * @throws InvalidArgumentException при неизвестном имени подключения
 * @throws RuntimeException при ошибке соединения
 */
function db_connect(string $name)
{
    static $cache = [];
    if (isset($cache[$name])) {
        return $cache[$name];
    }

    $config = app_config();
    if (!isset($config['db'][$name]) || !is_array($config['db'][$name])) {
        throw new InvalidArgumentException('Неизвестное подключение: ' . $name);
    }
    $cfg = $config['db'][$name];

    $conn = @pg_connect(db_build_conninfo($cfg), PGSQL_CONNECT_FORCE_NEW);
    if ($conn === false) {
        $last = error_get_last();
        $reason = is_array($last) && isset($last['message'])
            ? (string) $last['message']
            : 'неизвестная ошибка';
        throw new RuntimeException('Не удалось подключиться к БД "' . $name . '": ' . $reason);
    }

    $cache[$name] = $conn;
    return $conn;
}

/** Локальное подключение (кэш приложения). */
function db_local()
{
    return db_connect('local');
}

/** Внешнее подключение (источник данных). */
function db_external()
{
    return db_connect('external');
}

/**
 * Приводит значение параметра к виду, ожидаемому pg_query_params.
 * Массив переиндексируется — позиции становятся $1, $2, ...
 */
function db_normalize_params(array $params): array
{
    $out = [];
    foreach (array_values($params) as $value) {
        if ($value === null) {
            $out[] = null;
            continue;
        }
        if (is_bool($value)) {
            $out[] = $value ? 't' : 'f';
            continue;
        }
        if (is_int($value) || is_float($value)) {
            $out[] = (string) $value;
            continue;
        }
        if ($value instanceof DateTimeInterface) {
            $out[] = $value->format('Y-m-d H:i:s');
            continue;
        }
        if (is_string($value)) {
            $out[] = $value;
            continue;
        }
        if (is_scalar($value)) {
            $out[] = (string) $value;
            continue;
        }
        throw new InvalidArgumentException('Неподдерживаемый тип параметра SQL: ' . gettype($value));
    }
    return $out;
}

/**
 * Параметризованный запрос. Позиционные $1, $2, ...
 *
 * @return resource|\PgSql\Result
 * @throws RuntimeException при ошибке SQL
 */
function db_query_params($conn, string $sql, array $params = [])
{
    $normalized = db_normalize_params($params);
    $result = @pg_query_params($conn, $sql, $normalized);
    if ($result === false) {
        $error = pg_last_error($conn);
        if ($error === '') {
            $error = 'неизвестная ошибка запроса';
        }
        throw new RuntimeException('Ошибка SQL: ' . $error);
    }
    return $result;
}

/** Первая строка результата или null. */
function db_one($conn, string $sql, array $params = []): ?array
{
    $result = db_query_params($conn, $sql, $params);
    $row = pg_fetch_assoc($result);
    pg_free_result($result);
    return $row === false ? null : $row;
}

/** Все строки результата (пустой массив, если строк нет). */
function db_all($conn, string $sql, array $params = []): array
{
    $result = db_query_params($conn, $sql, $params);
    $rows = pg_fetch_all($result);
    pg_free_result($result);
    return $rows === false ? [] : $rows;
}

/** Первое поле первой строки или значение по умолчанию. */
function db_scalar($conn, string $sql, array $params = [], $default = null)
{
    $result = db_query_params($conn, $sql, $params);
    $row = pg_fetch_row($result);
    pg_free_result($result);
    if ($row === false || !array_key_exists(0, $row) || $row[0] === null) {
        return $default;
    }
    return $row[0];
}

/** Выполнение DML/DDL, возвращает число затронутых строк. */
function db_exec($conn, string $sql, array $params = []): int
{
    $result = db_query_params($conn, $sql, $params);
    $affected = pg_affected_rows($result);
    pg_free_result($result);
    return (int) $affected;
}

/** BEGIN. */
function db_begin($conn): void
{
    $result = @pg_query($conn, 'BEGIN');
    if ($result === false) {
        throw new RuntimeException('Не удалось начать транзакцию: ' . pg_last_error($conn));
    }
    pg_free_result($result);
}

/** COMMIT. */
function db_commit($conn): void
{
    $result = @pg_query($conn, 'COMMIT');
    if ($result === false) {
        throw new RuntimeException('Не удалось зафиксировать транзакцию: ' . pg_last_error($conn));
    }
    pg_free_result($result);
}

/** ROLLBACK (безопасно игнорирует ошибку отката). */
function db_rollback($conn): void
{
    $result = @pg_query($conn, 'ROLLBACK');
    if ($result !== false) {
        pg_free_result($result);
    }
}

/**
 * Безопасная проверка внешнего подключения без выброса исключения.
 *
 * @return array{ok: bool, error: ?string}
 */
function db_external_probe(): array
{
    try {
        $conn = db_external();
        $result = @pg_query($conn, 'SELECT 1');
        if ($result === false) {
            $error = pg_last_error($conn);
            return ['ok' => false, 'error' => $error === '' ? 'нет ответа' : $error];
        }
        pg_free_result($result);
        return ['ok' => true, 'error' => null];
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Проверяет наличие обязательных таблиц локальной схемы.
 *
 * @return array{ok: bool, missing: array<int,string>, error: ?string}
 */
function db_local_ready(): array
{
    $required = [
        'cache_edifices',
        'cache_edifice_dependencies',
        'cache_events',
        'cache_event_statuses',
        'cache_layout_nodes',
        'cache_layout_edges',
        'cache_sync_state',
    ];
    try {
        $conn = db_local();
        $rows = db_all(
            $conn,
            "SELECT table_name
               FROM information_schema.tables
              WHERE table_schema = $1 AND table_type = $2",
            ['public', 'BASE TABLE']
        );
        $existing = [];
        foreach ($rows as $row) {
            $existing[] = (string) $row['table_name'];
        }
        $missing = array_values(array_diff($required, $existing));
        return ['ok' => count($missing) === 0, 'missing' => $missing, 'error' => null];
    } catch (Throwable $e) {
        return ['ok' => false, 'missing' => [], 'error' => $e->getMessage()];
    }
}

/**
 * Полный сброс локального кэша: объекты, зависимости, события, компоновка.
 * Внешняя БД не затрагивается — только чтение.
 */
function db_reset_local(): void
{
    $conn = db_local();
    db_begin($conn);
    try {
        db_exec(
            $conn,
            'TRUNCATE TABLE cache_layout_edges, cache_layout_nodes, cache_events, '
                . 'cache_edifice_dependencies, cache_edifices, cache_event_statuses '
                . 'RESTART IDENTITY CASCADE'
        );
        db_exec(
            $conn,
            'UPDATE cache_sync_state
                SET last_sync_at = NULL,
                    last_status  = NULL,
                    last_message = NULL,
                    updated_at   = NOW()
              WHERE id = 1'
        );
        db_commit($conn);
    } catch (Throwable $e) {
        db_rollback($conn);
        throw $e;
    }
}

/**
 * Краткая статистика локального кэша.
 *
 * @return array{edifices:int, dependencies:int, events:int}
 */
function db_local_stats(): array
{
    $conn = db_local();
    return [
        'edifices'     => (int) db_scalar($conn, 'SELECT COUNT(*) FROM cache_edifices', [], 0),
        'dependencies' => (int) db_scalar($conn, 'SELECT COUNT(*) FROM cache_edifice_dependencies', [], 0),
        'events'       => (int) db_scalar($conn, 'SELECT COUNT(*) FROM cache_events', [], 0),
    ];
}
