<?php

declare(strict_types=1);

/**
 * Отправка успешного JSON-ответа и завершение скрипта.
 * Поле ok всегда true; остальные поля — из $payload.
 */
function json_ok(array $payload = [], int $status = 200): void
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
    }
    $body = array_merge(['ok' => true], $payload);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Отправка ошибочного JSON-ответа и завершение скрипта.
 */
function json_error(string $message, int $status = 400, array $extra = []): void
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
    }
    $body = ['ok' => false, 'error' => $message];
    if (!empty($extra)) {
        $body = array_merge($body, $extra);
    }
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
