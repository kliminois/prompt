<?php

declare(strict_types=1);

/** Триммирует и ограничивает длину строки, приводит скаляры к строке. */
function v_str($value, int $maxLen, string $default = ''): string
{
    if (!is_string($value)) {
        if (is_scalar($value)) {
            $value = (string) $value;
        } else {
            return $default;
        }
    }
    $value = trim($value);
    if (function_exists('mb_substr')) {
        return mb_substr($value, 0, $maxLen, 'UTF-8');
    }
    return substr($value, 0, $maxLen);
}

/** Положительный целочисленный ID или null. */
function v_id($value): ?int
{
    if ($value === null || $value === '') {
        return null;
    }
    if (is_int($value)) {
        return $value > 0 ? $value : null;
    }
    if (!is_scalar($value)) {
        return null;
    }
    $str = (string) $value;
    if ($str === '' || strlen($str) > 10) {
        return null;
    }
    if (!preg_match('/^\d+$/', $str)) {
        return null;
    }
    $n = (int) $str;
    return $n > 0 ? $n : null;
}

/** Значение из белого списка или $default. */
function v_enum($value, array $allowed, ?string $default = null): ?string
{
    if (!is_string($value)) {
        return $default;
    }
    return in_array($value, $allowed, true) ? $value : $default;
}

/** Дата-время в формате 'Y-m-d H:i:s' или null. */
function v_datetime($value): ?string
{
    if (!is_string($value) || $value === '') {
        return null;
    }
    $trimmed = trim($value);
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $trimmed);
    if ($dt instanceof DateTime) {
        $errors = DateTime::getLastErrors();
        if ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0)) {
            return $dt->format('Y-m-d H:i:s');
        }
        return null;
    }
    return null;
}

/** Булево значение из строки/числа. */
function v_bool($value): bool
{
    if (is_bool($value)) {
        return $value;
    }
    if (is_int($value)) {
        return $value !== 0;
    }
    if (is_string($value)) {
        return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
    }
    return false;
}

/** Массив строк из смешанного массива (без вложенных). */
function v_array_of_strings($value, int $maxItems = 100, int $maxLen = 100): array
{
    if (!is_array($value)) {
        return [];
    }
    $out = [];
    foreach ($value as $v) {
        if (count($out) >= $maxItems) {
            break;
        }
        if (!is_scalar($v)) {
            continue;
        }
        $s = v_str((string) $v, $maxLen);
        if ($s !== '') {
            $out[] = $s;
        }
    }
    return $out;
}

/** Конечное число (float) или null. */
function v_float($value): ?float
{
    if (is_int($value) || is_float($value)) {
        $f = (float) $value;
        return is_finite($f) ? $f : null;
    }
    if (is_string($value) && $value !== '') {
        if (!is_numeric($value)) {
            return null;
        }
        $f = (float) $value;
        return is_finite($f) ? $f : null;
    }
    return null;
}
